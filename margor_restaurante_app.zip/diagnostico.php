<?php
// ARQUIVO DE DIAGNÓSTICO — DELETE APÓS USO
require_once 'includes/db.php';

echo '<style>body{font-family:monospace;background:#0f0f0f;color:#F5F0E8;padding:2rem}
h2{color:#C9A84C;margin:1.5rem 0 .5rem}
table{border-collapse:collapse;width:100%;margin-bottom:1rem}
th,td{border:1px solid #2e2e2e;padding:.4rem .8rem;text-align:left}
th{background:#1e1e1e;color:#C9A84C}
.ok{color:#7bc492}.err{color:#e88882}.warn{color:#e0b06a}
pre{background:#1e1e1e;padding:1rem;border-radius:8px;overflow:auto}
</style>';

echo '<h1>🔧 Diagnóstico — RestauranteApp</h1>';

try {
    $db = getDB();

    // 1. Info do banco
    $dbNome = $db->query("SELECT DATABASE()")->fetchColumn();
    $versao = $db->query("SELECT VERSION()")->fetchColumn();
    echo "<h2>✅ Conexão OK</h2>";
    echo "<table><tr><th>Banco</th><th>Versão MySQL</th></tr>";
    echo "<tr><td><strong class='ok'>$dbNome</strong></td><td>$versao</td></tr></table>";

    // 2. Contagem por tabela
    echo "<h2>📊 Registros por tabela</h2>";
    echo "<table><tr><th>Tabela</th><th>Total</th><th>Status</th></tr>";
    $tabelas = ['usuarios','clientes','pratos','categorias_prato','reservas','pedidos','itens_pedido'];
    foreach ($tabelas as $t) {
        try {
            $n = $db->query("SELECT COUNT(*) FROM $t")->fetchColumn();
            $cls = $n > 0 ? 'ok' : 'warn';
            echo "<tr><td>$t</td><td><strong class='$cls'>$n</strong></td><td class='$cls'>" . ($n > 0 ? '✅ OK' : '⚠️ Vazio') . "</td></tr>";
        } catch (Exception $e) {
            echo "<tr><td>$t</td><td colspan='2' class='err'>❌ " . $e->getMessage() . "</td></tr>";
        }
    }
    echo "</table>";

    // 3. Verificar duplicatas em pratos
    echo "<h2>🔍 Verificar duplicatas em pratos</h2>";
    $dups = $db->query(
        "SELECT nome, COUNT(*) as qtd FROM pratos GROUP BY nome HAVING qtd > 1"
    )->fetchAll();
    if (empty($dups)) {
        echo "<p class='ok'>✅ Nenhum prato duplicado.</p>";
    } else {
        echo "<table><tr><th>Prato</th><th>Ocorrências</th></tr>";
        foreach ($dups as $d) {
            echo "<tr><td class='err'>{$d['nome']}</td><td class='err'>{$d['qtd']}</td></tr>";
        }
        echo "</table>";
        echo "<p class='warn'>⚠️ Execute o SQL abaixo para remover duplicatas:</p>";
        echo "<pre>";
        foreach ($dups as $d) {
            $nome = addslashes($d['nome']);
            echo "-- Manter apenas o ID mais baixo de '{$d['nome']}'\n";
            echo "DELETE FROM pratos WHERE nome='$nome' AND id NOT IN (SELECT * FROM (SELECT MIN(id) FROM pratos WHERE nome='$nome') t);\n\n";
        }
        echo "</pre>";
    }

    // 4. Últimos clientes cadastrados
    echo "<h2>👥 Últimos 5 clientes</h2>";
    $clientes = $db->query("SELECT id, nome, email, criado_em FROM clientes ORDER BY criado_em DESC LIMIT 5")->fetchAll();
    if (empty($clientes)) {
        echo "<p class='warn'>⚠️ Nenhum cliente cadastrado.</p>";
    } else {
        echo "<table><tr><th>ID</th><th>Nome</th><th>Email</th><th>Criado em</th></tr>";
        foreach ($clientes as $c) {
            echo "<tr><td>{$c['id']}</td><td>{$c['nome']}</td><td>{$c['email']}</td><td>{$c['criado_em']}</td></tr>";
        }
        echo "</table>";
    }

    // 5. Últimos pratos
    echo "<h2>🍽️ Últimos 5 pratos</h2>";
    $pratos = $db->query("SELECT id, nome, status, criado_em FROM pratos ORDER BY criado_em DESC LIMIT 5")->fetchAll();
    if (empty($pratos)) {
        echo "<p class='warn'>⚠️ Nenhum prato.</p>";
    } else {
        echo "<table><tr><th>ID</th><th>Nome</th><th>Status</th><th>Criado em</th></tr>";
        foreach ($pratos as $p) {
            echo "<tr><td>{$p['id']}</td><td>{$p['nome']}</td><td>{$p['status']}</td><td>{$p['criado_em']}</td></tr>";
        }
        echo "</table>";
    }

    // 6. Testar INSERT de cliente de teste
    echo "<h2>🧪 Teste de INSERT</h2>";
    if (isset($_GET['testar_insert'])) {
        try {
            $email_teste = 'teste_diagnostico_' . time() . '@teste.com';
            $db->prepare(
                "INSERT INTO clientes (nome, email, senha, telefone) VALUES (?, ?, MD5(?), ?)"
            )->execute(['Cliente Teste Diagnóstico', $email_teste, '123456', '(11) 99999-0000']);
            $id = $db->lastInsertId();
            echo "<p class='ok'>✅ INSERT funcionou! ID gerado: <strong>$id</strong></p>";
            echo "<p>Verifique no phpMyAdmin se o cliente com email <strong>$email_teste</strong> aparece.</p>";
            // Limpa o teste
            $db->prepare("DELETE FROM clientes WHERE id=?")->execute([$id]);
            echo "<p class='warn'>(Registro de teste removido automaticamente)</p>";
        } catch (Exception $e) {
            echo "<p class='err'>❌ Erro no INSERT: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } else {
        echo "<a href='?testar_insert=1' style='color:#C9A84C;text-decoration:underline'>Clique aqui para testar um INSERT na tabela clientes</a>";
    }

    // 7. Verificar charset
    echo "<h2>🔤 Charset da conexão</h2>";
    $charset = $db->query("SHOW VARIABLES LIKE 'character_set_client'")->fetch();
    $collation = $db->query("SHOW VARIABLES LIKE 'collation_connection'")->fetch();
    echo "<table><tr><th>Variável</th><th>Valor</th></tr>";
    echo "<tr><td>{$charset['Variable_name']}</td><td>{$charset['Value']}</td></tr>";
    echo "<tr><td>{$collation['Variable_name']}</td><td>{$collation['Value']}</td></tr>";
    echo "</table>";

    // 8. Verificar constraints de FK nos pedidos (motivo de não excluir prato)
    echo "<h2>🔗 Pratos vinculados a pedidos (não excluíveis)</h2>";
    $vinculados = $db->query(
        "SELECT pr.id, pr.nome, COUNT(ip.id) as vezes_pedido
         FROM pratos pr
         JOIN itens_pedido ip ON ip.prato_id = pr.id
         GROUP BY pr.id, pr.nome
         ORDER BY vezes_pedido DESC"
    )->fetchAll();
    if (empty($vinculados)) {
        echo "<p class='ok'>✅ Nenhum prato vinculado a pedidos.</p>";
    } else {
        echo "<table><tr><th>ID</th><th>Prato</th><th>Vezes em pedidos</th><th>Solução</th></tr>";
        foreach ($vinculados as $v) {
            echo "<tr><td>{$v['id']}</td><td class='warn'>{$v['nome']}</td><td>{$v['vezes_pedido']}</td><td style='font-size:.85rem;color:#7A7470'>Marque como Indisponível</td></tr>";
        }
        echo "</table>";
    }

} catch (Exception $e) {
    echo "<h2 class='err'>❌ Erro de conexão</h2>";
    echo "<p class='err'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Verifique as configurações em <strong>includes/db.php</strong></p>";
}

echo "<hr style='border-color:#2e2e2e;margin-top:2rem'>";
echo "<p style='color:#7A7470;font-size:.8rem'>⚠️ Exclua este arquivo após o diagnóstico: <code>diagnostico.php</code></p>";
?>
