<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Garçom') {
    header('Location: ../painel.php'); exit;
}

$db  = getDB();
$uid = (int)usuarioAtual()['id'];

// Pedidos abertos (todos, não só os seus)
$pedidos = $db->query(
    "SELECT p.id, c.nome AS cliente, p.status, p.total, p.criado_em, p.observacao
     FROM pedidos p JOIN clientes c ON c.id = p.cliente_id
     WHERE p.status NOT IN ('Entregue','Cancelado')
     ORDER BY p.criado_em ASC"
)->fetchAll();

// Reservas de hoje
$reservasHoje = $db->query(
    "SELECT r.nome, r.hora_reserva, r.pessoas, r.status
     FROM reservas r
     WHERE r.data_reserva = CURDATE()
     ORDER BY r.hora_reserva ASC"
)->fetchAll();

$tituloPagina = 'Painel Garçom';
$paginaAtiva  = 'painel';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
.garcom-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.4rem; }
@media (max-width: 700px) { .garcom-grid { grid-template-columns: 1fr; } }
</style>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div>
      <h1>Olá, <?= htmlspecialchars(explode(' ', usuarioAtual()['nome'])[0]) ?>! 👋</h1>
      <p>Aqui estão os pedidos e reservas de hoje</p>
    </div>
    <div style="display:flex;gap:.6rem">
      <a href="pedidos.php"  class="btn btn-primary btn-sm">➕ Novo pedido</a>
      <a href="reservas.php" class="btn btn-accent btn-sm">📅 Reservas</a>
    </div>
  </div>

  <!-- KPIs rápidos -->
  <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:1.4rem">
    <div class="stat-card">
      <div class="stat-icon">🧾</div>
      <div class="stat-value"><?= count($pedidos) ?></div>
      <div class="stat-label">Pedidos em aberto</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">📅</div>
      <div class="stat-value"><?= count($reservasHoje) ?></div>
      <div class="stat-label">Reservas hoje</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">👨‍🍳</div>
      <div class="stat-value">
        <?= count(array_filter($pedidos, fn($p) => $p['status'] === 'Pronto')) ?>
      </div>
      <div class="stat-label">Prontos p/ entregar</div>
    </div>
  </div>

  <div class="garcom-grid">

    <!-- Pedidos -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title" style="display:flex;justify-content:space-between;align-items:center">
        🧾 Pedidos em aberto
        <a href="pedidos.php" style="font-size:.76rem;color:var(--gold)">Gerenciar →</a>
      </div>
      <?php if (empty($pedidos)): ?>
        <div class="empty-state" style="padding:2rem 0">
          <div class="empty-icon">✅</div>
          <p>Nenhum pedido em aberto!</p>
        </div>
      <?php else: ?>
      <div class="table-wrap" style="border:none">
        <table>
          <thead><tr><th>#</th><th>Cliente</th><th>Status</th><th>Total</th></tr></thead>
          <tbody>
          <?php foreach ($pedidos as $p):
            $bm = ['Aguardando'=>'aguardando','Em preparo'=>'preparo','Pronto'=>'pronto'];
            $b  = $bm[$p['status']] ?? 'aguardando'; ?>
          <tr <?= $p['status']==='Pronto' ? 'style="background:rgba(74,124,89,0.06)"' : '' ?>>
            <td style="color:var(--muted);font-size:.8rem">#<?= $p['id'] ?></td>
            <td style="font-weight:500"><?= htmlspecialchars($p['cliente']) ?></td>
            <td><span class="badge badge-<?= $b ?>"><?= $p['status'] ?></span></td>
            <td style="color:var(--gold);font-family:var(--font-display)">R$ <?= number_format((float)$p['total'],2,',','.') ?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

    <!-- Reservas do dia -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title" style="display:flex;justify-content:space-between;align-items:center">
        📅 Reservas de hoje
        <a href="reservas.php" style="font-size:.76rem;color:var(--gold)">Gerenciar →</a>
      </div>
      <?php if (empty($reservasHoje)): ?>
        <div class="empty-state" style="padding:2rem 0">
          <div class="empty-icon">📅</div>
          <p>Sem reservas para hoje.</p>
        </div>
      <?php else: ?>
      <div class="table-wrap" style="border:none">
        <table>
          <thead><tr><th>Nome</th><th>Horário</th><th>Pess.</th><th>Status</th></tr></thead>
          <tbody>
          <?php foreach ($reservasHoje as $r):
            $b = match($r['status']) { 'Confirmada'=>'confirmada','Cancelada'=>'cancelada','Concluída'=>'concluida',default=>'pendente' }; ?>
          <tr>
            <td style="font-weight:500"><?= htmlspecialchars($r['nome']) ?></td>
            <td><?= substr($r['hora_reserva'],0,5) ?></td>
            <td>👥 <?= $r['pessoas'] ?></td>
            <td><span class="badge badge-<?= $b ?>"><?= $r['status'] ?></span></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

  </div>

  </main>
</div>
</body>
</html>
