<?php
require_once '../includes/auth.php';

$clienteLogadoDados = clienteLogado() ? clienteAtual() : null;
$erro = '';
$ok   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome    = trim($_POST['nome']         ?? '');
    $data    = trim($_POST['data_reserva'] ?? '');
    $hora    = trim($_POST['hora_reserva'] ?? '');
    $pessoas = (int)($_POST['pessoas']     ?? 1);

    if (!$nome || !$data || !$hora || $pessoas < 1) {
        $erro = 'Preencha todos os campos, incluindo data e horário.';
    } elseif ($data < date('Y-m-d')) {
        $erro = 'A data da reserva não pode ser no passado.';
    } elseif ($pessoas > 20) {
        $erro = 'Para grupos acima de 20 pessoas, entre em contato por telefone.';
    } else {
        $validacao = validarHorarioReserva($data, $hora);
        if ($validacao !== true) {
            $erro = $validacao;
        } else {
            $db = getDB();
            $clienteId = $clienteLogadoDados ? (int)$clienteLogadoDados['id'] : null;
            $db->prepare(
                "INSERT INTO reservas (nome, data_reserva, hora_reserva, pessoas, status, origem, cliente_id)
                 VALUES (?, ?, ?, ?, 'Pendente', 'online', ?)"
            )->execute([$nome, $data, $hora, $pessoas, $clienteId]);
            $ok = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fazer Reserva — RestauranteApp</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .reserva-wrap { min-height:100vh; display:flex; align-items:center; justify-content:center; padding:2rem; }
  </style>
</head>
<body>
<div class="reserva-wrap">
  <div style="width:100%;max-width:480px">

    <a href="../index.php" class="auth-back">← Voltar ao início</a>

    <div class="auth-card">
      <div class="auth-logo">
        <div class="auth-logo-icon">📅</div>
        <h1>Fazer reserva</h1>
        <p>Sem necessidade de cadastro</p>
      </div>

      <?php if ($clienteLogadoDados): ?>
        <div class="alert alert-info">
          👋 Olá, <strong><?= htmlspecialchars($clienteLogadoDados['nome']) ?></strong>!
          Esta reserva será vinculada à sua conta automaticamente.
        </div>
      <?php endif; ?>

      <?php if ($ok): ?>
        <div class="alert alert-success">
          ✅ <strong>Reserva solicitada com sucesso!</strong><br>
          Nossa equipe entrará em contato para confirmar.
        </div>
        <a href="../index.php" class="btn btn-outline btn-full" style="margin-top:.5rem">← Voltar ao início</a>
        <?php if (!clienteLogado()): ?>
        <div class="visitor-bar">
          <p>Quer acompanhar sua reserva?</p>
          <div style="display:flex;gap:.6rem;justify-content:center;flex-wrap:wrap">
            <a href="cadastro.php"      class="btn btn-primary btn-sm">✨ Criar conta</a>
            <a href="login-cliente.php" class="btn btn-outline btn-sm">🔑 Entrar</a>
          </div>
        </div>
        <?php endif; ?>

      <?php else: ?>

        <?php if ($erro): ?>
          <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>

          <div class="form-group">
            <label>Seu nome <span style="color:var(--gold)">*</span></label>
            <input type="text" name="nome" placeholder="Nome para a reserva"
                   value="<?= htmlspecialchars($_POST['nome'] ?? $clienteLogadoDados['nome'] ?? '') ?>"
                   <?= $clienteLogadoDados ? 'readonly style="opacity:.6"' : '' ?> required>
          </div>

          <!-- Picker de data + horário -->
          <div data-reserva-picker>
            <div class="form-group" style="margin-bottom:.6rem">
              <label>Data <span style="color:var(--gold)">*</span></label>
              <input type="date"   name="data_reserva" data-rp-date
                     value="<?= htmlspecialchars($_POST['data_reserva'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label>Horário <span style="color:var(--gold)">*</span></label>
              <input type="hidden" name="hora_reserva" data-rp-hora
                     value="<?= htmlspecialchars($_POST['hora_reserva'] ?? '') ?>">
            </div>
          </div>

          <div class="form-group" style="margin-top:.8rem">
            <label>Número de pessoas <span style="color:var(--gold)">*</span></label>
            <select name="pessoas" required>
              <?php for ($i = 1; $i <= 20; $i++): ?>
                <option value="<?= $i ?>" <?= (int)($_POST['pessoas'] ?? 2) === $i ? 'selected' : '' ?>>
                  <?= $i ?> pessoa<?= $i > 1 ? 's' : '' ?>
                </option>
              <?php endfor; ?>
            </select>
          </div>

          <button type="submit" class="btn btn-primary btn-full" style="margin-top:.4rem">
            📅 Confirmar reserva
          </button>
        </form>

        <?php if (!clienteLogado()): ?>
        <div class="visitor-bar">
          <p>Tem uma conta? Entre para vincular ao seu perfil</p>
          <div style="display:flex;gap:.6rem;justify-content:center;flex-wrap:wrap">
            <a href="login-cliente.php" class="btn btn-outline btn-sm">🔑 Entrar</a>
            <a href="cadastro.php"      class="btn btn-ghost btn-sm">✨ Criar conta</a>
          </div>
        </div>
        <?php else: ?>
        <div class="visitor-bar">
          <a href="cliente/reservas.php" class="btn btn-outline btn-sm">Ver minhas reservas</a>
          <a href="cliente/logout.php" style="font-size:.8rem;color:var(--muted);margin-left:.8rem">Sair</a>
        </div>
        <?php endif; ?>

      <?php endif; ?>
    </div>
  </div>
</div>
<script src="../assets/js/reserva-picker.js"></script>
</body>
</html>
