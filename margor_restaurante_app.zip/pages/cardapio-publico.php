<?php
require_once '../includes/auth.php';

$db = getDB();

// Buscar todos os pratos disponíveis por categoria
$stmt = $db->query(
    "SELECT p.id, p.nome, p.descricao, p.preco, p.tempo_minutos, p.status,
            c.nome AS categoria, c.id AS categoria_id
     FROM pratos p JOIN categorias_prato c ON c.id = p.categoria_id
     WHERE p.status = 'Disponível'
     ORDER BY c.nome, p.nome"
);
$todos = $stmt->fetchAll();

$porCategoria = [];
$idsVistos = [];
foreach ($todos as $p) {
    if (in_array($p['id'], $idsVistos)) continue;
    $idsVistos[] = $p['id'];
    $porCategoria[$p['categoria']][] = $p;
}

$categorias = array_keys($porCategoria);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cardápio — RestauranteApp</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    body { background: var(--bg); }

    .cardapio-page {
      max-width: 1100px;
      margin: 0 auto;
      padding: 0 2rem 5rem;
    }

    /* Header da página */
    .cardapio-hero {
      text-align: center;
      padding: 5rem 2rem 3.5rem;
      position: relative;
    }
    .cardapio-hero::before {
      content: '';
      position: absolute;
      top: 0; left: 50%;
      transform: translateX(-50%);
      width: 1px;
      height: 3rem;
      background: linear-gradient(180deg, transparent, var(--gold));
    }

    /* Filtros sticky */
    .cardapio-sticky {
      position: sticky;
      top: 0;
      z-index: 30;
      background: rgba(15,15,15,0.92);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border);
      padding: .8rem 0;
      margin: 0 -2rem;
      padding-left: 2rem;
      padding-right: 2rem;
    }
    .cardapio-sticky-inner {
      max-width: 1100px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }

    /* Seção de categoria */
    .cat-section { margin-bottom: 3.5rem; }
    .cat-section-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }
    .cat-section-title {
      font-family: var(--font-display);
      font-size: 1.5rem;
      color: var(--text);
    }
    .cat-line {
      flex: 1;
      height: 1px;
      background: linear-gradient(90deg, var(--border), transparent);
    }

    /* Grid com tamanho generoso */
    .pratos-grid-pub {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1.2rem;
    }

    /* Card refinado */
    .prato-pub-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius-lg);
      padding: 1.6rem;
      display: flex;
      flex-direction: column;
      gap: .8rem;
      transition: border-color .25s, box-shadow .25s, transform .25s;
      position: relative;
      overflow: hidden;
    }
    .prato-pub-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 2px;
      background: linear-gradient(90deg, transparent, var(--gold), transparent);
      opacity: 0;
      transition: opacity .3s;
    }
    .prato-pub-card:hover {
      border-color: var(--border-gold);
      box-shadow: 0 6px 28px rgba(201,168,76,0.1);
      transform: translateY(-2px);
    }
    .prato-pub-card:hover::before { opacity: 1; }

    .prato-pub-nome {
      font-family: var(--font-display);
      font-size: 1.15rem;
      color: var(--text);
      line-height: 1.25;
    }
    .prato-pub-desc {
      font-size: .84rem;
      color: var(--muted);
      line-height: 1.6;
      flex: 1;
    }
    .prato-pub-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-top: .8rem;
      border-top: 1px solid var(--border);
    }
    .prato-pub-preco {
      font-family: var(--font-display);
      font-size: 1.5rem;
      color: var(--gold);
      font-weight: 400;
    }
    .prato-pub-meta {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: .2rem;
    }
    .prato-pub-tempo { font-size: .75rem; color: var(--muted); }

    /* CTA login */
    .cta-login-bar {
      background: var(--gold-dim);
      border: 1px solid var(--border-gold);
      border-radius: var(--radius-lg);
      padding: 2rem;
      text-align: center;
      margin-bottom: 2.5rem;
    }
    .cta-login-bar h3 {
      font-size: 1.2rem;
      margin-bottom: .4rem;
    }
    .cta-login-bar p { font-size: .88rem; color: var(--text-2); margin-bottom: 1rem; }
  </style>
</head>
<body>

<!-- Barra de navegação simples -->
<nav style="background:var(--bg-2);border-bottom:1px solid var(--border);padding:.9rem 2rem;display:flex;align-items:center;justify-content:space-between">
  <a href="../index.php" style="font-family:var(--font-display);font-size:1.2rem;color:var(--gold)">Margôr</a>
  <div style="display:flex;gap:.8rem">
    <?php if (clienteLogado()): ?>
      <a href="cliente/cardapio.php" class="btn btn-primary btn-sm">🛒 Fazer pré-pedido</a>
      <a href="cliente/painel.php"   class="btn btn-outline btn-sm">Minha conta</a>
    <?php else: ?>
      <a href="login-cliente.php" class="btn btn-outline btn-sm">Entrar</a>
      <a href="cadastro.php"      class="btn btn-primary btn-sm">Criar conta</a>
    <?php endif; ?>
  </div>
</nav>

<!-- Hero -->
<div class="cardapio-hero">
  <p style="font-family:var(--font-accent);font-style:italic;font-size:.95rem;color:var(--gold);letter-spacing:.12em;margin-bottom:.6rem">
    Nossa cozinha
  </p>
  <h1 style="font-size:clamp(2rem,5vw,3rem);margin-bottom:.6rem">Cardápio</h1>
  <p style="color:var(--text-2);font-size:.95rem">Todos os pratos disponíveis hoje</p>
</div>

<!-- Sticky: filtros por categoria -->
<div class="cardapio-sticky">
  <div class="cardapio-sticky-inner">
    <div class="cat-filters" style="margin:0">
      <button class="cat-filter active" onclick="filtrarCat('todas', this)">Todos</button>
      <?php foreach ($categorias as $cat): ?>
        <button class="cat-filter"
                onclick="filtrarCat('<?= htmlspecialchars(strtolower(preg_replace('/\s+/','_',$cat))) ?>', this)">
          <?= htmlspecialchars($cat) ?>
        </button>
      <?php endforeach; ?>
    </div>
    <?php if (!clienteLogado()): ?>
    <a href="login-cliente.php" class="btn btn-primary btn-sm" style="flex-shrink:0">
      🛒 Fazer pré-pedido
    </a>
    <?php endif; ?>
  </div>
</div>

<div class="cardapio-page">

  <!-- CTA para quem não está logado -->
  <?php if (!clienteLogado()): ?>
  <div class="cta-login-bar" style="margin-top:2rem">
    <h3>Quer montar seu pedido antes de chegar?</h3>
    <p>Clientes cadastrados podem fazer um pré-pedido vinculado à sua reserva</p>
    <div style="display:flex;gap:.8rem;justify-content:center;flex-wrap:wrap">
      <a href="login-cliente.php" class="btn btn-primary">🔑 Entrar e pedir</a>
      <a href="cadastro.php"      class="btn btn-accent">✨ Criar conta grátis</a>
    </div>
  </div>
  <?php endif; ?>

  <!-- Pratos por categoria -->
  <?php foreach ($porCategoria as $cat => $pratos): ?>
  <?php $catSlug = strtolower(preg_replace('/\s+/', '_', $cat)); ?>
  <div class="cat-section" data-cat="<?= $catSlug ?>">
    <div class="cat-section-header">
      <h2 class="cat-section-title"><?= htmlspecialchars($cat) ?></h2>
      <div class="cat-line"></div>
      <span style="font-size:.75rem;color:var(--muted);white-space:nowrap">
        <?= count($pratos) ?> prato<?= count($pratos) > 1 ? 's' : '' ?>
      </span>
    </div>

    <div class="pratos-grid-pub">
      <?php foreach ($pratos as $p): ?>
      <div class="prato-pub-card">
        <h3 class="prato-pub-nome"><?= htmlspecialchars($p['nome']) ?></h3>
        <?php if ($p['descricao']): ?>
          <p class="prato-pub-desc"><?= htmlspecialchars($p['descricao']) ?></p>
        <?php endif; ?>
        <div class="prato-pub-footer">
          <span class="prato-pub-preco">R$ <?= number_format((float)$p['preco'], 2, ',', '.') ?></span>
          <div class="prato-pub-meta">
            <span class="prato-pub-tempo">⏱ <?= $p['tempo_minutos'] ?> min</span>
            <?php if (clienteLogado()): ?>
              <a href="cliente/cardapio.php?add=<?= $p['id'] ?>"
                 class="btn btn-accent btn-sm" style="margin-top:.3rem;font-size:.73rem">
                + Adicionar ao pedido
              </a>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endforeach; ?>

  <?php if (empty($porCategoria)): ?>
    <div class="empty-state" style="margin-top:3rem">
      <div class="empty-icon">🍽️</div>
      <h3>Cardápio em atualização</h3>
      <p>Volte em breve para conferir nossos pratos disponíveis.</p>
    </div>
  <?php endif; ?>

</div><!-- /cardapio-page -->

<script>
function filtrarCat(cat, btn) {
  // Atualiza botões
  document.querySelectorAll('.cat-filter').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  // Filtra seções
  document.querySelectorAll('.cat-section').forEach(sec => {
    sec.style.display = (cat === 'todas' || sec.dataset.cat === cat) ? '' : 'none';
  });
}
</script>
</body>
</html>
