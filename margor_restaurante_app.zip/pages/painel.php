<?php
require_once '../includes/auth.php';
requireLogin();

$perfil = usuarioAtual()['perfil'] ?? '';

$destino = match($perfil) {
    'Administrador' => 'admin/painel.php',
    'Gerente'       => 'gerente/painel.php',
    'Garçom'        => 'garcom/painel.php',
    'Cozinheiro'    => 'cozinheiro/painel.php',
    'Caixa'         => 'caixa/painel.php',
    default         => '../index.php',
};

header('Location: ' . $destino);
exit;
