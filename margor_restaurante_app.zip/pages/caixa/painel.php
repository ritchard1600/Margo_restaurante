<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Caixa') {
    header('Location: ../painel.php'); exit;
}

$db = getDB();

// Fechar pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fechar_pedido'])) {
    $pid = (int)$_POST['pedido_id'];
    $db->prepare("UPDATE pedidos SET status='Entregue' WHERE id=?")->execute([$pid]);
    header('Location: painel.php?ok=1'); exit;
}

// Pedidos prontos
$prontos = $db->query(
    "SELECT p.id, p.total, p.criado_em, p.observacao, c.nome AS cliente
     FROM pedidos p JOIN clientes c ON c.id=p.cliente_id
     WHERE p.status = 'Pronto'
     ORDER BY p.criado_em ASC"
)->fetchAll();

// Receita do dia
$receitaHoje = $db->query(
    "SELECT COALESCE(SUM(total),0) FROM pedidos WHERE DATE(criado_em)=CURDATE() AND status='Entregue'"
)->fetchColumn();

$entreguesHoje = $db->query(
    "SELECT COUNT(*) FROM pedidos WHERE DATE(criado_em)=CURDATE() AND status='Entregue'"
)->fetchColumn();

// Últimos entregues
$ultimosEntregues = $db->query(
    "SELECT p.id, p.total, p.criado_em, c.nome AS cliente
     FROM pedidos p JOIN clientes c ON c.id=p.cliente_id
     WHERE p.status='Entregue' AND DATE(p.criado_em)=CURDATE()
     ORDER BY p.criado_em DESC LIMIT 8"
)->fetchAll();

$tituloPagina = 'Caixa';
$paginaAtiva  = 'caixa';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
.caixa-grid { display:grid; grid-template-columns:1fr 1fr; gap:1.4rem; }
.pronto-card {
  background:var(--surface);
  border:2px solid rgba(74,124,89,0.35);
  border-radius:var(--radius-lg);
  padding:1.2rem;
  display:flex; flex-direction:column; gap:.8rem;
}
.pronto-card-header { display:flex; align-items:center; justify-content:space-between; }
.pronto-total {
  font-family:var(--font-display);
  font-size:1.6rem;
  color:var(--gold);
}
@media (max-width:700px) { .caixa-grid { grid-template-columns:1fr; } }
</style>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div>
      <h1>💰 Caixa</h1>
      <p>Gerencie pagamentos e fechamentos do dia</p>
    </div>
  </div>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">✅ Pedido fechado com sucesso!</div>
  <?php endif; ?>

  <!-- KPIs do dia -->
  <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:1.5rem">
    <div class="stat-card destaque" style="border-left:3px solid var(--gold)">
      <div class="stat-icon">💰</div>
      <div class="stat-value" style="font-size:1.5rem;color:var(--gold)">
        R$ <?= number_format((float)$receitaHoje,2,',','.') ?>
      </div>
      <div class="stat-label">Receita hoje</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">✅</div>
      <div class="stat-value"><?= $entreguesHoje ?></div>
      <div class="stat-label">Pedidos entregues hoje</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">⏳</div>
      <div class="stat-value"><?= count($prontos) ?></div>
      <div class="stat-label">Aguardando fechamento</div>
    </div>
  </div>

  <div class="caixa-grid">

    <!-- Prontos para fechar -->
    <div>
      <div class="card-title" style="margin-bottom:1rem;font-family:var(--font-display);font-size:1rem;color:var(--text)">
        Pedidos prontos — aguardando pagamento
      </div>
      <?php if (empty($prontos)): ?>
        <div class="empty-state" style="padding:2.5rem;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg)">
          <div class="empty-icon">✅</div>
          <h3>Tudo fechado!</h3>
          <p>Nenhum pedido aguardando pagamento.</p>
        </div>
      <?php else: ?>
        <?php foreach ($prontos as $p): ?>
        <div class="pronto-card" style="margin-bottom:1rem">
          <div class="pronto-card-header">
            <div>
              <span style="font-size:.75rem;color:var(--muted)">Pedido</span>
              <span style="font-weight:700;font-size:1.05rem;color:var(--text);margin-left:.3rem">#<?= $p['id'] ?></span>
              <span class="badge badge-pronto" style="margin-left:.5rem">Pronto</span>
            </div>
            <div class="pronto-total">R$ <?= number_format((float)$p['total'],2,',','.') ?></div>
          </div>
          <div style="font-size:.85rem;color:var(--text-2)">
            👤 <?= htmlspecialchars($p['cliente']) ?>
            <span style="color:var(--muted);font-size:.78rem;margin-left:.5rem">
              · <?= date('H:i',strtotime($p['criado_em'])) ?>
            </span>
          </div>
          <?php if ($p['observacao']): ?>
            <div style="font-size:.8rem;color:var(--muted)">📝 <?= htmlspecialchars($p['observacao']) ?></div>
          <?php endif; ?>
          <form method="POST">
            <input type="hidden" name="fechar_pedido" value="1">
            <input type="hidden" name="pedido_id"     value="<?= $p['id'] ?>">
            <button type="submit" class="btn btn-primary btn-full"
                    onclick="return confirm('Confirmar pagamento do pedido #<?= $p['id'] ?>?')">
              💳 Confirmar pagamento e entregar
            </button>
          </form>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Histórico do dia -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title">Entregues hoje</div>
      <?php if (empty($ultimosEntregues)): ?>
        <p style="color:var(--muted);font-size:.88rem">Nenhum pedido entregue ainda hoje.</p>
      <?php else: ?>
      <div class="table-wrap" style="border:none">
        <table>
          <thead><tr><th>#</th><th>Cliente</th><th>Hora</th><th>Total</th></tr></thead>
          <tbody>
          <?php foreach ($ultimosEntregues as $p): ?>
          <tr>
            <td style="color:var(--muted);font-size:.8rem">#<?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['cliente']) ?></td>
            <td style="font-size:.82rem;color:var(--muted)"><?= date('H:i',strtotime($p['criado_em'])) ?></td>
            <td style="color:var(--gold);font-family:var(--font-display)">R$ <?= number_format((float)$p['total'],2,',','.') ?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

  </div>

  </main>
</div>
</body>
</html>
