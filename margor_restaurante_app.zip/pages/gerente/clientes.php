<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Gerente') { header('Location: ../painel.php'); exit; }
$db=getDB();
$busca=trim($_GET['busca']??'');
$where="WHERE senha IS NOT NULL"; $params=[];
if($busca){ $where.=" AND (nome LIKE ? OR email LIKE ? OR telefone LIKE ?)"; $like="%$busca%"; $params=[$like,$like,$like]; }
$stmt=$db->prepare("SELECT c.*,(SELECT COUNT(*) FROM reservas r WHERE r.cliente_id=c.id) AS total_reservas,(SELECT COUNT(*) FROM pedidos p WHERE p.cliente_id=c.id) AS total_pedidos FROM clientes c $where ORDER BY c.criado_em DESC");
$stmt->execute($params); $clientes=$stmt->fetchAll();
$tituloPagina='Clientes'; $paginaAtiva='clientes'; $cssPath='../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
  <div class="page-header"><h1>Clientes</h1><p><?= count($clientes) ?> cadastrado<?= count($clientes)!==1?'s':'' ?> — <span style="color:#7bafd4;font-size:.82rem">👁️ Somente leitura</span></p></div>
  <form method="GET" style="display:flex;gap:.6rem;margin-bottom:1.4rem">
    <div class="form-group" style="margin:0;flex:1;max-width:360px">
      <input type="text" name="busca" placeholder="Buscar por nome, e-mail ou telefone..." value="<?= htmlspecialchars($busca) ?>" style="padding:.5rem .8rem">
    </div>
    <button type="submit" class="btn btn-primary btn-sm">Buscar</button>
    <?php if($busca): ?><a href="clientes.php" class="btn btn-ghost btn-sm">Limpar</a><?php endif; ?>
  </form>
  <?php if(empty($clientes)): ?>
    <div class="empty-state"><div class="empty-icon">👥</div><h3>Nenhum cliente</h3></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Reservas</th><th>Pedidos</th><th>Cadastrado em</th></tr></thead>
    <tbody>
    <?php foreach($clientes as $c): ?>
    <tr>
      <td style="font-weight:500"><?= htmlspecialchars($c['nome']) ?></td>
      <td style="font-size:.85rem"><?= htmlspecialchars($c['email']??'—') ?></td>
      <td style="font-size:.85rem"><?= htmlspecialchars($c['telefone']??'—') ?></td>
      <td style="text-align:center"><?= $c['total_reservas'] ?></td>
      <td style="text-align:center"><?= $c['total_pedidos'] ?></td>
      <td style="font-size:.82rem;color:var(--muted)"><?= date('d/m/Y',strtotime($c['criado_em'])) ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
  </main></div></body></html>
