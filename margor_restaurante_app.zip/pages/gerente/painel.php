<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Gerente') { header('Location: ../painel.php'); exit; }

$db = getDB();

$totalReservas  = $db->query("SELECT COUNT(*) FROM reservas")->fetchColumn();
$reservasHoje   = $db->query("SELECT COUNT(*) FROM reservas WHERE data_reserva = CURDATE()")->fetchColumn();
$pedidosAbertos = $db->query("SELECT COUNT(*) FROM pedidos WHERE status NOT IN ('Entregue','Cancelado')")->fetchColumn();
$totalClientes  = $db->query("SELECT COUNT(*) FROM clientes WHERE senha IS NOT NULL")->fetchColumn();
$receitaHoje    = $db->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE DATE(criado_em)=CURDATE() AND status='Entregue'")->fetchColumn();
$receitaMes     = $db->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE MONTH(criado_em)=MONTH(CURDATE()) AND YEAR(criado_em)=YEAR(CURDATE()) AND status='Entregue'")->fetchColumn();

$ultimasReservas = $db->query("SELECT nome, data_reserva, hora_reserva, pessoas, status FROM reservas ORDER BY criado_em DESC LIMIT 6")->fetchAll();
$pedidosAtivos   = $db->query("SELECT p.id, c.nome AS cliente, p.status, p.total FROM pedidos p JOIN clientes c ON c.id=p.cliente_id WHERE p.status NOT IN ('Entregue','Cancelado') ORDER BY p.criado_em DESC LIMIT 6")->fetchAll();

$tituloPagina = 'Painel Gerente';
$paginaAtiva  = 'painel';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
.readonly-badge {
  display:inline-flex;align-items:center;gap:.4rem;
  background:rgba(61,107,142,0.12);border:1px solid rgba(61,107,142,0.3);
  border-radius:99px;padding:.25rem .8rem;font-size:.72rem;color:#7bafd4;
  margin-bottom:1.2rem;
}
.kpi-grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:1rem;margin-bottom:1.5rem}
.kpi2{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.3rem 1.1rem;transition:border-color .2s}
.kpi2:hover{border-color:var(--border-gold)}
.kpi2.gold{border-left:3px solid var(--gold)}
.kpi2 .ico{font-size:1.5rem;margin-bottom:.4rem}
.kpi2 .val{font-family:var(--font-display);font-size:1.8rem;font-weight:700;color:var(--text);line-height:1;margin-bottom:.2rem}
.kpi2 .lbl{font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
.duas{display:grid;grid-template-columns:1fr 1fr;gap:1.4rem}
@media(max-width:700px){.duas{grid-template-columns:1fr}}
</style>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div>
      <h1>Visão geral</h1>
      <p>Olá, <?= htmlspecialchars(explode(' ',usuarioAtual()['nome'])[0]) ?>! — <?= date('d/m/Y') ?></p>
    </div>
    <div class="readonly-badge">👁️ Modo somente leitura</div>
  </div>

  <div class="kpi-grid2">
    <div class="kpi2 gold"><div class="ico">💰</div><div class="val" style="font-size:1.4rem;color:var(--gold)">R$ <?= number_format((float)$receitaHoje,2,',','.') ?></div><div class="lbl">Receita hoje</div></div>
    <div class="kpi2 gold"><div class="ico">📈</div><div class="val" style="font-size:1.4rem;color:var(--gold)">R$ <?= number_format((float)$receitaMes,2,',','.') ?></div><div class="lbl">Receita no mês</div></div>
    <div class="kpi2"><div class="ico">📅</div><div class="val"><?= $reservasHoje ?></div><div class="lbl">Reservas hoje</div></div>
    <div class="kpi2"><div class="ico">🧾</div><div class="val"><?= $pedidosAbertos ?></div><div class="lbl">Pedidos em aberto</div></div>
    <div class="kpi2"><div class="ico">👥</div><div class="val"><?= $totalClientes ?></div><div class="lbl">Clientes</div></div>
    <div class="kpi2"><div class="ico">📋</div><div class="val"><?= $totalReservas ?></div><div class="lbl">Total reservas</div></div>
  </div>

  <div class="duas">
    <div class="card" style="margin-bottom:0">
      <div class="card-title" style="display:flex;justify-content:space-between">
        📅 Reservas recentes
        <a href="reservas.php" style="font-size:.76rem;color:var(--gold)">Ver todas →</a>
      </div>
      <div class="table-wrap" style="border:none">
        <table><thead><tr><th>Nome</th><th>Data</th><th>Pess.</th><th>Status</th></tr></thead><tbody>
        <?php foreach ($ultimasReservas as $r):
          $b=match($r['status']){'Confirmada'=>'confirmada','Cancelada'=>'cancelada','Concluída'=>'concluida',default=>'pendente'}; ?>
        <tr>
          <td style="font-weight:500"><?= htmlspecialchars($r['nome']) ?></td>
          <td style="font-size:.82rem"><?= date('d/m',strtotime($r['data_reserva'])) ?> <?= substr($r['hora_reserva'],0,5) ?></td>
          <td>👥 <?= $r['pessoas'] ?></td>
          <td><span class="badge badge-<?= $b ?>"><?= $r['status'] ?></span></td>
        </tr>
        <?php endforeach; ?>
        </tbody></table>
      </div>
    </div>
    <div class="card" style="margin-bottom:0">
      <div class="card-title" style="display:flex;justify-content:space-between">
        🧾 Pedidos em aberto
        <a href="pedidos.php" style="font-size:.76rem;color:var(--gold)">Ver todos →</a>
      </div>
      <div class="table-wrap" style="border:none">
        <table><thead><tr><th>#</th><th>Cliente</th><th>Status</th><th>Total</th></tr></thead><tbody>
        <?php foreach ($pedidosAtivos as $p):
          $bm=['Aguardando'=>'aguardando','Em preparo'=>'preparo','Pronto'=>'pronto'];
          $b=$bm[$p['status']]??'aguardando'; ?>
        <tr>
          <td style="color:var(--muted);font-size:.8rem">#<?= $p['id'] ?></td>
          <td><?= htmlspecialchars($p['cliente']) ?></td>
          <td><span class="badge badge-<?= $b ?>"><?= $p['status'] ?></span></td>
          <td style="color:var(--gold);font-family:var(--font-display)">R$ <?= number_format((float)$p['total'],2,',','.') ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody></table>
      </div>
    </div>
  </div>

  <div class="card" style="margin-top:1.4rem">
    <div class="card-title">Acesso rápido (somente leitura)</div>
    <div style="display:flex;gap:.8rem;flex-wrap:wrap">
      <a href="relatorios.php" class="btn btn-outline">📊 Relatórios</a>
      <a href="clientes.php"   class="btn btn-outline">👥 Clientes</a>
      <a href="pedidos.php"    class="btn btn-outline">🧾 Pedidos</a>
      <a href="reservas.php"   class="btn btn-outline">📅 Reservas</a>
    </div>
  </div>

  </main>
</div>
</body>
</html>
