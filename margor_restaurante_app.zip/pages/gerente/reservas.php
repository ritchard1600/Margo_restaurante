<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Gerente') { header('Location: ../painel.php'); exit; }
$db = getDB();

$filtroData   = $_GET['data']   ?? date('Y-m-d');
$filtroStatus = $_GET['status'] ?? 'todas';
$where = 'WHERE 1=1'; $params = [];
if ($filtroData)               { $where .= ' AND r.data_reserva = ?'; $params[] = $filtroData; }
if ($filtroStatus !== 'todas') { $where .= ' AND r.status = ?';       $params[] = ucfirst($filtroStatus); }
$stmt = $db->prepare("SELECT r.*, c.nome AS cliente_nome FROM reservas r LEFT JOIN clientes c ON c.id=r.cliente_id $where ORDER BY r.data_reserva ASC, r.hora_reserva ASC");
$stmt->execute($params);
$reservas = $stmt->fetchAll();

$tituloPagina='Reservas'; $paginaAtiva='reservas'; $cssPath='../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div><h1>Reservas</h1><p><?= count($reservas) ?> resultado(s) — <span style="color:#7bafd4;font-size:.82rem">👁️ Somente leitura</span></p></div>
  </div>
  <form method="GET" style="display:flex;gap:.8rem;flex-wrap:wrap;align-items:flex-end;margin-bottom:1.4rem">
    <div class="form-group" style="margin:0"><label style="font-size:.75rem">Data</label>
      <input type="date" name="data" value="<?= htmlspecialchars($filtroData) ?>" style="padding:.4rem .7rem;font-size:.88rem"></div>
    <div class="form-group" style="margin:0"><label style="font-size:.75rem">Status</label>
      <select name="status" style="padding:.4rem .7rem;font-size:.88rem">
        <?php foreach(['todas','Pendente','Confirmada','Cancelada','Concluída'] as $s): ?>
          <option value="<?= strtolower($s) ?>" <?= strtolower($filtroStatus)===strtolower($s)?'selected':'' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select></div>
    <button type="submit" class="btn btn-primary btn-sm">Filtrar</button>
    <a href="reservas.php" class="btn btn-ghost btn-sm">Limpar</a>
  </form>
  <?php if(empty($reservas)): ?>
    <div class="empty-state"><div class="empty-icon">📅</div><h3>Nenhuma reserva encontrada</h3></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>#</th><th>Nome</th><th>Data / Hora</th><th>Pessoas</th><th>Origem</th><th>Cliente</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach($reservas as $r):
      $b=match($r['status']){'Confirmada'=>'confirmada','Cancelada'=>'cancelada','Concluída'=>'concluida',default=>'pendente'}; ?>
    <tr>
      <td style="color:var(--muted);font-size:.8rem">#<?= $r['id'] ?></td>
      <td style="font-weight:500"><?= htmlspecialchars($r['nome']) ?></td>
      <td><?= date('d/m/Y',strtotime($r['data_reserva'])) ?> <?= substr($r['hora_reserva'],0,5) ?></td>
      <td>👥 <?= $r['pessoas'] ?></td>
      <td style="font-size:.82rem"><?= $r['origem']==='online'?'🌐 Online':'🏠 Interno' ?></td>
      <td style="font-size:.82rem;color:var(--muted)"><?= $r['cliente_nome']?htmlspecialchars($r['cliente_nome']):'—' ?></td>
      <td><span class="badge badge-<?= $b ?>"><?= $r['status'] ?></span></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
  </main></div></body></html>
