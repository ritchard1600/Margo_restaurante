<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Gerente') { header('Location: ../painel.php'); exit; }
$db = getDB();

$filtroStatus = $_GET['status'] ?? 'todos';
$where='WHERE 1=1'; $params=[];
if ($filtroStatus!=='todos') { $where.=' AND p.status=?'; $params[]=ucfirst($filtroStatus); }
$pedidos=$db->prepare("SELECT p.id,p.status,p.total,p.observacao,p.criado_em,c.nome AS cliente FROM pedidos p JOIN clientes c ON c.id=p.cliente_id $where ORDER BY p.criado_em DESC");
$pedidos->execute($params); $pedidos=$pedidos->fetchAll();

$itensPorPedido=[];
if(!empty($pedidos)){
  $ids=implode(',',array_column($pedidos,'id'));
  foreach($db->query("SELECT ip.pedido_id,pr.nome,ip.quantidade,ip.preco_unit,ip.subtotal FROM itens_pedido ip JOIN pratos pr ON pr.id=ip.prato_id WHERE ip.pedido_id IN ($ids)")->fetchAll() as $it)
    $itensPorPedido[$it['pedido_id']][]=$it;
}
$tituloPagina='Pedidos'; $paginaAtiva='pedidos'; $cssPath='../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
.pedido-itens{display:none;background:var(--bg);padding:.8rem 1rem;border-top:1px solid var(--border)}
.pedido-itens.open{display:block}
.itens-mini td{padding:.3rem .5rem;font-size:.83rem;color:var(--text-2);border-bottom:1px solid var(--border)}
.itens-mini td:last-child{text-align:right;color:var(--gold)}
</style>
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div><h1>Pedidos</h1><p><?= count($pedidos) ?> pedido<?= count($pedidos)!==1?'s':'' ?> — <span style="color:#7bafd4;font-size:.82rem">👁️ Somente leitura</span></p></div>
  </div>
  <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.4rem">
    <?php foreach(['todos'=>'Todos','Aguardando'=>'Aguardando','Em preparo'=>'Em preparo','Pronto'=>'Pronto','Entregue'=>'Entregue','Cancelado'=>'Cancelado'] as $val=>$lbl): ?>
      <a href="?status=<?= urlencode($val) ?>" class="btn btn-sm <?= $filtroStatus===$val?'btn-primary':'btn-ghost' ?>"><?= $lbl ?></a>
    <?php endforeach; ?>
  </div>
  <?php if(empty($pedidos)): ?>
    <div class="empty-state"><div class="empty-icon">🧾</div><h3>Nenhum pedido</h3></div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>#</th><th>Cliente</th><th>Status</th><th>Total</th><th>Data</th></tr></thead>
    <tbody>
    <?php foreach($pedidos as $p):
      $bm=['Aguardando'=>'aguardando','Em preparo'=>'preparo','Pronto'=>'pronto','Entregue'=>'entregue','Cancelado'=>'cancelada'];
      $b=$bm[$p['status']]??'aguardando';
      $itens=$itensPorPedido[$p['id']]??[];
    ?>
    <tr style="cursor:pointer" onclick="document.getElementById('it<?= $p['id'] ?>').classList.toggle('open')">
      <td style="color:var(--muted);font-size:.8rem">#<?= $p['id'] ?></td>
      <td style="font-weight:500"><?= htmlspecialchars($p['cliente']) ?></td>
      <td><span class="badge badge-<?= $b ?>"><?= $p['status'] ?></span></td>
      <td style="font-family:var(--font-display);color:var(--gold)">R$ <?= number_format((float)$p['total'],2,',','.') ?></td>
      <td style="font-size:.8rem;color:var(--muted)"><?= date('d/m/Y H:i',strtotime($p['criado_em'])) ?></td>
    </tr>
    <tr><td colspan="5" style="padding:0;border-bottom:1px solid var(--border)">
      <div class="pedido-itens" id="it<?= $p['id'] ?>">
        <?php if(!empty($itens)): ?>
        <table class="itens-mini" style="width:100%;border-collapse:collapse">
          <?php foreach($itens as $it): ?>
          <tr><td><?= htmlspecialchars($it['nome']) ?></td><td><?= $it['quantidade'] ?>×</td><td>R$ <?= number_format((float)$it['subtotal'],2,',','.') ?></td></tr>
          <?php endforeach; ?>
        </table>
        <?php endif; ?>
      </div>
    </td></tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
  </main></div></body></html>
