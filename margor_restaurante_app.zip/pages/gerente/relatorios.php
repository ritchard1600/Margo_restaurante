<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Gerente') { header('Location: ../painel.php'); exit; }
// Reutiliza o relatório do admin (somente leitura — sem botões de ação)
include '../../pages/admin/relatorios.php';
