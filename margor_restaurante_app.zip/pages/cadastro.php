<?php
require_once '../includes/auth.php';

if (clienteLogado()) { header('Location: cliente/painel.php'); exit; }
if (usuarioLogado())  { header('Location: painel.php'); exit; }

$erro  = '';
$dados = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Limpar máscara do telefone antes de salvar
    $telefone = preg_replace('/\D/', '', $_POST['telefone'] ?? '');
    $telefone = strlen($telefone) >= 10 ? $telefone : '';

    $dados = [
        'nome'            => trim($_POST['nome'] ?? ''),
        'email'           => trim($_POST['email'] ?? ''),
        'senha'           => $_POST['senha'] ?? '',
        'senha2'          => $_POST['senha2'] ?? '',
        'telefone'        => $_POST['telefone'] ?? '', // mantém formatado para repopular
        'telefone_limpo'  => $telefone,
        'data_nascimento' => $_POST['data_nascimento'] ?? '',
    ];

    if (!$dados['nome'] || !$dados['email'] || !$dados['senha']) {
        $erro = 'Preencha os campos obrigatórios (nome, e-mail e senha).';
    } elseif (!filter_var($dados['email'], FILTER_VALIDATE_EMAIL)) {
        $erro = 'Informe um e-mail válido.';
    } elseif (strlen($dados['senha']) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($dados['senha'] !== $dados['senha2']) {
        $erro = 'As senhas não conferem.';
    } else {
        $resultado = cadastrarCliente([
            'nome'            => $dados['nome'],
            'email'           => $dados['email'],
            'senha'           => $dados['senha'],
            'senha2'          => $dados['senha2'],
            'telefone'        => $telefone,
            'data_nascimento' => $dados['data_nascimento'],
        ]);
        if ($resultado === true) {
            header('Location: cliente/painel.php?boas_vindas=1');
            exit;
        } else {
            $erro = $resultado;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Criar conta — RestauranteApp</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    /* Garante que o picker de nascimento fique dentro do card */
    .np-cal { max-width: 100%; }
    @media (max-width: 480px) {
      .np-cal { width: 260px; }
    }
  </style>

<style>
.senha-wrap { position: relative; }
.senha-wrap input { padding-right: 2.8rem; }
.btn-eye {
  position: absolute;
  right: .7rem; top: 50%;
  transform: translateY(-50%);
  background: none; border: none;
  color: var(--muted); cursor: pointer;
  font-size: 1rem; line-height: 1;
  padding: .2rem; transition: color .2s;
}
.btn-eye:hover { color: var(--gold); }
</style>
</head>
<body>
<div class="auth-page">
  <div style="width:100%;max-width:460px;position:relative;z-index:1">

    <a href="../index.php" class="auth-back">← Voltar ao início</a>

    <div class="auth-card">
      <div class="auth-logo">
        <div class="auth-logo-icon">🍽️</div>
        <h1>Criar conta</h1>
        <p>Acesse o cardápio e gerencie suas reservas</p>
      </div>

      <div class="auth-tabs">
        <a href="login-cliente.php" class="auth-tab">Entrar</a>
        <a href="#" class="auth-tab active">Criar conta</a>
      </div>

      <?php if ($erro): ?>
        <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="POST" novalidate>

        <!-- Nome -->
        <div class="form-group">
          <label>Nome completo <span style="color:var(--gold)">*</span></label>
          <input type="text" name="nome"
                 placeholder="Seu nome completo"
                 value="<?= htmlspecialchars($dados['nome'] ?? '') ?>"
                 required autofocus>
        </div>

        <!-- E-mail -->
        <div class="form-group">
          <label>E-mail <span style="color:var(--gold)">*</span></label>
          <input type="email" name="email"
                 placeholder="voce@email.com"
                 value="<?= htmlspecialchars($dados['email'] ?? '') ?>"
                 required>
        </div>

        <!-- Senha -->
        <div class="form-row">
          <div class="form-group">
            <label>Senha <span style="color:var(--gold)">*</span></label>
            <div class="senha-wrap">
            <input type="password" name="senha" placeholder="Mín. 6 caracteres" required>
              <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
            </div>
          </div>
          <div class="form-group">
            <label>Confirmar senha <span style="color:var(--gold)">*</span></label>
            <div class="senha-wrap">
            <input type="password" name="senha2" placeholder="••••••" required>
              <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
            </div>
          </div>
        </div>

        <!-- Telefone com máscara -->
        <div class="form-group">
          <label>Telefone</label>
          <input type="tel" name="telefone"
                 placeholder="(00) 00000-0000"
                 value="<?= htmlspecialchars($dados['telefone'] ?? '') ?>"
                 data-tel-mask
                 maxlength="16"
                 autocomplete="tel">
          <small style="font-size:.74rem;color:var(--muted);margin-top:.3rem;display:block">
            Digite apenas os números — a formatação é automática
          </small>
        </div>

        <!-- Data de nascimento — picker visual -->
        <div class="form-group">
          <label>Data de nascimento</label>
          <div data-nasc-picker>
            <input type="date" name="data_nascimento" data-nasc-input
                   value="<?= htmlspecialchars($dados['data_nascimento'] ?? '') ?>">
          </div>
          <small style="font-size:.74rem;color:var(--muted);margin-top:.3rem;display:block">
            Clique para abrir o calendário
          </small>
        </div>

        <button type="submit" class="btn btn-primary btn-full" style="margin-top:.4rem">
          Criar minha conta
        </button>
      </form>

      <div class="visitor-bar">
        <p>Prefere navegar sem conta?</p>
        <div style="display:flex;gap:.6rem;justify-content:center;flex-wrap:wrap">
          <a href="reserva.php"          class="btn btn-outline btn-sm">📅 Fazer reserva</a>
          <a href="cardapio-publico.php" class="btn btn-ghost btn-sm">🍴 Ver cardápio</a>
        </div>
      </div>
    </div>

  </div>
</div>
<script src="../assets/js/nascimento-picker.js"></script>

<script>
function toggleSenha(btn) {
  const inp = btn.closest('.senha-wrap').querySelector('input');
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  btn.textContent = show ? '🙈' : '👁️';
}
</script>
</body>
</html>
