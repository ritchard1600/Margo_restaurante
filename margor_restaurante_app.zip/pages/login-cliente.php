<?php
require_once '../includes/auth.php';

if (clienteLogado()) { header('Location: cliente/painel.php'); exit; }
if (usuarioLogado())  { header('Location: painel.php'); exit; }

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');
    if ($email && $senha) {
        if (loginCliente($email, $senha)) {
            $redir = $_GET['redir'] ?? 'cliente/painel.php';
            header('Location: ' . $redir);
            exit;
        } else {
            $erro = 'E-mail ou senha incorretos.';
        }
    } else {
        $erro = 'Preencha todos os campos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Entrar — RestauranteApp</title>
  <link rel="stylesheet" href="../assets/css/style.css">

<style>
.senha-wrap { position: relative; }
.senha-wrap input { padding-right: 2.8rem; }
.btn-eye {
  position: absolute;
  right: .7rem; top: 50%;
  transform: translateY(-50%);
  background: none; border: none;
  color: var(--muted); cursor: pointer;
  font-size: 1rem; line-height: 1;
  padding: .2rem; transition: color .2s;
}
.btn-eye:hover { color: var(--gold); }
</style>
</head>
<body>
<div class="auth-page">
  <div style="width:100%;max-width:420px;position:relative;z-index:1">

    <a href="../index.php" class="auth-back">← Voltar ao início</a>

    <div class="auth-card">
      <div class="auth-logo">
        <div class="auth-logo-icon">🍽️</div>
        <h1>Bem-vindo de volta</h1>
        <p>Acesse sua conta para reservas e pré-pedidos</p>
      </div>

      <div class="auth-tabs">
        <a href="#" class="auth-tab active">Entrar</a>
        <a href="cadastro.php" class="auth-tab">Criar conta</a>
      </div>


      <?php if ($erro): ?>
        <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="POST" novalidate>
        <div class="form-group">
          <label>E-mail</label>
          <input type="email" name="email" placeholder="seu@email.com"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                 required autofocus>
        </div>
        <div class="form-group">
          <label>Senha</label>
          <div class="senha-wrap">
          <input type="password" name="senha" placeholder="••••••" required>
            <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-full" style="margin-top:.3rem">
          Entrar na minha conta
        </button>
      </form>

      <div class="visitor-bar">
        <p>Prefere navegar sem conta?</p>
        <div style="display:flex;gap:.6rem;justify-content:center;flex-wrap:wrap">
          <a href="reserva.php"          class="btn btn-outline btn-sm">📅 Fazer reserva</a>
          <a href="cardapio-publico.php" class="btn btn-ghost btn-sm">🍴 Ver cardápio</a>
        </div>
      </div>
    </div>

  </div>
</div>

<script>
function toggleSenha(btn) {
  const inp = btn.closest('.senha-wrap').querySelector('input');
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  btn.textContent = show ? '🙈' : '👁️';
}
</script>
</body>
</html>
