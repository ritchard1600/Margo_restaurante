<?php
require_once '../includes/auth.php';

if (usuarioLogado())  { header('Location: painel.php'); exit; }
if (clienteLogado())  { header('Location: cliente/painel.php'); exit; }

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');
    if ($email && $senha) {
        if (login($email, $senha)) {
            header('Location: painel.php');
            exit;
        } else {
            $erro = 'Credenciais incorretas ou acesso não autorizado.';
        }
    } else {
        $erro = 'Preencha todos os campos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Acesso Interno — RestauranteApp</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .admin-page::before {
      background: radial-gradient(ellipse 50% 40% at 50% 0%, rgba(255,255,255,0.02) 0%, transparent 70%);
    }
    .lock-icon {
      width: 52px; height: 52px;
      background: rgba(255,255,255,0.05);
      border: 1px solid var(--border);
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 1.4rem;
      margin: 0 auto .8rem;
    }
    .perfil-chips {
      display: flex;
      flex-wrap: wrap;
      gap: .4rem;
      justify-content: center;
      margin-top: .8rem;
    }
    .perfil-chip {
      padding: .2rem .65rem;
      border-radius: 99px;
      font-size: .7rem;
      border: 1px solid var(--border);
      color: var(--muted);
      background: rgba(255,255,255,0.03);
    }
  </style>

<style>
.senha-wrap { position: relative; }
.senha-wrap input { padding-right: 2.8rem; }
.btn-eye {
  position: absolute;
  right: .7rem; top: 50%;
  transform: translateY(-50%);
  background: none; border: none;
  color: var(--muted); cursor: pointer;
  font-size: 1rem; line-height: 1;
  padding: .2rem; transition: color .2s;
}
.btn-eye:hover { color: var(--gold); }
</style>
</head>
<body>
<div class="auth-page admin-page">
  <div style="width:100%;max-width:420px;position:relative;z-index:1">

    <a href="../index.php" class="auth-back">← Voltar ao site</a>

    <div class="auth-card admin-variant">

      <div class="auth-logo">
        <div class="lock-icon">🔒</div>
        <div class="admin-badge">
          🏠 Área restrita — equipe interna
        </div>
        <h1 style="font-size:1.5rem">Acesso da equipe</h1>
        <p>Entre com as credenciais fornecidas pela administração</p>
      </div>

      <?php if ($erro): ?>
        <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="POST" novalidate>
        <div class="form-group">
          <label>E-mail corporativo</label>
          <input type="email" name="email" placeholder="nome@restaurante.com"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                 required autofocus>
        </div>
        <div class="form-group">
          <label>Senha</label>
          <div class="senha-wrap">
          <input type="password" name="senha" placeholder="••••••" required>
            <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
          </div>
        </div>
        <button type="submit" class="btn btn-outline btn-full" style="margin-top:.3rem;color:var(--text)">
          Acessar painel interno
        </button>
      </form>

      <div style="text-align:center;margin-top:1.5rem">
        <p style="font-size:.74rem;color:var(--muted);margin-bottom:.6rem">Perfis com acesso:</p>
        <div class="perfil-chips">
          <span class="perfil-chip">👑 Administrador</span>
          <span class="perfil-chip">🍽️ Garçom</span>
          <span class="perfil-chip">👨‍🍳 Cozinheiro</span>
          <span class="perfil-chip">💰 Caixa</span>
        </div>
      </div>

      <p style="text-align:center;font-size:.72rem;color:var(--muted);margin-top:1.5rem;border-top:1px solid var(--border);padding-top:1rem">
        Demo: admin@restaurante.com / 123456
      </p>
    </div>

  </div>
</div>

<script>
function toggleSenha(btn) {
  const inp = btn.closest('.senha-wrap').querySelector('input');
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  btn.textContent = show ? '🙈' : '👁️';
}
</script>
</body>
</html>
