<?php
require_once '../../includes/auth.php';
logoutCliente();
