<?php
require_once '../../includes/auth.php';
requireCliente();

$db      = getDB();
$cliente = clienteAtual();
$id      = (int)$cliente['id'];

// Estatísticas rápidas
$totalReservas = $db->prepare("SELECT COUNT(*) FROM reservas WHERE cliente_id = ?");
$totalReservas->execute([$id]);
$qtdReservas = (int)$totalReservas->fetchColumn();

$proximaReserva = $db->prepare(
    "SELECT data_reserva, hora_reserva, pessoas, status
     FROM reservas
     WHERE cliente_id = ? AND data_reserva >= CURDATE() AND status NOT IN ('Cancelada')
     ORDER BY data_reserva ASC, hora_reserva ASC LIMIT 1"
);
$proximaReserva->execute([$id]);
$proxima = $proximaReserva->fetch();

$totalPedidos = $db->prepare("SELECT COUNT(*), COALESCE(SUM(total),0) FROM pedidos WHERE cliente_id = ?");
$totalPedidos->execute([$id]);
[$qtdPedidos, $valorTotal] = $totalPedidos->fetch(PDO::FETCH_NUM);

// Últimas reservas
$ultimasReservas = $db->prepare(
    "SELECT data_reserva, hora_reserva, pessoas, status
     FROM reservas WHERE cliente_id = ?
     ORDER BY data_reserva DESC, hora_reserva DESC LIMIT 5"
);
$ultimasReservas->execute([$id]);
$reservasRecentes = $ultimasReservas->fetchAll();

$boasVindas = isset($_GET['boas_vindas']);

$paginaAtiva = 'painel';
require_once '../../includes/auth.php'; // já incluído — só para garantir autoload
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel — RestauranteApp</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
<?php
$paginaAtiva = 'painel';
require_once '../../includes/cliente_layout.php';
?>

  <?php if ($boasVindas): ?>
    <div class="alert alert-success">
      🎉 Bem-vindo(a), <?= htmlspecialchars($cliente['nome']) ?>! Sua conta foi criada com sucesso.
    </div>
  <?php endif; ?>

  <div class="page-header">
    <h1>Olá, <?= htmlspecialchars(explode(' ', $cliente['nome'])[0]) ?>!</h1>
    <p>Veja um resumo da sua conta</p>
  </div>

  <!-- Estatísticas -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-icon">📅</div>
      <div class="stat-value"><?= $qtdReservas ?></div>
      <div class="stat-label">Reservas feitas</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">🧾</div>
      <div class="stat-value"><?= $qtdPedidos ?></div>
      <div class="stat-label">Pedidos realizados</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">💰</div>
      <div class="stat-value">R$&nbsp;<?= number_format((float)$valorTotal, 2, ',', '.') ?></div>
      <div class="stat-label">Total em pedidos</div>
    </div>
  </div>

  <!-- Próxima reserva -->
  <?php if ($proxima): ?>
  <div class="card" style="margin-bottom:1.5rem;border-left:4px solid var(--primary)">
    <div class="card-title">📌 Próxima reserva</div>
    <div style="display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap">
      <div>
        <span style="font-size:1.6rem;font-weight:700;font-family:'Playfair Display',serif;color:var(--primary)">
          <?= date('d/m/Y', strtotime($proxima['data_reserva'])) ?>
        </span>
        <span style="color:var(--muted);margin-left:.5rem"><?= substr($proxima['hora_reserva'],0,5) ?></span>
      </div>
      <div style="color:var(--muted);font-size:.9rem">
        👥 <?= $proxima['pessoas'] ?> pessoa<?= $proxima['pessoas'] > 1 ? 's' : '' ?>
      </div>
      <?php
        $badge = match($proxima['status']) {
          'Confirmada' => 'confirmada', 'Cancelada' => 'cancelada',
          'Concluída'  => 'concluida',  default => 'pendente'
        };
      ?>
      <span class="badge badge-<?= $badge ?>"><?= $proxima['status'] ?></span>
      <a href="reservas.php" class="btn btn-outline btn-sm" style="margin-left:auto">Ver todas</a>
    </div>
  </div>
  <?php else: ?>
  <div class="card" style="margin-bottom:1.5rem">
    <div class="card-title">Próxima reserva</div>
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.8rem">
      <span style="color:var(--muted)">Nenhuma reserva futura encontrada.</span>
      <a href="../reserva.php" class="btn btn-accent btn-sm">📅 Fazer reserva</a>
    </div>
  </div>
  <?php endif; ?>

  <!-- Atalhos -->
  <div class="card">
    <div class="card-title">Acesso rápido</div>
    <div style="display:flex;gap:.8rem;flex-wrap:wrap">
      <a href="cardapio.php"   class="btn btn-primary">🍴 Ver cardápio</a>
      <a href="../reserva.php" class="btn btn-accent">📅 Nova reserva</a>
      <a href="reservas.php"   class="btn btn-outline">📋 Minhas reservas</a>
      <a href="perfil.php"     class="btn btn-ghost">👤 Meu perfil</a>
    </div>
  </div>

  <?php if (!empty($reservasRecentes)): ?>
  <div class="card" style="margin-top:1.5rem">
    <div class="card-title">Histórico de reservas recentes</div>
    <div class="table-wrap" style="border:none">
      <table>
        <thead>
          <tr>
            <th>Data</th><th>Horário</th><th>Pessoas</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($reservasRecentes as $r): ?>
          <?php
            $b = match($r['status']) {
              'Confirmada' => 'confirmada', 'Cancelada' => 'cancelada',
              'Concluída'  => 'concluida',  default => 'pendente'
            };
          ?>
          <tr>
            <td><?= date('d/m/Y', strtotime($r['data_reserva'])) ?></td>
            <td><?= substr($r['hora_reserva'],0,5) ?></td>
            <td><?= $r['pessoas'] ?></td>
            <td><span class="badge badge-<?= $b ?>"><?= $r['status'] ?></span></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

  </main>
</div>
</body>
</html>
