<?php
require_once '../../includes/auth.php';
requireCliente();

$db      = getDB();
$cliente = clienteAtual();
$id      = (int)$cliente['id'];

$erro = '';
$ok   = false;
$aba  = $_GET['aba'] ?? 'dados'; // 'dados' ou 'senha'

// Busca dados atuais do banco
$stmt = $db->prepare("SELECT * FROM clientes WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$dados = $stmt->fetch();

// ── Salvar dados pessoais ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_dados'])) {
    $nome     = trim($_POST['nome'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $nasc     = $_POST['data_nascimento'] ?? '';

    if (!$nome) {
        $erro = 'O nome não pode ser vazio.';
    } else {
        $upd = $db->prepare(
            "UPDATE clientes SET nome = ?, telefone = ?, data_nascimento = ? WHERE id = ?"
        );
        $upd->execute([$nome, $telefone ?: null, $nasc ?: null, $id]);
        // Atualiza sessão
        $_SESSION['cliente']['nome']     = $nome;
        $_SESSION['cliente']['telefone'] = $telefone;
        $dados['nome']     = $nome;
        $dados['telefone'] = $telefone;
        $ok = 'Dados atualizados com sucesso!';
    }
}

// ── Alterar senha ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_senha'])) {
    $senhaAtual = $_POST['senha_atual']  ?? '';
    $novaSenha  = $_POST['nova_senha']   ?? '';
    $confirma   = $_POST['confirma']     ?? '';

    // Verifica senha atual
    $check = $db->prepare("SELECT id FROM clientes WHERE id = ? AND senha = MD5(?) LIMIT 1");
    $check->execute([$id, $senhaAtual]);

    if (!$check->fetch()) {
        $erro = 'Senha atual incorreta.';
    } elseif (strlen($novaSenha) < 6) {
        $erro = 'A nova senha deve ter pelo menos 6 caracteres.';
    } elseif ($novaSenha !== $confirma) {
        $erro = 'A nova senha e a confirmação não conferem.';
    } else {
        $upd = $db->prepare("UPDATE clientes SET senha = MD5(?) WHERE id = ?");
        $upd->execute([$novaSenha, $id]);
        $ok = 'Senha alterada com sucesso!';
    }
    $aba = 'senha';
}

$primeiraLetra = mb_strtoupper(mb_substr($dados['nome'], 0, 1));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meu Perfil — RestauranteApp</title>
  <link rel="stylesheet" href="../../assets/css/style.css">

<style>
.senha-wrap { position: relative; }
.senha-wrap input { padding-right: 2.8rem; }
.btn-eye {
  position: absolute;
  right: .7rem; top: 50%;
  transform: translateY(-50%);
  background: none; border: none;
  color: var(--muted); cursor: pointer;
  font-size: 1rem; line-height: 1;
  padding: .2rem; transition: color .2s;
}
.btn-eye:hover { color: var(--gold); }
</style>
</head>
<body>
<?php $paginaAtiva = 'perfil'; require_once '../../includes/cliente_layout.php'; ?>

  <div class="page-header">
    <h1>Meu Perfil</h1>
    <p>Gerencie seus dados e senha</p>
  </div>

  <!-- Avatar + info -->
  <div class="profile-header">
    <div class="profile-avatar"><?= htmlspecialchars($primeiraLetra) ?></div>
    <div>
      <div class="profile-info-name"><?= htmlspecialchars($dados['nome']) ?></div>
      <div class="profile-info-email"><?= htmlspecialchars($dados['email']) ?></div>
      <div style="font-size:.78rem;color:var(--muted);margin-top:.2rem">
        Cliente desde <?= date('d/m/Y', strtotime($dados['criado_em'])) ?>
      </div>
    </div>
  </div>

  <!-- Abas -->
  <div class="auth-tabs" style="margin-bottom:1.5rem">
    <a href="?aba=dados"  class="auth-tab <?= $aba === 'dados'  ? 'active' : '' ?>">Dados pessoais</a>
    <a href="?aba=senha"  class="auth-tab <?= $aba === 'senha'  ? 'active' : '' ?>">Alterar senha</a>
  </div>

  <?php if ($erro): ?>
    <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
  <?php endif; ?>
  <?php if ($ok): ?>
    <div class="alert alert-success">✅ <?= htmlspecialchars($ok) ?></div>
  <?php endif; ?>

  <!-- ── ABA: dados ── -->
  <?php if ($aba === 'dados'): ?>
  <div class="card">
    <div class="card-title">Informações pessoais</div>
    <form method="POST">
      <input type="hidden" name="salvar_dados" value="1">

      <div class="form-group">
        <label>Nome completo</label>
        <input type="text" name="nome" value="<?= htmlspecialchars($dados['nome']) ?>" required>
      </div>
      <div class="form-group">
        <label>E-mail</label>
        <input type="email" value="<?= htmlspecialchars($dados['email']) ?>" disabled
               style="background:var(--bg);color:var(--muted);cursor:not-allowed">
        <small style="color:var(--muted);font-size:.78rem">O e-mail não pode ser alterado.</small>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Telefone</label>
          <input type="tel" name="telefone" placeholder="(00) 00000-0000"
                 value="<?= htmlspecialchars($dados['telefone'] ?? '') ?>"
                 data-tel-mask maxlength="16">
        </div>
        <div class="form-group">
          <label>Data de nascimento</label>
          <div data-nasc-picker>
            <input type="date" name="data_nascimento" data-nasc-input
                   value="<?= htmlspecialchars($dados['data_nascimento'] ?? '') ?>">
          </div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">💾 Salvar alterações</button>
    </form>
  </div>

  <!-- ── ABA: senha ── -->
  <?php else: ?>
  <div class="card">
    <div class="card-title">Alterar senha</div>
    <form method="POST" style="max-width:380px">
      <input type="hidden" name="salvar_senha" value="1">
      <div class="form-group">
        <label>Senha atual</label>
        <div class="senha-wrap">
        <input type="password" name="senha_atual" placeholder="••••••" required>
          <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
        </div>
      </div>
      <div class="form-group">
        <label>Nova senha</label>
        <div class="senha-wrap">
        <input type="password" name="nova_senha" placeholder="Mín. 6 caracteres" required>
          <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
        </div>
      </div>
      <div class="form-group">
        <label>Confirmar nova senha</label>
        <div class="senha-wrap">
        <input type="password" name="confirma" placeholder="••••••" required>
          <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">🔒 Alterar senha</button>
    </form>
  </div>
  <?php endif; ?>

  </main>
</div>
<script src="../../assets/js/nascimento-picker.js"></script>

<script>
function toggleSenha(btn) {
  const inp = btn.closest('.senha-wrap').querySelector('input');
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  btn.textContent = show ? '🙈' : '👁️';
}
</script>
</body>
</html>
