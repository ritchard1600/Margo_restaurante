<?php
require_once '../../includes/auth.php';
requireCliente();

$db      = getDB();
$cliente = clienteAtual();
$cid     = (int)$cliente['id'];

// ── Processar envio do pré-pedido ──
$pedidoOk  = false;
$pedidoErr = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_pedido'])) {
    $reservaId  = !empty($_POST['reserva_id']) ? (int)$_POST['reserva_id'] : null;
    $observacao = trim($_POST['observacao'] ?? '');
    $itensJson  = $_POST['itens_json'] ?? '[]';
    $itens      = json_decode($itensJson, true);

    if (empty($itens)) {
        $pedidoErr = 'Adicione ao menos um prato ao pedido.';
    } else {
        // Calcula total
        $total = 0;
        $pratosDb = [];
        foreach ($itens as $item) {
            $s = $db->prepare("SELECT id, preco FROM pratos WHERE id=? AND status='Disponível'");
            $s->execute([(int)$item['id']]);
            $prato = $s->fetch();
            if ($prato) {
                $pratosDb[(int)$item['id']] = $prato;
                $total += $prato['preco'] * (int)$item['qty'];
            }
        }
        if (empty($pratosDb)) {
            $pedidoErr = 'Nenhum prato válido encontrado.';
        } else {
            // Precisa de um usuário responsável — usa o ID do garçom padrão (admin)
            $uidGarcom = $db->query("SELECT id FROM usuarios WHERE perfil='Administrador' LIMIT 1")->fetchColumn() ?: 1;

            $db->prepare(
                "INSERT INTO pedidos (cliente_id, usuario_id, reserva_id, status, observacao, total)
                 VALUES (?, ?, ?, 'Aguardando', ?, ?)"
            )->execute([$cid, $uidGarcom, $reservaId, $observacao ?: null, $total]);

            $pedidoId = (int)$db->lastInsertId();

            foreach ($itens as $item) {
                $pid = (int)$item['id'];
                if (!isset($pratosDb[$pid])) continue;
                $qty = max(1, (int)$item['qty']);
                $precoUnit = $pratosDb[$pid]['preco'];
                $db->prepare(
                    "INSERT INTO itens_pedido (pedido_id, prato_id, quantidade, preco_unit) VALUES (?,?,?,?)"
                )->execute([$pedidoId, $pid, $qty, $precoUnit]);
            }
            $pedidoOk = true;
        }
    }
}

// ── Dados para a página ──
$pratos = $db->query(
    "SELECT p.id, p.nome, p.descricao, p.preco, p.tempo_minutos, c.nome AS categoria, c.id AS cat_id
     FROM pratos p JOIN categorias_prato c ON c.id = p.categoria_id
     WHERE p.status = 'Disponível'
     ORDER BY c.nome, p.nome"
)->fetchAll();

$porCategoria = [];
$idsVistos = [];
foreach ($pratos as $p) {
    if (in_array($p['id'], $idsVistos)) continue;
    $idsVistos[] = $p['id'];
    $porCategoria[$p['categoria']][] = $p;
}

// Reservas futuras do cliente (para vincular)
$reservasFuturas = $db->prepare(
    "SELECT id, data_reserva, hora_reserva, pessoas, status
     FROM reservas
     WHERE cliente_id = ? AND data_reserva >= CURDATE() AND status IN ('Pendente','Confirmada')
     ORDER BY data_reserva ASC, hora_reserva ASC"
);
$reservasFuturas->execute([$cid]);
$reservas = $reservasFuturas->fetchAll();

$paginaAtiva = 'cardapio';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cardápio & Pré-pedido — RestauranteApp</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
  <style>
    .cardapio-wrap { max-width: 1200px; margin: 0 auto; }

    /* Card de prato — versão cliente */
    .prato-cli-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius-lg);
      padding: 1.4rem;
      display: flex;
      flex-direction: column;
      gap: .7rem;
      transition: border-color .2s, box-shadow .2s;
      position: relative;
    }
    .prato-cli-card.no-carrinho {
      border-color: var(--border-gold);
      box-shadow: 0 0 0 1px rgba(201,168,76,0.15);
    }
    .prato-cli-card:hover { border-color: var(--border-gold); }

    .prato-cli-nome { font-family: var(--font-display); font-size: 1.05rem; color: var(--text); }
    .prato-cli-desc { font-size: .81rem; color: var(--muted); line-height: 1.55; flex: 1; }
    .prato-cli-footer {
      display: flex; align-items: center; justify-content: space-between;
      padding-top: .7rem; border-top: 1px solid var(--border);
      gap: .5rem;
    }
    .prato-cli-preco { font-family: var(--font-display); font-size: 1.25rem; color: var(--gold); }

    /* Badges de categoria */
    .cat-badge {
      display: inline-block;
      padding: .15rem .55rem;
      border-radius: 99px;
      font-size: .67rem;
      letter-spacing: .1em;
      text-transform: uppercase;
      color: var(--gold);
      border: 1px solid var(--border-gold);
      background: var(--gold-dim2);
      margin-bottom: .2rem;
    }

    /* Modal confirmação */
    .modal-overlay {
      display: none;
      position: fixed; inset: 0;
      background: rgba(0,0,0,.7);
      z-index: 999;
      align-items: center; justify-content: center;
      padding: 1rem;
    }
    .modal-overlay.open { display: flex; }
    .modal-box {
      background: var(--surface);
      border: 1px solid var(--border-gold);
      border-radius: var(--radius-lg);
      padding: 2rem;
      max-width: 500px;
      width: 100%;
      box-shadow: var(--shadow);
    }
    .modal-box h2 { font-size: 1.3rem; margin-bottom: .6rem; color: var(--gold); }

    /* Sucesso */
    .pedido-ok-box {
      text-align: center;
      padding: 3rem 2rem;
      background: var(--surface);
      border: 1px solid rgba(74,124,89,0.3);
      border-radius: var(--radius-lg);
      margin-bottom: 1.5rem;
    }
    .pedido-ok-box .ok-icon { font-size: 3rem; margin-bottom: .8rem; }
    .pedido-ok-box h2 { font-size: 1.5rem; color: #7bc492; margin-bottom: .4rem; }
    .pedido-ok-box p { color: var(--text-2); font-size: .9rem; }

    /* Sticky sidebar mobile */
    .carrinho-fab {
      display: none;
      position: fixed;
      bottom: 1.5rem; right: 1.5rem;
      z-index: 60;
    }
    .carrinho-fab button {
      background: var(--gold);
      color: #0f0f0f;
      border: none;
      border-radius: 99px;
      padding: .8rem 1.4rem;
      font-size: .88rem;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 20px rgba(201,168,76,0.4);
      font-family: var(--font-body);
      display: flex; align-items: center; gap: .5rem;
    }
    .carrinho-fab-badge {
      background: #0f0f0f;
      color: var(--gold);
      border-radius: 50%;
      width: 22px; height: 22px;
      display: flex; align-items: center; justify-content: center;
      font-size: .75rem;
      font-weight: 700;
    }

    @media (max-width: 900px) {
      .cardapio-layout { grid-template-columns: 1fr !important; }
      .carrinho-sidebar { display: none; }
      .carrinho-sidebar.mobile-open { display: block !important; position: fixed; inset: 0; z-index: 80; border-radius: 0; overflow-y: auto; }
      .carrinho-fab { display: block; }
    }
  </style>
</head>
<body>
<?php require_once '../../includes/cliente_layout.php'; ?>

  <?php if ($pedidoOk): ?>
  <!-- ── SUCESSO ── -->
  <div class="pedido-ok-box">
    <div class="ok-icon">✅</div>
    <h2>Pré-pedido enviado!</h2>
    <p>Nossa equipe recebeu seu pedido e ele estará pronto quando você chegar.<br>
       Acompanhe o status em <strong>Meus Pedidos</strong>.</p>
    <div style="display:flex;gap:.8rem;justify-content:center;flex-wrap:wrap;margin-top:1.5rem">
      <a href="pedidos.php"   class="btn btn-primary">🧾 Ver meus pedidos</a>
      <a href="cardapio.php"  class="btn btn-outline">← Fazer outro pedido</a>
    </div>
  </div>

  <?php else: ?>

  <?php if ($pedidoErr): ?>
    <div class="alert alert-err"><?= htmlspecialchars($pedidoErr) ?></div>
  <?php endif; ?>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div>
      <h1>Cardápio</h1>
      <p>Escolha os pratos para seu pré-pedido</p>
    </div>
    <a href="../cardapio-publico.php" class="btn btn-ghost btn-sm">Ver cardápio completo</a>
  </div>

  <!-- Filtros de categoria -->
  <div class="cat-filters">
    <button class="cat-filter active" onclick="filtrarCat('todas',this)">Todos</button>
    <?php foreach (array_keys($porCategoria) as $catNome): ?>
      <button class="cat-filter"
              onclick="filtrarCat('<?= htmlspecialchars(strtolower(preg_replace('/\s+/','_',$catNome))) ?>',this)">
        <?= htmlspecialchars($catNome) ?>
      </button>
    <?php endforeach; ?>
  </div>

  <div class="cardapio-layout" style="display:grid;grid-template-columns:1fr 320px;gap:1.5rem;align-items:start">

    <!-- ── Pratos ── -->
    <div>
      <?php foreach ($porCategoria as $cat => $pratos_cat): ?>
      <?php $catSlug = strtolower(preg_replace('/\s+/','_',$cat)); ?>
      <div class="cat-section" data-cat="<?= $catSlug ?>">
        <div style="display:flex;align-items:center;gap:.8rem;margin-bottom:1rem;margin-top:1.5rem">
          <h2 style="font-family:var(--font-display);font-size:1.1rem;color:var(--text-2)"><?= htmlspecialchars($cat) ?></h2>
          <div style="flex:1;height:1px;background:var(--border)"></div>
        </div>
        <div class="pratos-grid">
          <?php foreach ($pratos_cat as $p): ?>
          <div class="prato-cli-card prato-card-add" id="card-<?= $p['id'] ?>">
            <span class="cat-badge"><?= htmlspecialchars($cat) ?></span>
            <h3 class="prato-cli-nome"><?= htmlspecialchars($p['nome']) ?></h3>
            <?php if ($p['descricao']): ?>
              <p class="prato-cli-desc"><?= htmlspecialchars($p['descricao']) ?></p>
            <?php endif; ?>
            <div class="prato-cli-footer">
              <div>
                <div class="prato-cli-preco">R$ <?= number_format((float)$p['preco'],2,',','.') ?></div>
                <div style="font-size:.73rem;color:var(--muted)">⏱ <?= $p['tempo_minutos'] ?>min</div>
              </div>
              <!-- Controle de quantidade -->
              <div id="ctrl-<?= $p['id'] ?>">
                <button class="add-btn"
                        onclick="addItem(<?= $p['id'] ?>, '<?= htmlspecialchars(addslashes($p['nome'])) ?>', <?= $p['preco'] ?>)">
                  +
                </button>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>

      <?php if (empty($porCategoria)): ?>
        <div class="empty-state"><div class="empty-icon">🍽️</div><h3>Nenhum prato disponível</h3></div>
      <?php endif; ?>
    </div>

    <!-- ── Carrinho ── -->
    <div class="carrinho-sidebar" id="carritoSidebar">
      <div class="carrinho-header">
        <h3>🛒 Pré-pedido</h3>
        <span id="carr-count" style="font-size:.78rem;color:var(--muted)">0 itens</span>
      </div>
      <div class="carrinho-body">
        <div id="carr-empty" class="carrinho-empty">
          Nenhum item adicionado.<br>Selecione pratos ao lado.
        </div>
        <div id="carr-items"></div>
        <div id="carr-total" class="carrinho-total" style="display:none">
          <span style="color:var(--text-2);font-size:.88rem">Total estimado</span>
          <span class="carrinho-total-preco" id="carr-total-val">R$ 0,00</span>
        </div>
      </div>
      <div class="carrinho-footer">
        <!-- Vincular à reserva -->
        <div class="form-group" style="margin-bottom:.8rem">
          <label>Vincular à reserva</label>
          <?php if (!empty($reservas)): ?>
          <select id="reserva-select">
            <option value="">— Sem reserva vinculada —</option>
            <?php foreach ($reservas as $r): ?>
              <option value="<?= $r['id'] ?>">
                <?= date('d/m/Y',strtotime($r['data_reserva'])) ?>
                às <?= substr($r['hora_reserva'],0,5) ?> —
                <?= $r['pessoas'] ?> pess. (<?= $r['status'] ?>)
              </option>
            <?php endforeach; ?>
          </select>
          <?php else: ?>
          <div style="font-size:.8rem;color:var(--muted);padding:.5rem 0">
            Nenhuma reserva futura.
            <a href="../reserva.php" style="color:var(--gold)">Fazer reserva →</a>
          </div>
          <input type="hidden" id="reserva-select" value="">
          <?php endif; ?>
        </div>
        <div class="form-group" style="margin-bottom:1rem">
          <label>Observações</label>
          <textarea id="obs-input" rows="2" placeholder="Alergias, preferências..."
                    style="width:100%;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);padding:.6rem .8rem;color:var(--text);font-size:.83rem;font-family:var(--font-body);resize:vertical;outline:none"></textarea>
        </div>
        <button class="btn btn-primary btn-full" id="btn-enviar" onclick="abrirModal()" disabled>
          Enviar pré-pedido
        </button>
        <button class="btn btn-ghost btn-sm" style="width:100%;margin-top:.4rem" onclick="limparCarrinho()">
          Limpar carrinho
        </button>
      </div>
    </div>

  </div><!-- /cardapio-layout -->

  <?php endif; ?>

  <!-- Botão flutuante mobile -->
  <div class="carrinho-fab">
    <button onclick="toggleMobileCart()">
      🛒 Pedido
      <span class="carrinho-fab-badge" id="fab-count">0</span>
    </button>
  </div>

<!-- Modal de confirmação -->
<div class="modal-overlay" id="modal-confirma">
  <div class="modal-box">
    <h2>Confirmar pré-pedido</h2>
    <p style="color:var(--text-2);margin-bottom:1rem;font-size:.88rem">
      Revise os itens antes de enviar. O pedido será entregue quando você chegar ao restaurante.
    </p>
    <div id="modal-resumo" style="margin-bottom:1.2rem;font-size:.86rem;color:var(--text-2)"></div>

    <form method="POST" id="form-pedido">
      <input type="hidden" name="enviar_pedido" value="1">
      <input type="hidden" name="reserva_id"   id="h-reserva">
      <input type="hidden" name="observacao"    id="h-obs">
      <input type="hidden" name="itens_json"    id="h-itens">
      <div style="display:flex;gap:.8rem">
        <button type="submit" class="btn btn-primary" style="flex:1">✅ Confirmar e enviar</button>
        <button type="button" class="btn btn-ghost" onclick="fecharModal()">Cancelar</button>
      </div>
    </form>
  </div>
</div>

  </main>
</div>

<script>
// Estado do carrinho
let cart = {};

function addItem(id, nome, preco) {
  if (cart[id]) {
    cart[id].qty++;
  } else {
    cart[id] = { id, nome, preco, qty: 1 };
  }
  renderCart();
  renderCtrl(id);
}

function changeQty(id, delta) {
  if (!cart[id]) return;
  cart[id].qty += delta;
  if (cart[id].qty <= 0) {
    delete cart[id];
    renderCtrl(id, true);
  } else {
    renderCtrl(id);
  }
  renderCart();
}

function renderCtrl(id, reset = false) {
  const el = document.getElementById('ctrl-' + id);
  const card = document.getElementById('card-' + id);
  if (reset || !cart[id]) {
    el.innerHTML = `<button class="add-btn" onclick="addItem(${id}, '${cart[id]?.nome || ''}', ${cart[id]?.preco || 0})">+</button>`;
    // recria o botão com dados do card
    const nome = card.querySelector('.prato-cli-nome')?.textContent || '';
    const preco = parseFloat(card.querySelector('.prato-cli-preco')?.textContent?.replace('R$ ','')?.replace(',','.') || 0);
    el.innerHTML = `<button class="add-btn" onclick="addItem(${id}, \`${nome.replace(/`/g,"'")}\`, ${preco})">+</button>`;
    card.classList.remove('no-carrinho');
  } else {
    el.innerHTML = `
      <div class="qty-ctrl">
        <button onclick="changeQty(${id},-1)">−</button>
        <span>${cart[id].qty}</span>
        <button onclick="changeQty(${id},1)">+</button>
      </div>`;
    card.classList.add('no-carrinho');
  }
}

function renderCart() {
  const ids = Object.keys(cart);
  const count = ids.reduce((s, k) => s + cart[k].qty, 0);
  const total = ids.reduce((s, k) => s + cart[k].preco * cart[k].qty, 0);

  document.getElementById('carr-count').textContent = count + ' item' + (count !== 1 ? 's' : '');
  document.getElementById('fab-count').textContent = count;

  const empty   = document.getElementById('carr-empty');
  const itemsEl = document.getElementById('carr-items');
  const totalEl = document.getElementById('carr-total');
  const btnEnv  = document.getElementById('btn-enviar');

  if (ids.length === 0) {
    empty.style.display = '';
    itemsEl.innerHTML = '';
    totalEl.style.display = 'none';
    btnEnv.disabled = true;
    return;
  }
  empty.style.display = 'none';
  totalEl.style.display = 'flex';
  btnEnv.disabled = false;

  itemsEl.innerHTML = ids.map(k => {
    const it = cart[k];
    const sub = (it.preco * it.qty).toLocaleString('pt-BR', {style:'currency',currency:'BRL'});
    return `<div class="carrinho-item">
      <span class="carrinho-item-nome">${it.nome}</span>
      <span class="carrinho-item-qty">${it.qty}×</span>
      <span class="carrinho-item-preco">${sub}</span>
      <button class="carrinho-item-del" onclick="changeQty(${k},-${it.qty})" title="Remover">×</button>
    </div>`;
  }).join('');

  document.getElementById('carr-total-val').textContent =
    total.toLocaleString('pt-BR', {style:'currency',currency:'BRL'});
}

function limparCarrinho() {
  Object.keys(cart).forEach(id => { delete cart[id]; renderCtrl(parseInt(id), true); });
  cart = {};
  renderCart();
}

function abrirModal() {
  const ids = Object.keys(cart);
  if (!ids.length) return;

  const total = ids.reduce((s,k) => s+cart[k].preco*cart[k].qty, 0);
  const resumo = ids.map(k =>
    `<div style="display:flex;justify-content:space-between;padding:.3rem 0;border-bottom:1px solid var(--border)">
      <span>${cart[k].qty}× ${cart[k].nome}</span>
      <span style="color:var(--gold)">${(cart[k].preco*cart[k].qty).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</span>
    </div>`).join('') +
    `<div style="display:flex;justify-content:space-between;padding:.5rem 0;font-weight:600">
      <span>Total</span>
      <span style="color:var(--gold)">${total.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</span>
    </div>`;

  document.getElementById('modal-resumo').innerHTML = resumo;
  document.getElementById('modal-confirma').classList.add('open');
}

function fecharModal() {
  document.getElementById('modal-confirma').classList.remove('open');
}

document.getElementById('form-pedido').addEventListener('submit', function() {
  const sel = document.getElementById('reserva-select');
  document.getElementById('h-reserva').value = sel ? sel.value : '';
  document.getElementById('h-obs').value = document.getElementById('obs-input').value;
  document.getElementById('h-itens').value = JSON.stringify(
    Object.values(cart).map(it => ({ id: it.id, qty: it.qty }))
  );
});

function filtrarCat(cat, btn) {
  document.querySelectorAll('.cat-filter').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.cat-section').forEach(sec => {
    sec.style.display = (cat === 'todas' || sec.dataset.cat === cat) ? '' : 'none';
  });
}

function toggleMobileCart() {
  document.getElementById('carritoSidebar').classList.toggle('mobile-open');
}

// Fechar modal clicando fora
document.getElementById('modal-confirma').addEventListener('click', function(e) {
  if (e.target === this) fecharModal();
});
</script>
</body>
</html>
