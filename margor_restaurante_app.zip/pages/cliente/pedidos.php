<?php
require_once '../../includes/auth.php';
requireCliente();

$db      = getDB();
$cliente = clienteAtual();
$id      = (int)$cliente['id'];

// Pedidos do cliente
$stmt = $db->prepare(
    "SELECT p.id, p.status, p.observacao, p.total, p.criado_em
     FROM pedidos p
     WHERE p.cliente_id = ?
     ORDER BY p.criado_em DESC"
);
$stmt->execute([$id]);
$pedidos = $stmt->fetchAll();

// Itens por pedido (só busca se houver pedidos)
$itensPorPedido = [];
if (!empty($pedidos)) {
    $ids  = implode(',', array_column($pedidos, 'id'));
    $itens = $db->query(
        "SELECT ip.pedido_id, pr.nome, ip.quantidade, ip.preco_unit, ip.subtotal
         FROM itens_pedido ip
         JOIN pratos pr ON pr.id = ip.prato_id
         WHERE ip.pedido_id IN ($ids)
         ORDER BY ip.id"
    )->fetchAll();
    foreach ($itens as $item) {
        $itensPorPedido[$item['pedido_id']][] = $item;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meus Pedidos — RestauranteApp</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
  <style>
    .pedido-card { margin-bottom: 1.2rem; }
    .pedido-header {
      display: flex; align-items: center; justify-content: space-between;
      flex-wrap: wrap; gap: .6rem;
      padding: 1rem 1.2rem;
      background: var(--bg);
      border-bottom: 1px solid var(--border);
      border-radius: var(--radius) var(--radius) 0 0;
      cursor: pointer;
    }
    .pedido-body {
      padding: 1rem 1.2rem;
    }
    .itens-table { width: 100%; font-size: .87rem; }
    .itens-table td { padding: .4rem .5rem; border-bottom: 1px solid var(--border); }
    .itens-table tr:last-child td { border-bottom: none; }
    .pedido-total {
      text-align: right; font-weight: 700;
      font-family: 'Playfair Display', serif;
      font-size: 1.1rem; color: var(--accent);
      padding-top: .6rem;
    }
  </style>
</head>
<body>
<?php $paginaAtiva = 'pedidos'; require_once '../../includes/cliente_layout.php'; ?>

  <div class="page-header">
    <h1>Meus Pedidos</h1>
    <p><?= count($pedidos) ?> pedido<?= count($pedidos) !== 1 ? 's' : '' ?> realizados</p>
  </div>

  <?php if (empty($pedidos)): ?>
    <div class="empty-state">
      <div class="empty-icon">🧾</div>
      <h3>Nenhum pedido ainda</h3>
      <p>Seus pedidos feitos no restaurante aparecerão aqui.</p>
    </div>

  <?php else: ?>
    <?php foreach ($pedidos as $pedido): ?>
    <?php
      $badgeMap = [
        'Aguardando' => 'aguardando', 'Em preparo' => 'preparo',
        'Pronto'     => 'pronto',     'Entregue'   => 'entregue',
        'Cancelado'  => 'cancelada'
      ];
      $b = $badgeMap[$pedido['status']] ?? 'aguardando';
      $itens = $itensPorPedido[$pedido['id']] ?? [];
    ?>
    <div class="card pedido-card">
      <div class="pedido-header" onclick="togglePedido(<?= $pedido['id'] ?>)">
        <div>
          <span style="font-weight:700;color:var(--primary)">Pedido #<?= $pedido['id'] ?></span>
          <span style="font-size:.82rem;color:var(--muted);margin-left:.6rem">
            <?= date('d/m/Y H:i', strtotime($pedido['criado_em'])) ?>
          </span>
        </div>
        <div style="display:flex;align-items:center;gap:.8rem">
          <span class="badge badge-<?= $b ?>"><?= $pedido['status'] ?></span>
          <span style="font-size:.75rem;color:var(--muted)">▼</span>
        </div>
      </div>

      <div class="pedido-body" id="pedido-<?= $pedido['id'] ?>" style="display:none">
        <?php if ($pedido['observacao']): ?>
          <div class="alert alert-info" style="margin-bottom:.8rem;font-size:.85rem">
            📝 <?= htmlspecialchars($pedido['observacao']) ?>
          </div>
        <?php endif; ?>

        <?php if (!empty($itens)): ?>
          <table class="itens-table">
            <thead>
              <tr style="color:var(--muted);font-size:.78rem;text-transform:uppercase;letter-spacing:.05em">
                <td>Item</td><td style="text-align:center">Qtd</td>
                <td style="text-align:right">Unit.</td><td style="text-align:right">Subtotal</td>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($itens as $item): ?>
              <tr>
                <td><?= htmlspecialchars($item['nome']) ?></td>
                <td style="text-align:center"><?= $item['quantidade'] ?></td>
                <td style="text-align:right">R$ <?= number_format((float)$item['preco_unit'],2,',','.') ?></td>
                <td style="text-align:right">R$ <?= number_format((float)$item['subtotal'],2,',','.') ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p style="color:var(--muted);font-size:.87rem">Itens não disponíveis.</p>
        <?php endif; ?>

        <div class="pedido-total">
          Total: R$ <?= number_format((float)$pedido['total'], 2, ',', '.') ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>

  </main>
</div>

<script>
function togglePedido(id) {
  const el = document.getElementById('pedido-' + id);
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
</script>
</body>
</html>
