<?php
require_once '../../includes/auth.php';
requireCliente();

$db      = getDB();
$cliente = clienteAtual();
$id      = (int)$cliente['id'];

// Filtro de status
$filtro = $_GET['status'] ?? 'todas';
$where  = 'WHERE r.cliente_id = ?';
$params = [$id];
if ($filtro !== 'todas') {
    $where   .= ' AND r.status = ?';
    $params[] = ucfirst($filtro);
}

$stmt = $db->prepare(
    "SELECT r.id, r.data_reserva, r.hora_reserva, r.pessoas, r.status, r.origem, r.criado_em
     FROM reservas r
     $where
     ORDER BY r.data_reserva DESC, r.hora_reserva DESC"
);
$stmt->execute($params);
$reservas = $stmt->fetchAll();

// Contadores por status
$contadores = $db->prepare(
    "SELECT status, COUNT(*) AS total FROM reservas WHERE cliente_id = ? GROUP BY status"
);
$contadores->execute([$id]);
$counts = [];
foreach ($contadores->fetchAll() as $row) {
    $counts[$row['status']] = $row['total'];
}
$totalGeral = array_sum($counts);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Minhas Reservas — RestauranteApp</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
<?php $paginaAtiva = 'reservas'; require_once '../../includes/cliente_layout.php'; ?>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div>
      <h1>Minhas Reservas</h1>
      <p><?= $totalGeral ?> reserva<?= $totalGeral !== 1 ? 's' : '' ?> no total</p>
    </div>
    <a href="../reserva.php" class="btn btn-accent">📅 Nova reserva</a>
  </div>

  <!-- Filtros -->
  <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.5rem">
    <?php
    $filtros = [
      'todas'      => "Todas ($totalGeral)",
      'pendente'   => 'Pendente ('    . ($counts['Pendente']   ?? 0) . ')',
      'confirmada' => 'Confirmada ('  . ($counts['Confirmada'] ?? 0) . ')',
      'cancelada'  => 'Cancelada ('   . ($counts['Cancelada']  ?? 0) . ')',
      'concluída'  => 'Concluída ('   . ($counts['Concluída']  ?? 0) . ')',
    ];
    foreach ($filtros as $val => $label): ?>
      <a href="?status=<?= $val ?>"
         class="btn btn-sm <?= $filtro === $val ? 'btn-primary' : 'btn-ghost' ?>">
        <?= $label ?>
      </a>
    <?php endforeach; ?>
  </div>

  <?php if (empty($reservas)): ?>
    <div class="empty-state">
      <div class="empty-icon">📅</div>
      <h3>Nenhuma reserva encontrada</h3>
      <p>
        <?= $filtro !== 'todas' ? 'Tente outro filtro ou f' : 'F' ?>aça sua primeira reserva agora mesmo!
      </p>
      <a href="../reserva.php" class="btn btn-accent" style="margin-top:1rem">📅 Fazer reserva</a>
    </div>

  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Data</th>
            <th>Horário</th>
            <th>Pessoas</th>
            <th>Origem</th>
            <th>Status</th>
            <th>Feita em</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($reservas as $r): ?>
          <?php
            $b = match($r['status']) {
              'Confirmada' => 'confirmada',
              'Cancelada'  => 'cancelada',
              'Concluída'  => 'concluida',
              default      => 'pendente'
            };
            $hoje    = date('Y-m-d');
            $passada = $r['data_reserva'] < $hoje;
          ?>
          <tr <?= $passada ? 'style="opacity:.7"' : '' ?>>
            <td style="color:var(--muted);font-size:.8rem">#<?= $r['id'] ?></td>
            <td>
              <strong><?= date('d/m/Y', strtotime($r['data_reserva'])) ?></strong>
              <?php if ($r['data_reserva'] === $hoje): ?>
                <span class="badge badge-confirmada" style="font-size:.68rem;margin-left:.3rem">hoje</span>
              <?php endif; ?>
            </td>
            <td><?= substr($r['hora_reserva'],0,5) ?></td>
            <td>👥 <?= $r['pessoas'] ?></td>
            <td style="font-size:.82rem;color:var(--muted)">
              <?= $r['origem'] === 'online' ? '🌐 Online' : '🏠 Interno' ?>
            </td>
            <td><span class="badge badge-<?= $b ?>"><?= $r['status'] ?></span></td>
            <td style="font-size:.8rem;color:var(--muted)">
              <?= date('d/m/Y', strtotime($r['criado_em'])) ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  </main>
</div>
</body>
</html>
