<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Administrador') { header('Location: ../painel.php'); exit; }

$db   = getDB();
$erro = '';
$ok   = false;

// Salvar prato (novo ou edição)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_prato'])) {
    $pid    = (int)($_POST['prato_id'] ?? 0);
    $nome   = trim($_POST['nome'] ?? '');
    $desc   = trim($_POST['descricao'] ?? '');
    $preco  = str_replace(',', '.', $_POST['preco'] ?? '0');
    $tempo  = (int)($_POST['tempo_minutos'] ?? 0);
    $catId  = (int)($_POST['categoria_id'] ?? 0);
    $status = $_POST['status'] ?? 'Disponível';

    if (!$nome || !$preco || !$catId) {
        $erro = 'Preencha nome, preço e categoria.';
    } else {
        if ($pid) {
            $db->prepare("UPDATE pratos SET nome=?,descricao=?,preco=?,tempo_minutos=?,categoria_id=?,status=? WHERE id=?")
               ->execute([$nome,$desc,$preco,$tempo,$catId,$status,$pid]);
        } else {
            $db->prepare("INSERT INTO pratos (nome,descricao,preco,tempo_minutos,categoria_id,status) VALUES (?,?,?,?,?,?)")
               ->execute([$nome,$desc,$preco,$tempo,$catId,$status]);
        }
        header('Location: cardapio.php?ok=1'); exit;
    }
}

// Toggle disponibilidade via AJAX/POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
    $pid = (int)$_POST['prato_id'];
    $db->prepare(
        "UPDATE pratos SET status = IF(status='Disponível','Indisponível','Disponível') WHERE id=?"
    )->execute([$pid]);
    header('Location: cardapio.php?ok=1'); exit;
}

// Excluir prato
if (isset($_GET['excluir'])) {
    $pid = (int)$_GET['excluir'];
    try {
        $db->prepare("DELETE FROM pratos WHERE id=?")->execute([$pid]);
    } catch (\Exception $e) {
        $erro = 'Não é possível excluir: prato vinculado a pedidos. Marque como Indisponível.';
    }
    if (!$erro) { header('Location: cardapio.php?ok=1'); exit; }
}

// Buscar prato para edição
$pratoEdit = null;
if (isset($_GET['editar'])) {
    $s = $db->prepare("SELECT * FROM pratos WHERE id=? LIMIT 1");
    $s->execute([(int)$_GET['editar']]);
    $pratoEdit = $s->fetch();
}

// Lista de pratos
$stmt = $db->query(
    "SELECT DISTINCT p.id, p.nome, p.descricao, p.preco, p.tempo_minutos,
            p.categoria_id, p.status, p.criado_em, c.nome AS categoria
     FROM pratos p JOIN categorias_prato c ON c.id=p.categoria_id
     ORDER BY c.nome, p.nome"
);
$porCat = [];
$idsVistos = [];
foreach ($stmt->fetchAll() as $p) {
    if (in_array($p['id'], $idsVistos)) continue; // evita duplicatas
    $idsVistos[] = $p['id'];
    $porCat[$p['categoria']][] = $p;
}

$categorias = $db->query("SELECT * FROM categorias_prato ORDER BY nome")->fetchAll();

$tituloPagina = 'Cardápio';
$paginaAtiva  = 'cardapio';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
/* Cards do cardápio admin */
.admin-prato-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
  gap: 1rem;
  margin-bottom: 2.5rem;
}
.admin-prato-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  overflow: hidden;
  transition: border-color .2s, box-shadow .2s;
  display: flex;
  flex-direction: column;
}
.admin-prato-card:hover { border-color: var(--border-gold); }
.admin-prato-card.indisponivel { opacity: .55; }
.admin-prato-card-body { padding: 1.2rem; flex: 1; }
.admin-prato-card-nome {
  font-family: var(--font-display);
  font-size: 1.05rem;
  color: var(--text);
  margin-bottom: .4rem;
}
.admin-prato-card-desc {
  font-size: .8rem;
  color: var(--muted);
  line-height: 1.5;
  margin-bottom: .8rem;
}
.admin-prato-card-preco {
  font-family: var(--font-display);
  font-size: 1.3rem;
  color: var(--gold);
}
.admin-prato-card-tempo { font-size: .72rem; color: var(--muted); }
.admin-prato-card-footer {
  padding: .8rem 1.2rem;
  border-top: 1px solid var(--border);
  background: var(--bg-2);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: .5rem;
}

/* Toggle */
.status-toggle {
  display: flex;
  align-items: center;
  gap: .5rem;
  cursor: pointer;
  font-size: .78rem;
  color: var(--muted);
}
.toggle-pill {
  width: 38px; height: 22px;
  border-radius: 99px;
  background: rgba(192,80,74,0.3);
  border: 1px solid rgba(192,80,74,0.4);
  position: relative;
  transition: all .25s;
  flex-shrink: 0;
}
.toggle-pill::after {
  content: '';
  position: absolute;
  width: 16px; height: 16px;
  background: #7A7470;
  border-radius: 50%;
  top: 2px; left: 2px;
  transition: transform .25s, background .25s;
}
.toggle-pill.on {
  background: rgba(74,124,89,0.3);
  border-color: rgba(74,124,89,0.5);
}
.toggle-pill.on::after { transform: translateX(16px); background: #7bc492; }
</style>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div><h1>Cardápio</h1><p>Gerencie pratos e disponibilidade</p></div>
    <a href="?novo=1" class="btn btn-primary btn-sm">➕ Novo prato</a>
  </div>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">✅ Operação realizada com sucesso!</div>
  <?php endif; ?>
  <?php if ($erro): ?>
    <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
  <?php endif; ?>

  <!-- Formulário novo/edição -->
  <?php if (isset($_GET['novo']) || $pratoEdit): ?>
  <div class="card" style="margin-bottom:2rem;border-left:3px solid var(--gold)">
    <div class="card-title"><?= $pratoEdit ? 'Editar prato' : 'Novo prato' ?></div>
    <form method="POST">
      <input type="hidden" name="salvar_prato" value="1">
      <input type="hidden" name="prato_id" value="<?= $pratoEdit['id'] ?? 0 ?>">
      <div class="form-row">
        <div class="form-group" style="grid-column:span 2">
          <label>Nome do prato</label>
          <input type="text" name="nome" value="<?= htmlspecialchars($pratoEdit['nome'] ?? '') ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label>Descrição</label>
        <input type="text" name="descricao" value="<?= htmlspecialchars($pratoEdit['descricao'] ?? '') ?>"
               placeholder="Ingredientes, modo de preparo...">
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Preço (R$)</label>
          <input type="text" name="preco"
                 value="<?= $pratoEdit ? number_format((float)$pratoEdit['preco'],2,',','.') : '' ?>"
                 placeholder="0,00" required>
        </div>
        <div class="form-group">
          <label>Tempo (min)</label>
          <input type="number" name="tempo_minutos" value="<?= $pratoEdit['tempo_minutos'] ?? 0 ?>" min="0">
        </div>
        <div class="form-group">
          <label>Categoria</label>
          <select name="categoria_id" required>
            <option value="">Selecione...</option>
            <?php foreach ($categorias as $c): ?>
              <option value="<?= $c['id'] ?>" <?= ($pratoEdit['categoria_id']??0)==$c['id']?'selected':'' ?>>
                <?= htmlspecialchars($c['nome']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-group" style="max-width:200px">
        <label>Status</label>
        <select name="status">
          <option value="Disponível"   <?= ($pratoEdit['status']??'Disponível')==='Disponível'?'selected':'' ?>>Disponível</option>
          <option value="Indisponível" <?= ($pratoEdit['status']??'')==='Indisponível'?'selected':'' ?>>Indisponível</option>
        </select>
      </div>
      <div style="display:flex;gap:.6rem">
        <button type="submit" class="btn btn-primary">💾 Salvar prato</button>
        <a href="cardapio.php" class="btn btn-ghost">Cancelar</a>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <!-- Cards por categoria -->
  <?php foreach ($porCat as $cat => $pratos): ?>
  <div class="cardapio-categoria">
    <h2 class="categoria-titulo">
      <?= htmlspecialchars($cat) ?>
      <span style="font-size:.75rem;color:var(--muted);font-weight:400">
        (<?= count($pratos) ?> prato<?= count($pratos)>1?'s':'' ?>)
      </span>
    </h2>

    <div class="admin-prato-grid">
      <?php foreach ($pratos as $p): ?>
      <div class="admin-prato-card <?= $p['status']==='Indisponível'?'indisponivel':'' ?>">
        <div class="admin-prato-card-body">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:.5rem;margin-bottom:.5rem">
            <h3 class="admin-prato-card-nome"><?= htmlspecialchars($p['nome']) ?></h3>
            <span class="badge <?= $p['status']==='Disponível'?'badge-disponivel':'badge-indisponivel' ?>" style="flex-shrink:0">
              <?= $p['status'] ?>
            </span>
          </div>
          <p class="admin-prato-card-desc"><?= htmlspecialchars($p['descricao'] ?? '—') ?></p>
          <div style="display:flex;align-items:center;justify-content:space-between">
            <span class="admin-prato-card-preco">R$ <?= number_format((float)$p['preco'],2,',','.') ?></span>
            <span class="admin-prato-card-tempo">⏱ <?= $p['tempo_minutos'] ?>min</span>
          </div>
        </div>
        <div class="admin-prato-card-footer">
          <!-- Toggle rápido -->
          <form method="POST" style="margin:0">
            <input type="hidden" name="toggle_status" value="1">
            <input type="hidden" name="prato_id"     value="<?= $p['id'] ?>">
            <button type="submit" class="status-toggle" title="Alternar disponibilidade">
              <span class="toggle-pill <?= $p['status']==='Disponível'?'on':'' ?>"></span>
              <span><?= $p['status']==='Disponível'?'Disponível':'Indisponível' ?></span>
            </button>
          </form>
          <!-- Ações -->
          <div style="display:flex;gap:.4rem">
            <a href="?editar=<?= $p['id'] ?>" class="btn btn-ghost btn-sm" title="Editar">✏️</a>
            <a href="?excluir=<?= $p['id'] ?>"
               onclick="return confirm('Excluir <?= htmlspecialchars(addslashes($p['nome'])) ?>?')"
               class="btn btn-danger btn-sm" title="Excluir">🗑️</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endforeach; ?>

  </main>
</div>
</body>
</html>
