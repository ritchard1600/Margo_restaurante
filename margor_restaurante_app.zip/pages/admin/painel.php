<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Administrador') {
    header('Location: ../painel.php'); exit;
}

$db = getDB();

// ── KPIs ──
$totalReservas  = $db->query("SELECT COUNT(*) FROM reservas")->fetchColumn();
$reservasHoje   = $db->query("SELECT COUNT(*) FROM reservas WHERE data_reserva = CURDATE()")->fetchColumn();
$pedidosAbertos = $db->query("SELECT COUNT(*) FROM pedidos WHERE status NOT IN ('Entregue','Cancelado')")->fetchColumn();
$totalClientes  = $db->query("SELECT COUNT(*) FROM clientes WHERE senha IS NOT NULL")->fetchColumn();
$totalFuncionarios = $db->query("SELECT COUNT(*) FROM usuarios WHERE status='Ativo'")->fetchColumn();
$receitaHoje    = $db->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE DATE(criado_em)=CURDATE() AND status='Entregue'")->fetchColumn();
$receitaMes     = $db->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE MONTH(criado_em)=MONTH(CURDATE()) AND YEAR(criado_em)=YEAR(CURDATE()) AND status='Entregue'")->fetchColumn();
$pratosAtivos   = $db->query("SELECT COUNT(*) FROM pratos WHERE status='Disponível'")->fetchColumn();

// ── Últimas reservas ──
$ultimasReservas = $db->query(
    "SELECT r.nome, r.data_reserva, r.hora_reserva, r.pessoas, r.status, r.origem
     FROM reservas r ORDER BY r.criado_em DESC LIMIT 6"
)->fetchAll();

// ── Pedidos em aberto ──
$pedidosAtivos = $db->query(
    "SELECT p.id, c.nome AS cliente, p.status, p.total, p.criado_em
     FROM pedidos p JOIN clientes c ON c.id = p.cliente_id
     WHERE p.status NOT IN ('Entregue','Cancelado')
     ORDER BY p.criado_em DESC LIMIT 6"
)->fetchAll();

// ── Pedidos por status (para mini gráfico) ──
$statusPedidos = $db->query(
    "SELECT status, COUNT(*) as total FROM pedidos GROUP BY status"
)->fetchAll(PDO::FETCH_KEY_PAIR);

$tituloPagina = 'Painel Admin';
$paginaAtiva  = 'painel';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
.kpi-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.kpi-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 1.4rem 1.2rem;
  transition: border-color .2s, transform .2s;
  cursor: default;
}
.kpi-card:hover { border-color: var(--border-gold); transform: translateY(-1px); }
.kpi-card.destaque { border-left: 3px solid var(--gold); }
.kpi-card.verde    { border-left: 3px solid #4A7C59; }
.kpi-icon  { font-size: 1.6rem; margin-bottom: .5rem; }
.kpi-valor {
  font-family: var(--font-display);
  font-size: 1.9rem;
  font-weight: 700;
  color: var(--text);
  line-height: 1;
  margin-bottom: .25rem;
}
.kpi-label { font-size: .74rem; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; }

.duas-colunas {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.4rem;
  margin-bottom: 1.4rem;
}

/* Atalhos rápidos */
.atalhos-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: .8rem;
}
.atalho-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: .5rem;
  padding: 1.2rem;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  color: var(--text-2);
  font-size: .83rem;
  text-align: center;
  transition: all .2s;
  text-decoration: none;
}
.atalho-btn:hover {
  border-color: var(--border-gold);
  color: var(--gold);
  background: var(--gold-dim2);
  transform: translateY(-2px);
}
.atalho-btn .ico { font-size: 1.6rem; }

/* Badge de status de pedidos */
.status-bar {
  display: flex;
  gap: .8rem;
  flex-wrap: wrap;
  margin-bottom: 1.4rem;
}
.status-chip {
  display: flex;
  align-items: center;
  gap: .4rem;
  padding: .4rem .9rem;
  border-radius: 99px;
  font-size: .78rem;
  font-weight: 500;
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
}

@media (max-width: 700px) {
  .duas-colunas { grid-template-columns: 1fr; }
}
</style>

  <!-- Cabeçalho -->
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:1.5rem">
    <div>
      <h1>Visão geral</h1>
      <p><?= date('l, d \d\e F \d\e Y') ?> &nbsp;·&nbsp; Olá, <?= htmlspecialchars(explode(' ', usuarioAtual()['nome'])[0]) ?>!</p>
    </div>
    <div style="display:flex;gap:.6rem;flex-wrap:wrap">
      <a href="pedidos.php"  class="btn btn-primary btn-sm">➕ Novo pedido</a>
      <a href="reservas.php" class="btn btn-accent btn-sm">📅 Nova reserva</a>
    </div>
  </div>

  <!-- KPIs -->
  <div class="kpi-grid">
    <div class="kpi-card destaque">
      <div class="kpi-icon">💰</div>
      <div class="kpi-valor" style="font-size:1.5rem;color:var(--gold)">
        R$ <?= number_format((float)$receitaHoje, 2, ',', '.') ?>
      </div>
      <div class="kpi-label">Receita hoje</div>
    </div>
    <div class="kpi-card destaque">
      <div class="kpi-icon">📈</div>
      <div class="kpi-valor" style="font-size:1.5rem;color:var(--gold)">
        R$ <?= number_format((float)$receitaMes, 2, ',', '.') ?>
      </div>
      <div class="kpi-label">Receita no mês</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-icon">📅</div>
      <div class="kpi-valor"><?= $reservasHoje ?></div>
      <div class="kpi-label">Reservas hoje</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-icon">🧾</div>
      <div class="kpi-valor"><?= $pedidosAbertos ?></div>
      <div class="kpi-label">Pedidos em aberto</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-icon">👥</div>
      <div class="kpi-valor"><?= $totalClientes ?></div>
      <div class="kpi-label">Clientes cadastrados</div>
    </div>
    <div class="kpi-card verde">
      <div class="kpi-icon">🍴</div>
      <div class="kpi-valor"><?= $pratosAtivos ?></div>
      <div class="kpi-label">Pratos disponíveis</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-icon">👨‍💼</div>
      <div class="kpi-valor"><?= $totalFuncionarios ?></div>
      <div class="kpi-label">Funcionários ativos</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-icon">📋</div>
      <div class="kpi-valor"><?= $totalReservas ?></div>
      <div class="kpi-label">Total de reservas</div>
    </div>
  </div>

  <!-- Status dos pedidos -->
  <?php if (!empty($statusPedidos)): ?>
  <div class="status-bar">
    <span style="font-size:.78rem;color:var(--muted);align-self:center">Pedidos:</span>
    <?php
    $mapLabel = ['Aguardando'=>'⏳','Em preparo'=>'👨‍🍳','Pronto'=>'✅','Entregue'=>'🍽️','Cancelado'=>'❌'];
    foreach ($statusPedidos as $s => $n): ?>
      <span class="status-chip">
        <?= $mapLabel[$s] ?? '•' ?> <?= $s ?> <strong style="color:var(--text)"><?= $n ?></strong>
      </span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Reservas + Pedidos -->
  <div class="duas-colunas">

    <!-- Reservas recentes -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title" style="display:flex;justify-content:space-between;align-items:center">
        📅 Reservas recentes
        <a href="reservas.php" style="font-size:.76rem;color:var(--gold)">Ver todas →</a>
      </div>
      <?php if (empty($ultimasReservas)): ?>
        <p style="color:var(--muted);font-size:.88rem">Nenhuma reserva ainda.</p>
      <?php else: ?>
      <div class="table-wrap" style="border:none">
        <table>
          <thead><tr><th>Nome</th><th>Data</th><th>Pess.</th><th>Status</th></tr></thead>
          <tbody>
          <?php foreach ($ultimasReservas as $r):
            $b = match($r['status']) { 'Confirmada'=>'confirmada','Cancelada'=>'cancelada','Concluída'=>'concluida',default=>'pendente' }; ?>
          <tr>
            <td style="font-weight:500"><?= htmlspecialchars($r['nome']) ?></td>
            <td style="font-size:.82rem"><?= date('d/m',strtotime($r['data_reserva'])) ?> <?= substr($r['hora_reserva'],0,5) ?></td>
            <td>👥 <?= $r['pessoas'] ?></td>
            <td><span class="badge badge-<?= $b ?>"><?= $r['status'] ?></span></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

    <!-- Pedidos ativos -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title" style="display:flex;justify-content:space-between;align-items:center">
        🧾 Pedidos em aberto
        <a href="pedidos.php" style="font-size:.76rem;color:var(--gold)">Ver todos →</a>
      </div>
      <?php if (empty($pedidosAtivos)): ?>
        <p style="color:var(--muted);font-size:.88rem">Nenhum pedido em aberto.</p>
      <?php else: ?>
      <div class="table-wrap" style="border:none">
        <table>
          <thead><tr><th>#</th><th>Cliente</th><th>Status</th><th>Total</th></tr></thead>
          <tbody>
          <?php foreach ($pedidosAtivos as $p):
            $bm = ['Aguardando'=>'aguardando','Em preparo'=>'preparo','Pronto'=>'pronto'];
            $b = $bm[$p['status']] ?? 'aguardando'; ?>
          <tr>
            <td style="color:var(--muted);font-size:.8rem">#<?= $p['id'] ?></td>
            <td style="font-weight:500"><?= htmlspecialchars($p['cliente']) ?></td>
            <td><span class="badge badge-<?= $b ?>"><?= $p['status'] ?></span></td>
            <td style="color:var(--gold);font-family:var(--font-display)">R$ <?= number_format((float)$p['total'],2,',','.') ?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

  </div>

  <!-- Atalhos rápidos -->
  <div class="card">
    <div class="card-title">Acesso rápido</div>
    <div class="atalhos-grid">
      <a href="cardapio.php"   class="atalho-btn"><span class="ico">🍴</span> Cardápio</a>
      <a href="clientes.php"   class="atalho-btn"><span class="ico">👥</span> Clientes</a>
      <a href="usuarios.php"   class="atalho-btn"><span class="ico">🔑</span> Usuários</a>
      <a href="relatorios.php" class="atalho-btn"><span class="ico">📊</span> Relatórios</a>
      <a href="cozinha.php"    class="atalho-btn"><span class="ico">👨‍🍳</span> Cozinha</a>
      <a href="caixa.php"      class="atalho-btn"><span class="ico">💰</span> Caixa</a>
      <a href="reservas.php"   class="atalho-btn"><span class="ico">📅</span> Reservas</a>
      <a href="pedidos.php"    class="atalho-btn"><span class="ico">🧾</span> Pedidos</a>
    </div>
  </div>

  </main>
</div>
<script src="../../assets/js/reserva-horario.js"></script>
</body>
</html>
