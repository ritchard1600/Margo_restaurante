<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Administrador') { header('Location: ../painel.php'); exit; }

$db = getDB();

// Filtros
$periodo = $_GET['periodo'] ?? 'mes'; // dia, mes, ano
$dia     = $_GET['dia']     ?? date('Y-m-d');
$mes     = (int)($_GET['mes'] ?? date('m'));
$ano     = (int)($_GET['ano'] ?? date('Y'));

$mesesNomes = ['','Janeiro','Fevereiro','Março','Abril','Maio','Junho',
               'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

// ── WHERE dinâmico por período ──────────────────────────────
function wherePeriodoPedido(string $periodo, string $dia, int $mes, int $ano): array {
    return match($periodo) {
        'dia'  => ["DATE(p.criado_em) = ?",          [$dia]],
        'ano'  => ["YEAR(p.criado_em) = ?",           [$ano]],
        default=> ["MONTH(p.criado_em)=? AND YEAR(p.criado_em)=?", [$mes, $ano]],
    };
}
function wherePeriodoReserva(string $periodo, string $dia, int $mes, int $ano): array {
    return match($periodo) {
        'dia'  => ["DATE(r.data_reserva) = ?",                      [$dia]],
        'ano'  => ["YEAR(r.data_reserva) = ?",                      [$ano]],
        default=> ["MONTH(r.data_reserva)=? AND YEAR(r.data_reserva)=?", [$mes, $ano]],
    };
}

[$wPedido,  $pPedido]  = wherePeriodoPedido($periodo,  $dia, $mes, $ano);
[$wReserva, $pReserva] = wherePeriodoReserva($periodo, $dia, $mes, $ano);

// ── KPIs ────────────────────────────────────────────────────
$kpi = $db->prepare(
    "SELECT COUNT(*) AS qtd_pedidos,
            COALESCE(SUM(total),0) AS receita
     FROM pedidos p WHERE $wPedido AND p.status='Entregue'"
);
$kpi->execute($pPedido);
$kpis = $kpi->fetch();
$ticketMedio = $kpis['qtd_pedidos'] > 0 ? $kpis['receita'] / $kpis['qtd_pedidos'] : 0;

$kpiRes = $db->prepare(
    "SELECT COUNT(*) AS total FROM reservas r WHERE $wReserva"
);
$kpiRes->execute($pReserva);
$totalReservas = $kpiRes->fetchColumn();

// ── Pratos mais vendidos ─────────────────────────────────────
$pratosVendidos = $db->prepare(
    "SELECT pr.nome,
            SUM(ip.quantidade)  AS qtd,
            SUM(ip.subtotal)    AS receita
     FROM itens_pedido ip
     JOIN pratos  pr ON pr.id = ip.prato_id
     JOIN pedidos p  ON p.id  = ip.pedido_id
     WHERE $wPedido AND p.status='Entregue'
     GROUP BY pr.id, pr.nome
     ORDER BY qtd DESC
     LIMIT 10"
);
$pratosVendidos->execute($pPedido);
$rankingPratos = $pratosVendidos->fetchAll();

// ── Reservas por status ──────────────────────────────────────
$resStatus = $db->prepare(
    "SELECT r.status, COUNT(*) AS total
     FROM reservas r WHERE $wReserva
     GROUP BY r.status"
);
$resStatus->execute($pReserva);
$reservasStatus = [];
foreach ($resStatus->fetchAll() as $r) $reservasStatus[$r['status']] = (int)$r['total'];

// ── Reservas por dia (para gráfico de linha) ─────────────────
if ($periodo === 'mes') {
    $resEvol = $db->prepare(
        "SELECT DAY(r.data_reserva) AS dia, COUNT(*) AS total
         FROM reservas r
         WHERE MONTH(r.data_reserva)=? AND YEAR(r.data_reserva)=?
         GROUP BY DAY(r.data_reserva) ORDER BY dia"
    );
    $resEvol->execute([$mes, $ano]);
} elseif ($periodo === 'ano') {
    $resEvol = $db->prepare(
        "SELECT MONTH(r.data_reserva) AS dia, COUNT(*) AS total
         FROM reservas r
         WHERE YEAR(r.data_reserva)=?
         GROUP BY MONTH(r.data_reserva) ORDER BY dia"
    );
    $resEvol->execute([$ano]);
} else {
    $resEvol = $db->prepare(
        "SELECT HOUR(r.criado_em) AS dia, COUNT(*) AS total
         FROM reservas r
         WHERE DATE(r.data_reserva)=?
         GROUP BY HOUR(r.criado_em) ORDER BY dia"
    );
    $resEvol->execute([$dia]);
}
$reservasEvol = $resEvol->fetchAll();

// ── Receita por período (para gráfico de barras) ─────────────
if ($periodo === 'mes') {
    $receitaEvol = $db->prepare(
        "SELECT DAY(p.criado_em) AS label, COALESCE(SUM(p.total),0) AS receita, COUNT(*) AS pedidos
         FROM pedidos p WHERE MONTH(p.criado_em)=? AND YEAR(p.criado_em)=? AND p.status='Entregue'
         GROUP BY DAY(p.criado_em) ORDER BY label"
    );
    $receitaEvol->execute([$mes, $ano]);
} elseif ($periodo === 'ano') {
    $receitaEvol = $db->prepare(
        "SELECT MONTH(p.criado_em) AS label, COALESCE(SUM(p.total),0) AS receita, COUNT(*) AS pedidos
         FROM pedidos p WHERE YEAR(p.criado_em)=? AND p.status='Entregue'
         GROUP BY MONTH(p.criado_em) ORDER BY label"
    );
    $receitaEvol->execute([$ano]);
} else {
    $receitaEvol = $db->prepare(
        "SELECT HOUR(p.criado_em) AS label, COALESCE(SUM(p.total),0) AS receita, COUNT(*) AS pedidos
         FROM pedidos p WHERE DATE(p.criado_em)=? AND p.status='Entregue'
         GROUP BY HOUR(p.criado_em) ORDER BY label"
    );
    $receitaEvol->execute([$dia]);
}
$receitaEvolData = $receitaEvol->fetchAll();

// Título do período selecionado
$tituloPeriodo = match($periodo) {
    'dia'  => 'dia ' . date('d/m/Y', strtotime($dia)),
    'ano'  => 'ano ' . $ano,
    default=> $mesesNomes[$mes] . ' ' . $ano,
};

$tituloPagina = 'Relatórios';
$paginaAtiva  = 'relatorios';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
/* Abas de período */
.periodo-tabs {
  display: flex;
  gap: .4rem;
  margin-bottom: 1.5rem;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: .4rem;
  width: fit-content;
}
.periodo-tab {
  padding: .5rem 1.2rem;
  border-radius: 8px;
  font-size: .83rem;
  font-weight: 500;
  color: var(--muted);
  border: none;
  background: none;
  cursor: pointer;
  text-decoration: none;
  transition: all .2s;
  font-family: var(--font-body);
}
.periodo-tab:hover { color: var(--text); background: var(--surface-2); }
.periodo-tab.active { background: var(--gold); color: #0f0f0f; font-weight: 600; }

/* Filtro inline */
.filtro-bar {
  display: flex;
  gap: .6rem;
  align-items: flex-end;
  flex-wrap: wrap;
  margin-bottom: 1.5rem;
}

/* KPIs */
.kpi-row {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.kpi-mini {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 1.2rem 1rem;
  transition: border-color .2s;
}
.kpi-mini:hover { border-color: var(--border-gold); }
.kpi-mini.gold  { border-left: 3px solid var(--gold); }
.kpi-mini.green { border-left: 3px solid #4A7C59; }
.kpi-mini .ico  { font-size: 1.4rem; margin-bottom: .4rem; }
.kpi-mini .val  { font-family: var(--font-display); font-size: 1.7rem; font-weight: 700; color: var(--text); line-height: 1; margin-bottom: .25rem; }
.kpi-mini .lbl  { font-size: .72rem; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; }

/* Layout de dois gráficos */
.graficos-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.4rem;
  margin-bottom: 1.4rem;
}
@media (max-width: 800px) { .graficos-grid { grid-template-columns: 1fr; } }

/* Canvas */
.chart-container { position: relative; height: 220px; }
</style>

  <!-- Cabeçalho -->
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div>
      <h1>📊 Relatórios</h1>
      <p>Análise de desempenho — <?= $tituloPeriodo ?></p>
    </div>
  </div>

  <!-- Abas de período -->
  <div class="periodo-tabs">
    <a href="?periodo=dia&dia=<?= date('Y-m-d') ?>"
       class="periodo-tab <?= $periodo==='dia'?'active':'' ?>">Dia</a>
    <a href="?periodo=mes&mes=<?= date('m') ?>&ano=<?= date('Y') ?>"
       class="periodo-tab <?= $periodo==='mes'?'active':'' ?>">Mês</a>
    <a href="?periodo=ano&ano=<?= date('Y') ?>"
       class="periodo-tab <?= $periodo==='ano'?'active':'' ?>">Ano</a>
  </div>

  <!-- Filtro conforme período -->
  <form method="GET" class="filtro-bar">
    <input type="hidden" name="periodo" value="<?= $periodo ?>">
    <?php if ($periodo === 'dia'): ?>
      <div class="form-group" style="margin:0">
        <label style="font-size:.74rem">Data</label>
        <input type="date" name="dia" value="<?= htmlspecialchars($dia) ?>"
               max="<?= date('Y-m-d') ?>" style="padding:.4rem .7rem;font-size:.88rem">
      </div>
    <?php elseif ($periodo === 'mes'): ?>
      <div class="form-group" style="margin:0">
        <label style="font-size:.74rem">Mês</label>
        <select name="mes" style="padding:.4rem .6rem;font-size:.88rem">
          <?php for($i=1;$i<=12;$i++): ?>
            <option value="<?=$i?>" <?=$mes===$i?'selected':''?>><?= $mesesNomes[$i] ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="form-group" style="margin:0">
        <label style="font-size:.74rem">Ano</label>
        <select name="ano" style="padding:.4rem .6rem;font-size:.88rem">
          <?php for($y=date('Y');$y>=date('Y')-4;$y--): ?>
            <option value="<?=$y?>" <?=$ano===$y?'selected':''?>><?=$y?></option>
          <?php endfor; ?>
        </select>
      </div>
    <?php else: ?>
      <div class="form-group" style="margin:0">
        <label style="font-size:.74rem">Ano</label>
        <select name="ano" style="padding:.4rem .6rem;font-size:.88rem">
          <?php for($y=date('Y');$y>=date('Y')-4;$y--): ?>
            <option value="<?=$y?>" <?=$ano===$y?'selected':''?>><?=$y?></option>
          <?php endfor; ?>
        </select>
      </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary btn-sm">Filtrar</button>
  </form>

  <!-- KPIs -->
  <div class="kpi-row">
    <div class="kpi-mini gold">
      <div class="ico">💰</div>
      <div class="val" style="font-size:1.4rem;color:var(--gold)">
        R$ <?= number_format((float)$kpis['receita'],2,',','.') ?>
      </div>
      <div class="lbl">Receita</div>
    </div>
    <div class="kpi-mini">
      <div class="ico">🧾</div>
      <div class="val"><?= $kpis['qtd_pedidos'] ?></div>
      <div class="lbl">Pedidos entregues</div>
    </div>
    <div class="kpi-mini">
      <div class="ico">🎯</div>
      <div class="val" style="font-size:1.3rem">R$ <?= number_format($ticketMedio,2,',','.') ?></div>
      <div class="lbl">Ticket médio</div>
    </div>
    <div class="kpi-mini green">
      <div class="ico">📅</div>
      <div class="val"><?= $totalReservas ?></div>
      <div class="lbl">Reservas</div>
    </div>
  </div>

  <!-- Gráficos superiores: Receita + Reservas -->
  <div class="graficos-grid">

    <!-- Gráfico de receita -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title">
        💰 Receita
        <span style="font-size:.75rem;color:var(--muted);font-weight:400;margin-left:.4rem">
          por <?= $periodo==='dia'?'hora':($periodo==='mes'?'dia':'mês') ?>
        </span>
      </div>
      <?php if (!empty($receitaEvolData)): ?>
        <div class="chart-container">
          <canvas id="chartReceita"></canvas>
        </div>
      <?php else: ?>
        <div class="empty-state" style="padding:2rem 0"><div class="empty-icon" style="font-size:2rem">📊</div><p>Sem dados neste período.</p></div>
      <?php endif; ?>
    </div>

    <!-- Gráfico de reservas por período -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title">
        📅 Reservas
        <span style="font-size:.75rem;color:var(--muted);font-weight:400;margin-left:.4rem">
          por <?= $periodo==='dia'?'hora':($periodo==='mes'?'dia':'mês') ?>
        </span>
      </div>
      <?php if (!empty($reservasEvol)): ?>
        <div class="chart-container">
          <canvas id="chartReservas"></canvas>
        </div>
      <?php else: ?>
        <div class="empty-state" style="padding:2rem 0"><div class="empty-icon" style="font-size:2rem">📅</div><p>Sem reservas neste período.</p></div>
      <?php endif; ?>
    </div>

  </div>

  <!-- Gráfico pratos mais vendidos -->
  <div class="card" style="margin-bottom:1.4rem">
    <div class="card-title">
      🏆 Pratos mais vendidos
      <span style="font-size:.75rem;color:var(--muted);font-weight:400;margin-left:.4rem">— <?= $tituloPeriodo ?></span>
    </div>
    <?php if (!empty($rankingPratos)): ?>
      <div class="chart-container" style="height:260px">
        <canvas id="chartPratos"></canvas>
      </div>
    <?php else: ?>
      <div class="empty-state" style="padding:2rem 0"><div class="empty-icon" style="font-size:2rem">🍽️</div><p>Sem vendas registradas neste período.</p></div>
    <?php endif; ?>
  </div>

  <!-- Status de reservas + tabela de pratos -->
  <div class="graficos-grid">

    <!-- Donut reservas por status -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title">📊 Reservas por status</div>
      <?php if (!empty($reservasStatus)): ?>
        <div class="chart-container" style="height:200px">
          <canvas id="chartStatus"></canvas>
        </div>
        <!-- Legenda manual -->
        <div style="display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.8rem;justify-content:center">
          <?php
          $bmap = ['Confirmada'=>'confirmada','Cancelada'=>'cancelada','Concluída'=>'concluida','Pendente'=>'pendente'];
          foreach ($reservasStatus as $st => $qt): ?>
            <span class="badge badge-<?= $bmap[$st]??'pendente' ?>"><?= $st ?>: <?= $qt ?></span>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="empty-state" style="padding:2rem 0"><p>Sem reservas neste período.</p></div>
      <?php endif; ?>
    </div>

    <!-- Tabela top pratos -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title">🥇 Ranking de pratos</div>
      <?php if (!empty($rankingPratos)): ?>
      <div class="table-wrap" style="border:none">
        <table>
          <thead><tr><th>#</th><th>Prato</th><th>Qtd</th><th>Receita</th></tr></thead>
          <tbody>
          <?php foreach ($rankingPratos as $i => $pr): ?>
          <tr>
            <td style="font-size:.9rem">
              <?= $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':($i+1).'.')) ?>
            </td>
            <td style="font-weight:500;font-size:.85rem"><?= htmlspecialchars($pr['nome']) ?></td>
            <td style="color:var(--gold);font-weight:600"><?= $pr['qtd'] ?>×</td>
            <td style="font-family:var(--font-display);color:var(--gold);font-size:.9rem">
              R$ <?= number_format((float)$pr['receita'],2,',','.') ?>
            </td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php else: ?>
        <div class="empty-state" style="padding:2rem 0"><p>Sem dados.</p></div>
      <?php endif; ?>
    </div>

  </div>

  </main>
</div>

<!-- Chart.js via CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// ── Paleta ─────────────────────────────────────────────────
const GOLD      = '#C9A84C';
const GOLD_DIM  = 'rgba(201,168,76,0.15)';
const GREEN     = '#4A7C59';
const GREEN_DIM = 'rgba(74,124,89,0.15)';
const MUTED     = '#7A7470';
const TEXT      = '#C8BFA8';

Chart.defaults.color = TEXT;
Chart.defaults.borderColor = '#2e2e2e';
Chart.defaults.font.family = "'Inter', sans-serif";

const tooltipStyle = {
  backgroundColor: '#1e1e1e',
  borderColor: 'rgba(201,168,76,0.3)',
  borderWidth: 1,
  titleColor: GOLD,
  bodyColor: TEXT,
  padding: 10,
  cornerRadius: 8,
};

// ── Labels dinâmicos ────────────────────────────────────────
const PERIODO  = <?= json_encode($periodo) ?>;
const MESES_PT = ['','Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

function makeLabel(val) {
  if (PERIODO === 'ano')  return MESES_PT[val] || val;
  if (PERIODO === 'dia')  return val + 'h';
  return 'Dia ' + val;
}

// ── Gráfico de Receita (barras) ─────────────────────────────
<?php if (!empty($receitaEvolData)): ?>
(function(){
  const labels  = <?= json_encode(array_column($receitaEvolData, 'label')) ?>;
  const valores = <?= json_encode(array_map(fn($r) => round((float)$r['receita'], 2), $receitaEvolData)) ?>;

  new Chart(document.getElementById('chartReceita'), {
    type: 'bar',
    data: {
      labels: labels.map(makeLabel),
      datasets: [{
        label: 'Receita (R$)',
        data: valores,
        backgroundColor: GOLD_DIM,
        borderColor: GOLD,
        borderWidth: 2,
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          ...tooltipStyle,
          callbacks: {
            label: ctx => ' R$ ' + ctx.parsed.y.toLocaleString('pt-BR', {minimumFractionDigits:2})
          }
        }
      },
      scales: {
        x: { grid: { color: '#1e1e1e' }, ticks: { color: MUTED, font: { size: 11 } } },
        y: {
          grid: { color: '#2e2e2e' },
          ticks: {
            color: MUTED, font: { size: 11 },
            callback: v => 'R$ ' + (v >= 1000 ? (v/1000).toFixed(1)+'k' : v)
          }
        }
      }
    }
  });
})();
<?php endif; ?>

// ── Gráfico de Reservas (linha) ──────────────────────────────
<?php if (!empty($reservasEvol)): ?>
(function(){
  const labels = <?= json_encode(array_column($reservasEvol, 'dia')) ?>;
  const totais = <?= json_encode(array_column($reservasEvol, 'total')) ?>;

  new Chart(document.getElementById('chartReservas'), {
    type: 'line',
    data: {
      labels: labels.map(makeLabel),
      datasets: [{
        label: 'Reservas',
        data: totais,
        borderColor: GREEN,
        backgroundColor: GREEN_DIM,
        borderWidth: 2,
        pointBackgroundColor: GREEN,
        pointRadius: 4,
        pointHoverRadius: 6,
        fill: true,
        tension: 0.35,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          ...tooltipStyle,
          callbacks: { label: ctx => ' ' + ctx.parsed.y + ' reserva(s)' }
        }
      },
      scales: {
        x: { grid: { color: '#1e1e1e' }, ticks: { color: MUTED, font: { size: 11 } } },
        y: {
          grid: { color: '#2e2e2e' },
          ticks: { color: MUTED, font: { size: 11 }, stepSize: 1 },
          beginAtZero: true
        }
      }
    }
  });
})();
<?php endif; ?>

// ── Gráfico Pratos mais vendidos (barras horizontais) ────────
<?php if (!empty($rankingPratos)): ?>
(function(){
  const nomes   = <?= json_encode(array_column($rankingPratos, 'nome')) ?>;
  const qtds    = <?= json_encode(array_map(fn($r) => (int)$r['qtd'], $rankingPratos)) ?>;
  const receitas= <?= json_encode(array_map(fn($r) => round((float)$r['receita'],2), $rankingPratos)) ?>;

  // Cores degradê dourado para cada barra
  const colors = nomes.map((_, i) => `rgba(201,168,76,${1 - i * 0.07})`);

  new Chart(document.getElementById('chartPratos'), {
    type: 'bar',
    data: {
      labels: nomes,
      datasets: [{
        label: 'Unidades vendidas',
        data: qtds,
        backgroundColor: colors,
        borderColor: GOLD,
        borderWidth: 1,
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          ...tooltipStyle,
          callbacks: {
            label: ctx => ' ' + ctx.parsed.x + ' un. vendidas',
            afterLabel: ctx => ' R$ ' + receitas[ctx.dataIndex].toLocaleString('pt-BR',{minimumFractionDigits:2})
          }
        }
      },
      scales: {
        x: {
          grid: { color: '#2e2e2e' },
          ticks: { color: MUTED, font: { size: 11 }, stepSize: 1 }
        },
        y: {
          grid: { display: false },
          ticks: { color: TEXT, font: { size: 12 } }
        }
      }
    }
  });
})();
<?php endif; ?>

// ── Gráfico Donut — Reservas por status ──────────────────────
<?php if (!empty($reservasStatus)): ?>
(function(){
  const labels = <?= json_encode(array_keys($reservasStatus)) ?>;
  const dados  = <?= json_encode(array_values($reservasStatus)) ?>;
  const paleta = { Confirmada:'#4A7C59', Cancelada:'#C0504A', Concluída:'#3D6B8E', Pendente:'#C9913A' };
  const cores  = labels.map(l => paleta[l] || GOLD);

  new Chart(document.getElementById('chartStatus'), {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: dados,
        backgroundColor: cores.map(c => c + '99'),
        borderColor: cores,
        borderWidth: 2,
        hoverOffset: 8,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      cutout: '68%',
      plugins: {
        legend: { display: false },
        tooltip: {
          ...tooltipStyle,
          callbacks: {
            label: ctx => ' ' + ctx.label + ': ' + ctx.parsed + ' reserva(s)'
          }
        }
      }
    }
  });
})();
<?php endif; ?>
</script>
</body>
</html>
