<?php
require_once '../../includes/auth.php';
requireLogin();
$perfil = usuarioAtual()['perfil'];
if (!in_array($perfil, ['Administrador','Caixa'])) { header('Location: ../painel.php'); exit; }

$db = getDB();

// Fechar pedido (marcar como Entregue)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fechar_pedido'])) {
    $pid = (int)$_POST['pedido_id'];
    $db->prepare("UPDATE pedidos SET status='Entregue' WHERE id=?")->execute([$pid]);
    header('Location: caixa.php?ok=1'); exit;
}

// Pedidos prontos (aguardando pagamento)
$prontos = $db->query(
    "SELECT p.id, p.status, p.observacao, p.total, p.criado_em, c.nome AS cliente
     FROM pedidos p JOIN clientes c ON c.id=p.cliente_id
     WHERE p.status = 'Pronto'
     ORDER BY p.criado_em ASC"
)->fetchAll();

// Itens
$itensPorPedido = [];
if (!empty($prontos)) {
    $ids = implode(',', array_column($prontos,'id'));
    foreach ($db->query(
        "SELECT ip.pedido_id, pr.nome, ip.quantidade, ip.preco_unit, ip.subtotal
         FROM itens_pedido ip JOIN pratos pr ON pr.id=ip.prato_id WHERE ip.pedido_id IN ($ids)"
    )->fetchAll() as $it) {
        $itensPorPedido[$it['pedido_id']][] = $it;
    }
}

// Resumo do dia
$resumo = $db->query(
    "SELECT COUNT(*) AS qtd, COALESCE(SUM(total),0) AS total
     FROM pedidos WHERE status='Entregue' AND DATE(criado_em)=CURDATE()"
)->fetch();

$tituloPagina = 'Caixa';
$paginaAtiva  = 'caixa';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>

  <div class="page-header">
    <h1>💰 Caixa</h1>
    <p>Pedidos prontos aguardando pagamento</p>
  </div>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">✅ Pedido fechado com sucesso!</div>
  <?php endif; ?>

  <!-- Resumo do dia -->
  <div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-bottom:1.5rem">
    <div class="stat-card">
      <div class="stat-icon">🧾</div>
      <div class="stat-value"><?= $resumo['qtd'] ?></div>
      <div class="stat-label">Pedidos fechados hoje</div>
    </div>
    <div class="stat-card" style="border-left:3px solid var(--accent)">
      <div class="stat-icon">💰</div>
      <div class="stat-value" style="font-size:1.5rem">R$ <?= number_format((float)$resumo['total'],2,',','.') ?></div>
      <div class="stat-label">Receita do dia</div>
    </div>
    <div class="stat-card" style="border-left:3px solid var(--warning)">
      <div class="stat-icon">⏳</div>
      <div class="stat-value"><?= count($prontos) ?></div>
      <div class="stat-label">Aguardando pagamento</div>
    </div>
  </div>

  <?php if (empty($prontos)): ?>
    <div class="empty-state">
      <div class="empty-icon">🟢</div>
      <h3>Nenhum pedido aguardando pagamento</h3>
      <p>Os pedidos marcados como "Pronto" pela cozinha aparecerão aqui.</p>
    </div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.2rem">
    <?php foreach ($prontos as $p):
      $itens = $itensPorPedido[$p['id']] ?? [];
    ?>
    <div class="card" style="border-left:4px solid var(--accent)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
        <div>
          <span style="font-weight:700;font-size:1.05rem;color:var(--primary)">#<?= $p['id'] ?></span>
          <span style="font-size:.83rem;color:var(--muted);margin-left:.5rem">
            <?= date('H:i',strtotime($p['criado_em'])) ?>
          </span>
        </div>
        <span class="badge badge-pronto">Pronto</span>
      </div>

      <div style="font-size:.85rem;color:var(--muted);margin-bottom:.8rem">
        👤 <?= htmlspecialchars($p['cliente']) ?>
      </div>

      <!-- Itens -->
      <?php foreach ($itens as $it): ?>
      <div style="display:flex;justify-content:space-between;font-size:.88rem;padding:.25rem 0;border-bottom:1px solid var(--border)">
        <span><?= $it['quantidade'] ?>x <?= htmlspecialchars($it['nome']) ?></span>
        <span>R$ <?= number_format((float)$it['subtotal'],2,',','.') ?></span>
      </div>
      <?php endforeach; ?>

      <?php if ($p['observacao']): ?>
        <div style="font-size:.8rem;color:var(--muted);margin-top:.4rem">📝 <?= htmlspecialchars($p['observacao']) ?></div>
      <?php endif; ?>

      <!-- Total -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:1rem;padding-top:.7rem;border-top:2px solid var(--border)">
        <span style="font-weight:700;font-size:1.1rem;font-family:'Playfair Display',serif;color:var(--accent)">
          R$ <?= number_format((float)$p['total'],2,',','.') ?>
        </span>
        <form method="POST">
          <input type="hidden" name="pedido_id"    value="<?= $p['id'] ?>">
          <input type="hidden" name="fechar_pedido" value="1">
          <button type="submit" class="btn btn-primary btn-sm">✅ Receber pagamento</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  </main>
</div>
</body>
</html>
