<?php
require_once '../../includes/auth.php';
requireLogin();
$perfil = usuarioAtual()['perfil'];
if (!in_array($perfil, ['Administrador','Cozinheiro'])) { header('Location: ../painel.php'); exit; }

$db = getDB();

// Atualizar status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pedido_id'])) {
    $pid    = (int)$_POST['pedido_id'];
    $status = $_POST['novo_status'] ?? '';
    if (in_array($status, ['Em preparo','Pronto'])) {
        $db->prepare("UPDATE pedidos SET status=? WHERE id=?")->execute([$status, $pid]);
    }
    header('Location: cozinha.php'); exit;
}

// Pedidos que a cozinha precisa ver
$pedidos = $db->query(
    "SELECT p.id, p.status, p.observacao, p.criado_em, c.nome AS cliente
     FROM pedidos p JOIN clientes c ON c.id=p.cliente_id
     WHERE p.status IN ('Aguardando','Em preparo')
     ORDER BY p.criado_em ASC"
)->fetchAll();

$itensPorPedido = [];
if (!empty($pedidos)) {
    $ids = implode(',', array_column($pedidos,'id'));
    foreach ($db->query(
        "SELECT ip.pedido_id, pr.nome, ip.quantidade
         FROM itens_pedido ip JOIN pratos pr ON pr.id=ip.prato_id
         WHERE ip.pedido_id IN ($ids) ORDER BY ip.id"
    )->fetchAll() as $it) {
        $itensPorPedido[$it['pedido_id']][] = $it;
    }
}

$tituloPagina = 'Cozinha';
$paginaAtiva  = 'cozinha';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
.cozinha-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:1.2rem; }
.cozinha-card { background:var(--surface); border:2px solid var(--border); border-radius:12px; padding:1.2rem; position:relative; }
.cozinha-card.aguardando { border-color:#E8C04A; }
.cozinha-card.preparo    { border-color:var(--accent); }
.cozinha-tempo {
  position:absolute; top:1rem; right:1rem;
  font-size:.75rem; color:var(--muted);
  background:var(--bg); padding:.2rem .5rem;
  border-radius:99px;
}
.item-linha-coz {
  display:flex; align-items:center; gap:.5rem;
  padding:.35rem 0; border-bottom:1px solid var(--border);
  font-size:.9rem;
}
.item-linha-coz:last-child { border-bottom:none; }
.item-qtd {
  background:var(--primary); color:#fff;
  font-weight:700; font-size:.8rem;
  width:26px; height:26px; border-radius:50%;
  display:flex; align-items:center; justify-content:center;
  flex-shrink:0;
}
</style>

  <div class="page-header" style="display:flex;align-items:center;justify-content:space-between">
    <div>
      <h1>👨‍🍳 Fila da cozinha</h1>
      <p><?= count($pedidos) ?> pedido<?= count($pedidos)!==1?'s':'' ?> aguardando</p>
    </div>
    <button onclick="location.reload()" class="btn btn-outline btn-sm">🔄 Atualizar</button>
  </div>

  <?php if (empty($pedidos)): ?>
    <div class="empty-state">
      <div class="empty-icon">✅</div>
      <h3>Tudo em dia!</h3>
      <p>Nenhum pedido aguardando preparo no momento.</p>
    </div>
  <?php else: ?>
  <div class="cozinha-grid">
    <?php foreach ($pedidos as $p):
      $itens    = $itensPorPedido[$p['id']] ?? [];
      $minutos  = (int)round((time() - strtotime($p['criado_em'])) / 60);
      $classCss = $p['status'] === 'Em preparo' ? 'preparo' : 'aguardando';
    ?>
    <div class="cozinha-card <?= $classCss ?>">
      <div class="cozinha-tempo">⏱ <?= $minutos ?>min atrás</div>

      <div style="margin-bottom:.8rem">
        <span style="font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:.05em">Pedido</span>
        <span style="font-weight:700;font-size:1.1rem;color:var(--primary);margin-left:.3rem">#<?= $p['id'] ?></span>
        <span class="badge <?= $p['status']==='Em preparo'?'badge-preparo':'badge-aguardando' ?>" style="margin-left:.5rem">
          <?= $p['status'] ?>
        </span>
      </div>

      <div style="font-size:.83rem;color:var(--muted);margin-bottom:.8rem">
        👤 <?= htmlspecialchars($p['cliente']) ?>
      </div>

      <div style="margin-bottom:.8rem">
        <?php foreach ($itens as $it): ?>
        <div class="item-linha-coz">
          <span class="item-qtd"><?= $it['quantidade'] ?></span>
          <span><?= htmlspecialchars($it['nome']) ?></span>
        </div>
        <?php endforeach; ?>
      </div>

      <?php if ($p['observacao']): ?>
        <div class="alert alert-warn" style="font-size:.82rem;padding:.5rem .8rem;margin-bottom:.8rem">
          📝 <?= htmlspecialchars($p['observacao']) ?>
        </div>
      <?php endif; ?>

      <form method="POST">
        <input type="hidden" name="pedido_id" value="<?= $p['id'] ?>">
        <?php if ($p['status'] === 'Aguardando'): ?>
          <input type="hidden" name="novo_status" value="Em preparo">
          <button type="submit" class="btn btn-accent btn-full">👨‍🍳 Iniciar preparo</button>
        <?php else: ?>
          <input type="hidden" name="novo_status" value="Pronto">
          <button type="submit" class="btn btn-primary btn-full">✅ Marcar como pronto</button>
        <?php endif; ?>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Auto-refresh a cada 30s -->
  <script>setTimeout(()=>location.reload(), 30000);</script>

  </main>
</div>
</body>
</html>
