<?php
require_once '../../includes/auth.php';
requireLogin();
$perfil = usuarioAtual()['perfil'];
if (!in_array($perfil, ['Administrador','Garçom'])) { header('Location: ../painel.php'); exit; }

$db = getDB();

// Atualizar status do pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_status'])) {
    $pid    = (int)$_POST['pedido_id'];
    $status = $_POST['novo_status'] ?? '';
    $validos = ['Aguardando','Em preparo','Pronto','Entregue','Cancelado'];
    if ($pid && in_array($status, $validos)) {
        $db->prepare("UPDATE pedidos SET status=? WHERE id=?")->execute([$status, $pid]);
    }
    header('Location: pedidos.php?ok=1'); exit;
}

// Novo pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['novo_pedido'])) {
    $clienteId  = (int)($_POST['cliente_id'] ?? 0);
    $observacao = trim($_POST['observacao'] ?? '');
    $uid        = (int)usuarioAtual()['id'];
    $itensIds   = $_POST['prato_id']    ?? [];
    $itensQtd   = $_POST['quantidade']  ?? [];

    if ($clienteId && !empty($itensIds)) {
        $total = 0;
        $linhas = [];
        foreach ($itensIds as $i => $pid) {
            $pid = (int)$pid;
            $qty = max(1,(int)($itensQtd[$i] ?? 1));
            $p = $db->prepare("SELECT id, preco FROM pratos WHERE id=? AND status='Disponível'");
            $p->execute([$pid]);
            $prato = $p->fetch();
            if ($prato) {
                $total += $prato['preco'] * $qty;
                $linhas[] = ['prato_id'=>$pid,'qty'=>$qty,'preco'=>$prato['preco']];
            }
        }
        $db->prepare(
            "INSERT INTO pedidos (cliente_id,usuario_id,status,observacao,total) VALUES (?,?,'Aguardando',?,?)"
        )->execute([$clienteId,$uid,$observacao?:null,$total]);
        $pedidoId = (int)$db->lastInsertId();
        foreach ($linhas as $l) {
            $db->prepare(
                "INSERT INTO itens_pedido (pedido_id,prato_id,quantidade,preco_unit) VALUES (?,?,?,?)"
            )->execute([$pedidoId,$l['prato_id'],$l['qty'],$l['preco']]);
        }
        header('Location: pedidos.php?ok=1'); exit;
    }
}

// Filtro de status
$filtroStatus = $_GET['status'] ?? 'abertos';
$where  = 'WHERE 1=1';
$params = [];
if ($filtroStatus === 'abertos') {
    $where .= " AND p.status NOT IN ('Entregue','Cancelado')";
} elseif ($filtroStatus !== 'todos') {
    $where .= ' AND p.status = ?';
    $params[] = ucfirst($filtroStatus);
}

$pedidos = $db->prepare(
    "SELECT p.id, p.status, p.total, p.observacao, p.criado_em,
            c.nome AS cliente, u.nome AS funcionario
     FROM pedidos p
     JOIN clientes c  ON c.id = p.cliente_id
     JOIN usuarios u  ON u.id = p.usuario_id
     $where ORDER BY p.criado_em DESC"
);
$pedidos->execute($params);
$pedidos = $pedidos->fetchAll();

// Itens de cada pedido
$itensPorPedido = [];
if (!empty($pedidos)) {
    $ids = implode(',', array_column($pedidos,'id'));
    foreach ($db->query(
        "SELECT ip.pedido_id, pr.nome, ip.quantidade, ip.preco_unit, ip.subtotal
         FROM itens_pedido ip JOIN pratos pr ON pr.id=ip.prato_id
         WHERE ip.pedido_id IN ($ids) ORDER BY ip.id"
    )->fetchAll() as $it) {
        $itensPorPedido[$it['pedido_id']][] = $it;
    }
}

// Para o formulário de novo pedido
$clientes = $db->query("SELECT id, nome FROM clientes ORDER BY nome")->fetchAll();
$pratos   = $db->query(
    "SELECT p.id, p.nome, p.preco, c.nome AS categoria
     FROM pratos p JOIN categorias_prato c ON c.id=p.categoria_id
     WHERE p.status='Disponível' ORDER BY c.nome, p.nome"
)->fetchAll();

$tituloPagina = 'Pedidos';
$paginaAtiva  = 'pedidos';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>
<style>
.pedido-row { cursor:pointer; }
.pedido-itens {
  display:none;
  background:var(--bg);
  padding:.8rem 1rem;
  border-top:1px solid var(--border);
}
.pedido-itens.open { display:block; }
.itens-mini-table { width:100%; font-size:.83rem; border-collapse:collapse; }
.itens-mini-table td { padding:.3rem .5rem; color:var(--text-2); }
.itens-mini-table td:last-child { text-align:right; color:var(--gold); }

.novo-pedido-grid {
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:1rem;
}
.prato-linha {
  display:flex;align-items:center;gap:.6rem;
  padding:.4rem 0;border-bottom:1px solid var(--border);
  font-size:.85rem;
}
.prato-linha:last-child{border-bottom:none}
.prato-linha input[type=number]{
  width:60px;padding:.25rem .4rem;
  background:var(--bg);border:1px solid var(--border);
  border-radius:6px;color:var(--text);font-size:.82rem;
  text-align:center;
}
.prato-linha label{flex:1;cursor:pointer}
.prato-linha input[type=checkbox]{accent-color:var(--gold)}
</style>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div><h1>Pedidos</h1><p><?= count($pedidos) ?> pedido<?= count($pedidos)!==1?'s':'' ?></p></div>
    <button onclick="document.getElementById('modal-novo').style.display='flex'" class="btn btn-primary btn-sm">➕ Novo pedido</button>
  </div>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">✅ Operação realizada com sucesso!</div>
  <?php endif; ?>

  <!-- Filtros de status -->
  <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.4rem">
    <?php
    $filtros = [
      'abertos' => 'Em aberto',
      'todos'   => 'Todos',
      'Aguardando' => 'Aguardando',
      'Em preparo' => 'Em preparo',
      'Pronto'     => 'Pronto',
      'Entregue'   => 'Entregue',
      'Cancelado'  => 'Cancelado',
    ];
    foreach ($filtros as $val => $label):
      $ativo = $filtroStatus === $val; ?>
      <a href="?status=<?= urlencode($val) ?>"
         class="btn btn-sm <?= $ativo ? 'btn-primary' : 'btn-ghost' ?>">
        <?= $label ?>
      </a>
    <?php endforeach; ?>
  </div>

  <?php if (empty($pedidos)): ?>
    <div class="empty-state"><div class="empty-icon">🧾</div><h3>Nenhum pedido encontrado</h3></div>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>#</th><th>Cliente</th><th>Funcionário</th><th>Status</th><th>Total</th><th>Criado em</th><th>Ação</th></tr>
      </thead>
      <tbody>
      <?php foreach ($pedidos as $p):
        $bm = ['Aguardando'=>'aguardando','Em preparo'=>'preparo','Pronto'=>'pronto','Entregue'=>'entregue','Cancelado'=>'cancelada'];
        $b  = $bm[$p['status']] ?? 'aguardando';
        $itens = $itensPorPedido[$p['id']] ?? [];
      ?>
      <tr class="pedido-row" onclick="toggleItens(<?= $p['id'] ?>)">
        <td style="color:var(--muted);font-size:.8rem">#<?= $p['id'] ?></td>
        <td style="font-weight:500"><?= htmlspecialchars($p['cliente']) ?></td>
        <td style="font-size:.82rem;color:var(--muted)"><?= htmlspecialchars($p['funcionario']) ?></td>
        <td><span class="badge badge-<?= $b ?>"><?= $p['status'] ?></span></td>
        <td style="font-family:var(--font-display);color:var(--gold)">R$ <?= number_format((float)$p['total'],2,',','.') ?></td>
        <td style="font-size:.8rem;color:var(--muted)"><?= date('d/m/Y H:i',strtotime($p['criado_em'])) ?></td>
        <td onclick="event.stopPropagation()">
          <form method="POST" style="display:flex;gap:.3rem">
            <input type="hidden" name="atualizar_status" value="1">
            <input type="hidden" name="pedido_id" value="<?= $p['id'] ?>">
            <select name="novo_status" style="font-size:.8rem;padding:.25rem .4rem;border-radius:6px;border:1px solid var(--border);background:var(--surface);color:var(--text)">
              <?php foreach (['Aguardando','Em preparo','Pronto','Entregue','Cancelado'] as $s): ?>
                <option value="<?= $s ?>" <?= $p['status']===$s?'selected':'' ?>><?= $s ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">✓</button>
          </form>
        </td>
      </tr>
      <!-- Linha expansível com itens -->
      <tr id="itens-<?= $p['id'] ?>">
        <td colspan="7" style="padding:0;border-bottom:1px solid var(--border)">
          <div class="pedido-itens">
            <?php if ($p['observacao']): ?>
              <div class="alert alert-warn" style="font-size:.8rem;padding:.4rem .7rem;margin-bottom:.6rem">
                📝 <?= htmlspecialchars($p['observacao']) ?>
              </div>
            <?php endif; ?>
            <?php if (!empty($itens)): ?>
            <table class="itens-mini-table">
              <thead><tr>
                <td style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em">Item</td>
                <td style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em">Qtd</td>
                <td style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;text-align:right">Unit.</td>
                <td style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;text-align:right">Subtotal</td>
              </tr></thead>
              <tbody>
              <?php foreach ($itens as $it): ?>
              <tr>
                <td><?= htmlspecialchars($it['nome']) ?></td>
                <td><?= $it['quantidade'] ?>×</td>
                <td style="text-align:right">R$ <?= number_format((float)$it['preco_unit'],2,',','.') ?></td>
                <td>R$ <?= number_format((float)$it['subtotal'],2,',','.') ?></td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
            <?php else: ?>
              <p style="color:var(--muted);font-size:.83rem">Itens não disponíveis.</p>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <!-- Modal Novo Pedido -->
  <div id="modal-novo" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:999;align-items:flex-start;justify-content:center;overflow-y:auto;padding:2rem 1rem">
    <div style="background:var(--surface);border:1px solid var(--border-gold);border-radius:14px;padding:2rem;width:100%;max-width:680px;margin:auto">
      <h2 style="font-size:1.2rem;margin-bottom:1.4rem;color:var(--gold)">🧾 Novo pedido</h2>
      <form method="POST">
        <input type="hidden" name="novo_pedido" value="1">

        <div class="novo-pedido-grid">
          <div class="form-group">
            <label>Cliente</label>
            <select name="cliente_id" required>
              <option value="">Selecione o cliente...</option>
              <?php foreach ($clientes as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nome']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Observação</label>
            <input type="text" name="observacao" placeholder="Alergias, preferências...">
          </div>
        </div>

        <div class="form-group">
          <label>Pratos</label>
          <div style="border:1px solid var(--border);border-radius:var(--radius);padding:.8rem;max-height:300px;overflow-y:auto;background:var(--bg)">
            <?php
            $catAtual = '';
            foreach ($pratos as $pr):
              if ($pr['categoria'] !== $catAtual):
                $catAtual = $pr['categoria'];
            ?>
              <div style="font-size:.7rem;color:var(--gold);text-transform:uppercase;letter-spacing:.1em;margin:.8rem 0 .3rem;padding-top:.4rem;border-top:1px solid var(--border)">
                <?= htmlspecialchars($catAtual) ?>
              </div>
            <?php endif; ?>
            <div class="prato-linha">
              <input type="checkbox" name="prato_id[]" value="<?= $pr['id'] ?>" id="pr<?= $pr['id'] ?>"
                     onchange="toggleQty(this, <?= $pr['id'] ?>)">
              <label for="pr<?= $pr['id'] ?>"><?= htmlspecialchars($pr['nome']) ?></label>
              <span style="font-size:.78rem;color:var(--muted)">R$ <?= number_format((float)$pr['preco'],2,',','.') ?></span>
              <input type="number" name="quantidade[]" id="qty<?= $pr['id'] ?>"
                     value="1" min="1" max="20" disabled
                     style="opacity:.4">
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div style="display:flex;gap:.8rem;margin-top:.5rem">
          <button type="submit" class="btn btn-primary" style="flex:1">💾 Criar pedido</button>
          <button type="button" onclick="document.getElementById('modal-novo').style.display='none'" class="btn btn-ghost">Cancelar</button>
        </div>
      </form>
    </div>
  </div>

  </main>
</div>

<script>
function toggleItens(id) {
  const el = document.querySelector('#itens-' + id + ' .pedido-itens');
  if (el) el.classList.toggle('open');
}
function toggleQty(cb, id) {
  const qty = document.getElementById('qty' + id);
  qty.disabled = !cb.checked;
  qty.style.opacity = cb.checked ? '1' : '.4';
}
document.getElementById('modal-novo').addEventListener('click', function(e) {
  if (e.target === this) this.style.display = 'none';
});
</script>
</body>
</html>
