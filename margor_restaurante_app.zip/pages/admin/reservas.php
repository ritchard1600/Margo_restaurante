<?php
require_once '../../includes/auth.php';
requireLogin();
$perfil = usuarioAtual()['perfil'];
if (!in_array($perfil, ['Administrador','Garçom'])) { header('Location: ../painel.php'); exit; }

$db = getDB();

// Atualizar status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $rid    = (int)($_POST['reserva_id'] ?? 0);
    $status = $_POST['novo_status'] ?? '';
    if ($rid && in_array($status, ['Pendente','Confirmada','Cancelada','Concluída'])) {
        $db->prepare("UPDATE reservas SET status=? WHERE id=?")->execute([$status, $rid]);
    }
    header('Location: reservas.php?ok=1'); exit;
}

// Nova reserva interna
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nova_reserva'])) {
    $nome    = trim($_POST['nome'] ?? '');
    $data    = $_POST['data_reserva'] ?? '';
    $hora    = $_POST['hora_reserva'] ?? '';
    $pessoas = (int)($_POST['pessoas'] ?? 1);
    $uid     = (int)usuarioAtual()['id'];
    if ($nome && $data && $hora) {
        $validacao = validarHorarioReserva($data, $hora);
        if ($validacao === true) {
            $db->prepare(
                "INSERT INTO reservas (nome, data_reserva, hora_reserva, pessoas, status, origem, usuario_id)
                 VALUES (?,?,?,?,'Confirmada','interno',?)"
            )->execute([$nome, $data, $hora, $pessoas, $uid]);
        }
    }
    header('Location: reservas.php?ok=1'); exit;
}

// Filtros
$filtroData   = $_GET['data']   ?? date('Y-m-d');
$filtroStatus = $_GET['status'] ?? 'todas';

$where  = 'WHERE 1=1';
$params = [];
if ($filtroData)               { $where .= ' AND r.data_reserva = ?'; $params[] = $filtroData; }
if ($filtroStatus !== 'todas') { $where .= ' AND r.status = ?';       $params[] = ucfirst($filtroStatus); }

$stmt = $db->prepare(
    "SELECT r.*, c.nome AS cliente_nome
     FROM reservas r LEFT JOIN clientes c ON c.id = r.cliente_id
     $where ORDER BY r.data_reserva ASC, r.hora_reserva ASC"
);
$stmt->execute($params);
$reservas = $stmt->fetchAll();

$tituloPagina = 'Reservas';
$paginaAtiva  = 'reservas';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div><h1>Reservas</h1><p><?= count($reservas) ?> resultado(s)</p></div>
    <button onclick="document.getElementById('modal-nova').style.display='flex'" class="btn btn-primary btn-sm">➕ Nova reserva</button>
  </div>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">✅ Operação realizada com sucesso.</div>
  <?php endif; ?>

  <form method="GET" style="display:flex;gap:.8rem;flex-wrap:wrap;align-items:flex-end;margin-bottom:1.4rem">
    <div class="form-group" style="margin:0">
      <label style="font-size:.75rem">Data</label>
      <input type="date" name="data" value="<?= htmlspecialchars($filtroData) ?>" style="padding:.4rem .7rem;font-size:.88rem">
    </div>
    <div class="form-group" style="margin:0">
      <label style="font-size:.75rem">Status</label>
      <select name="status" style="padding:.4rem .7rem;font-size:.88rem">
        <?php foreach (['todas','Pendente','Confirmada','Cancelada','Concluída'] as $s): ?>
          <option value="<?= strtolower($s) ?>" <?= strtolower($filtroStatus)===strtolower($s)?'selected':'' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-primary btn-sm">Filtrar</button>
    <a href="reservas.php" class="btn btn-ghost btn-sm">Limpar</a>
  </form>

  <?php if (empty($reservas)): ?>
    <div class="empty-state"><div class="empty-icon">📅</div><h3>Nenhuma reserva encontrada</h3></div>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Nome</th><th>Data / Hora</th><th>Pessoas</th><th>Origem</th><th>Cliente vinculado</th><th>Status</th><th>Ação</th></tr></thead>
      <tbody>
      <?php foreach ($reservas as $r):
        $b = match($r['status']) { 'Confirmada'=>'confirmada','Cancelada'=>'cancelada','Concluída'=>'concluida',default=>'pendente' }; ?>
      <tr>
        <td style="color:var(--muted);font-size:.8rem">#<?= $r['id'] ?></td>
        <td style="font-weight:500"><?= htmlspecialchars($r['nome']) ?></td>
        <td><?= date('d/m/Y',strtotime($r['data_reserva'])) ?> <?= substr($r['hora_reserva'],0,5) ?></td>
        <td>👥 <?= $r['pessoas'] ?></td>
        <td style="font-size:.82rem"><?= $r['origem']==='online'?'🌐 Online':'🏠 Interno' ?></td>
        <td style="font-size:.82rem;color:var(--muted)"><?= $r['cliente_nome'] ? htmlspecialchars($r['cliente_nome']) : '—' ?></td>
        <td><span class="badge badge-<?= $b ?>"><?= $r['status'] ?></span></td>
        <td>
          <form method="POST" style="display:flex;gap:.3rem">
            <input type="hidden" name="reserva_id" value="<?= $r['id'] ?>">
            <input type="hidden" name="acao" value="1">
            <select name="novo_status" style="font-size:.8rem;padding:.25rem .4rem;border-radius:6px;border:1px solid var(--border);background:var(--surface);color:var(--text)">
              <?php foreach (['Pendente','Confirmada','Cancelada','Concluída'] as $s): ?>
                <option value="<?= $s ?>" <?= $r['status']===$s?'selected':'' ?>><?= $s ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">✓</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <div id="modal-nova" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:999;align-items:center;justify-content:center">
    <div style="background:var(--surface);border:1px solid var(--border-gold);border-radius:14px;padding:2rem;width:100%;max-width:420px;margin:1rem">
      <h2 style="font-size:1.2rem;margin-bottom:1.2rem;color:var(--gold)">📅 Nova reserva interna</h2>
      <form method="POST">
        <input type="hidden" name="nova_reserva" value="1">
        <div class="form-group"><label>Nome</label><input type="text" name="nome" required></div>
        <div class="form-row">
          <div class="form-group"><label>Data</label><input type="date" name="data_reserva" id="data_reserva_modal" value="<?= date('Y-m-d') ?>" required></div>
          <div class="form-group">
          <label>Horário</label>
          <input type="time" name="hora_reserva" id="hora_reserva_modal" required>
          <div class="horario-hint" id="msg-horario" style="display:none;font-size:.75rem;color:var(--gold);margin-top:.3rem;padding:.3rem .6rem;background:var(--gold-dim2);border-radius:6px;border:1px solid var(--border-gold)"></div>
        </div>
        <div style="font-size:.75rem;color:var(--muted);padding:.5rem;background:var(--bg);border-radius:6px;line-height:1.7;margin-bottom:.3rem">
          🕐 Seg–Qui: 12h–15h e 19h–23h · Sex–Sáb: 12h–00h · Dom: 12h–17h
        </div>
        </div>
        <div class="form-group">
          <label>Pessoas</label>
          <select name="pessoas">
            <?php for($i=1;$i<=20;$i++): ?><option value="<?=$i?>"><?=$i?> pessoa<?=$i>1?'s':''?></option><?php endfor; ?>
          </select>
        </div>
        <div style="display:flex;gap:.6rem;margin-top:.5rem">
          <button type="submit" class="btn btn-primary" style="flex:1">Salvar</button>
          <button type="button" onclick="document.getElementById('modal-nova').style.display='none'" class="btn btn-ghost">Cancelar</button>
        </div>
      </form>
    </div>
  </div>

  </main>
</div>
<script src="../../assets/js/reserva-picker.js"></script>
</body>
</html>
