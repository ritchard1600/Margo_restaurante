<?php
require_once '../../includes/auth.php';
requireLogin();
if (usuarioAtual()['perfil'] !== 'Administrador') { header('Location: ../painel.php'); exit; }

$db   = getDB();
$erro = '';

// Salvar usuário (novo ou edição)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_usuario'])) {
    $uid    = (int)($_POST['usuario_id'] ?? 0);
    $nome   = trim($_POST['nome']   ?? '');
    $email  = trim($_POST['email']  ?? '');
    $perfil = $_POST['perfil']  ?? '';
    $status = $_POST['status']  ?? 'Ativo';
    $senha  = $_POST['senha']   ?? '';

    $perfisValidos  = ['Administrador','Gerente','Garçom','Cozinheiro','Caixa'];
    $statusValidos  = ['Ativo','Inativo'];

    if (!$nome || !$email || !in_array($perfil, $perfisValidos)) {
        $erro = 'Preencha nome, e-mail e perfil corretamente.';
    } elseif (!$uid && !$senha) {
        $erro = 'Defina uma senha para o novo funcionário.';
    } else {
        // Checa e-mail duplicado
        $check = $db->prepare("SELECT id FROM usuarios WHERE email=? AND id!=? LIMIT 1");
        $check->execute([$email, $uid]);
        if ($check->fetch()) {
            $erro = 'Este e-mail já está em uso.';
        } else {
            if ($uid) {
                if ($senha) {
                    $db->prepare("UPDATE usuarios SET nome=?,email=?,senha=MD5(?),perfil=?,status=? WHERE id=?")
                       ->execute([$nome,$email,$senha,$perfil,$status,$uid]);
                } else {
                    $db->prepare("UPDATE usuarios SET nome=?,email=?,perfil=?,status=? WHERE id=?")
                       ->execute([$nome,$email,$perfil,$status,$uid]);
                }
            } else {
                $db->prepare("INSERT INTO usuarios (nome,email,senha,perfil,status) VALUES (?,?,MD5(?),?,?)")
                   ->execute([$nome,$email,$senha,$perfil,$status]);
            }
            header('Location: usuarios.php?ok=1'); exit;
        }
    }
}

// Inativar/ativar
if (isset($_GET['toggle'])) {
    $uid = (int)$_GET['toggle'];
    $db->prepare(
        "UPDATE usuarios SET status = IF(status='Ativo','Inativo','Ativo') WHERE id=? AND id!=1"
    )->execute([$uid]);
    header('Location: usuarios.php?ok=1'); exit;
}

// Editar
$usuEdit = null;
if (isset($_GET['editar'])) {
    $s = $db->prepare("SELECT * FROM usuarios WHERE id=? LIMIT 1");
    $s->execute([(int)$_GET['editar']]);
    $usuEdit = $s->fetch();
}

$usuarios = $db->query(
    "SELECT *, (SELECT COUNT(*) FROM pedidos  WHERE usuario_id=usuarios.id) AS total_pedidos,
              (SELECT COUNT(*) FROM reservas WHERE usuario_id=usuarios.id) AS total_reservas
     FROM usuarios ORDER BY perfil, nome"
)->fetchAll();

$corPerfil = fn($p) => match($p) {
    'Administrador' => '#C4714A', 'Gerente' => '#5A3D7A', 'Garçom' => '#3D5A45',
    'Cozinheiro' => '#7B5EA7',   'Caixa'   => '#2C6E8A',
    default => '#7A7A72'
};

$tituloPagina = 'Usuários';
$paginaAtiva  = 'usuarios';
$cssPath      = '../../assets/css/style.css';
require_once '../../includes/painel_layout.php';
?>

  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
    <div><h1>Usuários / Funcionários</h1><p><?= count($usuarios) ?> cadastrado<?= count($usuarios)!==1?'s':'' ?></p></div>
    <a href="usuarios.php?novo=1" class="btn btn-accent btn-sm">➕ Novo funcionário</a>
  </div>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">✅ Operação realizada com sucesso!</div>
  <?php endif; ?>
  <?php if ($erro): ?>
    <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
  <?php endif; ?>

  <!-- Formulário novo / edição -->
  <?php if (isset($_GET['novo']) || $usuEdit): ?>
  <div class="card" style="margin-bottom:1.5rem;border-left:4px solid var(--accent)">
    <div class="card-title"><?= $usuEdit ? 'Editar funcionário' : 'Novo funcionário' ?></div>
    <form method="POST">
      <input type="hidden" name="salvar_usuario" value="1">
      <input type="hidden" name="usuario_id" value="<?= $usuEdit['id'] ?? 0 ?>">
      <div class="form-row">
        <div class="form-group">
          <label>Nome</label>
          <input type="text" name="nome" value="<?= htmlspecialchars($usuEdit['nome'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label>E-mail</label>
          <input type="email" name="email" value="<?= htmlspecialchars($usuEdit['email'] ?? '') ?>" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label><?= $usuEdit ? 'Nova senha (deixe em branco para manter)' : 'Senha' ?></label>
          <div class="senha-wrap">
          <input type="password" name="senha" placeholder="••••••" <?= $usuEdit ? '' : 'required' ?>>
            <button type="button" class="btn-eye" onclick="toggleSenha(this)" tabindex="-1">👁️</button>
          </div>
        </div>
        <div class="form-group">
          <label>Perfil</label>
          <select name="perfil" required>
            <?php foreach (['Administrador','Gerente','Garçom','Cozinheiro','Caixa'] as $pf): ?>
              <option value="<?= $pf ?>" <?= ($usuEdit['perfil']??'')===$pf?'selected':'' ?>><?= $pf ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <option value="Ativo"   <?= ($usuEdit['status']??'Ativo')==='Ativo'?'selected':'' ?>>Ativo</option>
            <option value="Inativo" <?= ($usuEdit['status']??'')==='Inativo'?'selected':'' ?>>Inativo</option>
          </select>
        </div>
      </div>
      <div style="display:flex;gap:.6rem">
        <button type="submit" class="btn btn-primary">💾 Salvar</button>
        <a href="usuarios.php" class="btn btn-ghost">Cancelar</a>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <!-- Tabela -->
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Pedidos</th><th>Reservas</th><th>Status</th><th>Ações</th></tr>
      </thead>
      <tbody>
      <?php foreach ($usuarios as $u): ?>
      <tr style="<?= $u['status']==='Inativo'?'opacity:.6':'' ?>">
        <td style="font-weight:500"><?= htmlspecialchars($u['nome']) ?></td>
        <td style="font-size:.85rem"><?= htmlspecialchars($u['email']) ?></td>
        <td>
          <span style="display:inline-block;padding:.2rem .6rem;border-radius:99px;font-size:.72rem;font-weight:700;background:<?= $corPerfil($u['perfil']) ?>;color:#fff">
            <?= $u['perfil'] ?>
          </span>
        </td>
        <td style="text-align:center"><?= $u['total_pedidos'] ?></td>
        <td style="text-align:center"><?= $u['total_reservas'] ?></td>
        <td>
          <span class="badge <?= $u['status']==='Ativo'?'badge-confirmada':'badge-cancelada' ?>">
            <?= $u['status'] ?>
          </span>
        </td>
        <td>
          <div style="display:flex;gap:.4rem">
            <a href="?editar=<?= $u['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
            <?php if ($u['id'] != 1): ?>
            <a href="?toggle=<?= $u['id'] ?>"
               onclick="return confirm('<?= $u['status']==='Ativo'?'Inativar':'Ativar' ?> este usuário?')"
               class="btn btn-sm <?= $u['status']==='Ativo'?'btn-danger':'btn-primary' ?>">
               <?= $u['status']==='Ativo'?'🔴 Inativar':'🟢 Ativar' ?>
            </a>
            <?php else: ?>
              <span style="font-size:.75rem;color:var(--muted)">Admin master</span>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  </main>
</div>

<script>
function toggleSenha(btn) {
  const inp = btn.closest('.senha-wrap').querySelector('input');
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  btn.textContent = show ? '🙈' : '👁️';
}
</script>
</body>
</html>
