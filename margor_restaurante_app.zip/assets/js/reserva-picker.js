/**
 * reserva-picker.js
 * Seletor de data com dia/mês/ano separados + botões de horário por período
 */
(function () {
  'use strict';

  // ── Regras de horário ──────────────────────────────────────
  const SLOTS = {
    0: ['12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00'],
    1: ['12:00','12:30','13:00','13:30','14:00','14:30','15:00','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00'],
    2: ['12:00','12:30','13:00','13:30','14:00','14:30','15:00','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00'],
    3: ['12:00','12:30','13:00','13:30','14:00','14:30','15:00','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00'],
    4: ['12:00','12:30','13:00','13:30','14:00','14:30','15:00','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00'],
    5: ['12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00','23:30'],
    6: ['12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00','23:30'],
  };

  const MESES_NOMES = [
    'Janeiro','Fevereiro','Março','Abril','Maio','Junho',
    'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'
  ];

  const DIAS_SEMANA = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];

  // ── CSS ────────────────────────────────────────────────────
  const CSS = `
  /* Seletores separados dia/mês/ano */
  .rp-selects-row {
    display: grid;
    grid-template-columns: 1fr 1.6fr 1fr;
    gap: .5rem;
    margin-bottom: .8rem;
  }
  .rp-select-group { display: flex; flex-direction: column; gap: .3rem; }
  .rp-select-label {
    font-size: .68rem;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--muted, #7A7470);
    font-weight: 500;
    font-family: var(--font-body, sans-serif);
  }
  .rp-sel {
    width: 100%;
    background: var(--bg, #0f0f0f);
    border: 1px solid var(--border, #2e2e2e);
    border-radius: var(--radius, 10px);
    color: var(--text, #F5F0E8);
    font-size: .88rem;
    font-family: var(--font-body, sans-serif);
    padding: .65rem .8rem;
    cursor: pointer;
    transition: border-color .2s, box-shadow .2s;
    outline: none;
    appearance: none;
    -webkit-appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%237A7470' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right .7rem center;
    padding-right: 2rem;
  }
  .rp-sel:focus, .rp-sel:hover {
    border-color: var(--gold, #C9A84C);
    box-shadow: 0 0 0 3px rgba(201,168,76,0.1);
  }
  .rp-sel option { background: var(--surface, #1e1e1e); color: var(--text, #F5F0E8); }
  .rp-sel:disabled { opacity: .35; cursor: not-allowed; }

  /* Info do dia selecionado */
  .rp-dia-info {
    display: none;
    font-size: .78rem;
    color: var(--gold, #C9A84C);
    padding: .4rem .8rem;
    background: rgba(201,168,76,0.07);
    border: 1px solid rgba(201,168,76,0.2);
    border-radius: 8px;
    margin-bottom: .8rem;
  }
  .rp-dia-info.visible { display: block; }

  /* Slots de horário */
  .rp-slots-wrap { margin-top: .2rem; }
  .rp-slots-label {
    font-size: .7rem;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--muted, #7A7470);
    font-weight: 500;
    margin-bottom: .5rem;
    font-family: var(--font-body, sans-serif);
  }
  .rp-periodo-label {
    font-size: .7rem;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--gold, #C9A84C);
    margin: .6rem 0 .3rem;
    font-family: var(--font-body, sans-serif);
  }
  .rp-slots-grid {
    display: flex;
    flex-wrap: wrap;
    gap: .4rem;
  }
  .rp-slot {
    padding: .35rem .75rem;
    border-radius: 8px;
    font-size: .8rem;
    border: 1px solid var(--border, #2e2e2e);
    background: var(--bg, #0f0f0f);
    color: var(--text-2, #C8BFA8);
    cursor: pointer;
    transition: all .15s;
    font-family: var(--font-body, sans-serif);
  }
  .rp-slot:hover {
    border-color: var(--gold, #C9A84C);
    color: var(--gold, #C9A84C);
    background: rgba(201,168,76,0.06);
  }
  .rp-slot.selected {
    background: var(--gold, #C9A84C);
    color: #0f0f0f;
    border-color: var(--gold, #C9A84C);
    font-weight: 600;
  }
  .rp-selecione-data {
    font-size: .82rem;
    color: var(--muted, #7A7470);
    padding: .5rem 0;
    font-style: italic;
  }
  `;

  function injectCSS() {
    if (document.getElementById('rp-css')) return;
    const s = document.createElement('style');
    s.id = 'rp-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  function pad(n) { return String(n).padStart(2, '0'); }

  function getDiasNoMes(mes, ano) {
    return new Date(ano, mes, 0).getDate(); // mes é 1-12
  }

  function getDiaSemana(dia, mes, ano) {
    return new Date(ano, mes - 1, dia).getDay();
  }

  function getSlotsParaDia(diaSemana) {
    const todos = SLOTS[diaSemana] || [];
    const blocos = [];
    let atual = [];
    for (let i = 0; i < todos.length; i++) {
      if (i === 0) { atual.push(todos[i]); continue; }
      const [ph, pm] = todos[i-1].split(':').map(Number);
      const [ch, cm] = todos[i].split(':').map(Number);
      const diff = (ch * 60 + cm) - (ph * 60 + pm);
      if (diff > 30) { blocos.push(atual); atual = [todos[i]]; }
      else atual.push(todos[i]);
    }
    if (atual.length) blocos.push(atual);
    return blocos;
  }

  // ── Classe principal ───────────────────────────────────────
  function ReservaPicker(inputDate, inputHora, container) {
    this.inputDate = inputDate;
    this.inputHora = inputHora;

    const hoje = new Date();
    this.hojeAno  = hoje.getFullYear();
    this.hojeMes  = hoje.getMonth() + 1; // 1-12
    this.hojeDia  = hoje.getDate();

    // Estado selecionado
    this.selDia  = null;
    this.selMes  = null;
    this.selAno  = null;
    this.selHora = inputHora.value || null;

    // Restaurar valor existente
    if (inputDate.value) {
      const parts = inputDate.value.split('-');
      if (parts.length === 3) {
        this.selAno = parseInt(parts[0]);
        this.selMes = parseInt(parts[1]);
        this.selDia = parseInt(parts[2]);
      }
    }

    this._build(container);
  }

  ReservaPicker.prototype._build = function (container) {
    const self = this;

    // ── Row de selects ──────────────────────────────────────
    const row = document.createElement('div');
    row.className = 'rp-selects-row';

    // Select DIA
    const grpDia = document.createElement('div');
    grpDia.className = 'rp-select-group';
    const lblDia = document.createElement('div');
    lblDia.className = 'rp-select-label';
    lblDia.textContent = 'Dia';
    this.selDiaEl = document.createElement('select');
    this.selDiaEl.className = 'rp-sel';
    this.selDiaEl.disabled = true;
    grpDia.appendChild(lblDia);
    grpDia.appendChild(this.selDiaEl);

    // Select MÊS
    const grpMes = document.createElement('div');
    grpMes.className = 'rp-select-group';
    const lblMes = document.createElement('div');
    lblMes.className = 'rp-select-label';
    lblMes.textContent = 'Mês';
    this.selMesEl = document.createElement('select');
    this.selMesEl.className = 'rp-sel';
    const optMesPad = document.createElement('option');
    optMesPad.value = ''; optMesPad.textContent = 'Mês';
    this.selMesEl.appendChild(optMesPad);
    MESES_NOMES.forEach(function (nome, i) {
      const mes = i + 1;
      // Só mostra meses do ano selecionado a partir do mês atual
      const opt = document.createElement('option');
      opt.value = mes;
      opt.textContent = nome;
      if (self.selMes === mes) opt.selected = true;
      self.selMesEl.appendChild(opt);
    });
    grpMes.appendChild(lblMes);
    grpMes.appendChild(this.selMesEl);

    // Select ANO
    const grpAno = document.createElement('div');
    grpAno.className = 'rp-select-group';
    const lblAno = document.createElement('div');
    lblAno.className = 'rp-select-label';
    lblAno.textContent = 'Ano';
    this.selAnoEl = document.createElement('select');
    this.selAnoEl.className = 'rp-sel';
    const optAnoPad = document.createElement('option');
    optAnoPad.value = ''; optAnoPad.textContent = 'Ano';
    this.selAnoEl.appendChild(optAnoPad);
    for (let a = self.hojeAno; a <= self.hojeAno + 2; a++) {
      const opt = document.createElement('option');
      opt.value = a; opt.textContent = a;
      if (self.selAno === a) opt.selected = true;
      self.selAnoEl.appendChild(opt);
    }
    grpAno.appendChild(lblAno);
    grpAno.appendChild(this.selAnoEl);

    row.appendChild(grpDia);
    row.appendChild(grpMes);
    row.appendChild(grpAno);
    container.appendChild(row);

    // Info do dia da semana
    this.diaInfo = document.createElement('div');
    this.diaInfo.className = 'rp-dia-info';
    container.appendChild(this.diaInfo);

    // Slots
    this.slotsWrap = document.createElement('div');
    this.slotsWrap.className = 'rp-slots-wrap';
    const avisoData = document.createElement('div');
    avisoData.className = 'rp-selecione-data';
    avisoData.textContent = 'Selecione dia, mês e ano para ver os horários';
    this.slotsWrap.appendChild(avisoData);
    container.appendChild(this.slotsWrap);

    // ── Eventos ─────────────────────────────────────────────

    // Ao mudar o Ano — refiltra meses disponíveis
    this.selAnoEl.addEventListener('change', function () {
      self.selAno = parseInt(this.value) || null;
      self.selMes = null;
      self.selDia = null;
      self.selHora = null;
      self.inputDate.value = '';
      self.inputHora.value = '';
      self._filtrarMeses();
      self._resetDias();
      self._resetSlots();
    });

    // Ao mudar o Mês — popula dias
    this.selMesEl.addEventListener('change', function () {
      self.selMes = parseInt(this.value) || null;
      self.selDia = null;
      self.selHora = null;
      self.inputDate.value = '';
      self.inputHora.value = '';
      self._popularDias();
      self._resetSlots();
    });

    // Ao mudar o Dia — atualiza slots
    this.selDiaEl.addEventListener('change', function () {
      self.selDia = parseInt(this.value) || null;
      self.selHora = null;
      self.inputHora.value = '';
      self._atualizarData();
      self._renderSlots();
    });

    // Restaurar estado inicial se já tinha valor
    if (this.selAno) {
      this._filtrarMeses();
      if (this.selMes) {
        this.selMesEl.value = this.selMes;
        this._popularDias();
        if (this.selDia) {
          this.selDiaEl.value = this.selDia;
          this._atualizarData();
          if (this.selHora) this._renderSlots();
        }
      }
    }
  };

  ReservaPicker.prototype._filtrarMeses = function () {
    const self = this;
    const ano = self.selAno;
    if (!ano) return;

    Array.from(this.selMesEl.options).forEach(function (opt) {
      if (!opt.value) return; // placeholder
      const mes = parseInt(opt.value);
      // Desabilita meses passados no ano atual
      opt.disabled = (ano === self.hojeAno && mes < self.hojeMes);
    });

    // Se mês atual ficou inválido, resetar
    const mesAtual = parseInt(this.selMesEl.value);
    if (mesAtual && ano === this.hojeAno && mesAtual < this.hojeMes) {
      this.selMesEl.value = '';
    }
  };

  ReservaPicker.prototype._popularDias = function () {
    const self = this;
    const mes = self.selMes;
    const ano = self.selAno;

    this.selDiaEl.innerHTML = '';
    const pad0 = document.createElement('option');
    pad0.value = ''; pad0.textContent = 'Dia';
    this.selDiaEl.appendChild(pad0);

    if (!mes || !ano) {
      this.selDiaEl.disabled = true;
      return;
    }

    const totalDias = getDiasNoMes(mes, ano);
    const diaMin = (ano === self.hojeAno && mes === self.hojeMes) ? self.hojeDia : 1;

    for (let d = 1; d <= totalDias; d++) {
      const opt = document.createElement('option');
      opt.value = d;
      const ds = DIAS_SEMANA[getDiaSemana(d, mes, ano)];
      opt.textContent = pad(d) + ' — ' + ds;
      if (d < diaMin) opt.disabled = true;
      if (self.selDia === d) opt.selected = true;
      self.selDiaEl.appendChild(opt);
    }

    this.selDiaEl.disabled = false;
  };

  ReservaPicker.prototype._resetDias = function () {
    this.selDiaEl.innerHTML = '<option value="">Dia</option>';
    this.selDiaEl.disabled = true;
    this.diaInfo.className = 'rp-dia-info';
  };

  ReservaPicker.prototype._atualizarData = function () {
    const { selDia, selMes, selAno } = this;
    if (!selDia || !selMes || !selAno) return;

    const ds = DIAS_SEMANA[getDiaSemana(selDia, selMes, selAno)];
    const nomeMes = MESES_NOMES[selMes - 1];

    this.inputDate.value = selAno + '-' + pad(selMes) + '-' + pad(selDia);
    this.diaInfo.textContent = '📅 ' + ds + ', ' + pad(selDia) + ' de ' + nomeMes + ' de ' + selAno;
    this.diaInfo.className = 'rp-dia-info visible';
  };

  ReservaPicker.prototype._resetSlots = function () {
    this.slotsWrap.innerHTML = '';
    const aviso = document.createElement('div');
    aviso.className = 'rp-selecione-data';
    aviso.textContent = 'Selecione dia, mês e ano para ver os horários';
    this.slotsWrap.appendChild(aviso);
    this.diaInfo.className = 'rp-dia-info';
    this.inputDate.value = '';
  };

  ReservaPicker.prototype._renderSlots = function () {
    const self = this;
    const { selDia, selMes, selAno } = this;
    if (!selDia || !selMes || !selAno) return;

    const diaSemana = getDiaSemana(selDia, selMes, selAno);
    const blocos = getSlotsParaDia(diaSemana);
    const nomesBlocos = ['Almoço', 'Jantar'];

    this.slotsWrap.innerHTML = '';

    if (!blocos.length) {
      const el = document.createElement('div');
      el.className = 'rp-selecione-data';
      el.textContent = 'Sem horários disponíveis para este dia.';
      this.slotsWrap.appendChild(el);
      return;
    }

    const lblGeral = document.createElement('div');
    lblGeral.className = 'rp-slots-label';
    lblGeral.textContent = 'Horários disponíveis';
    this.slotsWrap.appendChild(lblGeral);

    blocos.forEach(function (bloco, bi) {
      if (blocos.length > 1) {
        const bl = document.createElement('div');
        bl.className = 'rp-periodo-label';
        bl.textContent = nomesBlocos[bi] || ('Período ' + (bi + 1));
        self.slotsWrap.appendChild(bl);
      }

      const grid = document.createElement('div');
      grid.className = 'rp-slots-grid';

      bloco.forEach(function (slot) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'rp-slot';
        btn.textContent = slot;
        if (self.selHora === slot) btn.classList.add('selected');

        btn.addEventListener('click', function () {
          self.slotsWrap.querySelectorAll('.rp-slot').forEach(function (b) {
            b.classList.remove('selected');
          });
          btn.classList.add('selected');
          self.selHora = slot;
          self.inputHora.value = slot;
        });

        grid.appendChild(btn);
      });

      self.slotsWrap.appendChild(grid);
    });

    // Restaurar seleção de hora se existir
    if (self.selHora) {
      self.slotsWrap.querySelectorAll('.rp-slot').forEach(function (btn) {
        if (btn.textContent === self.selHora) btn.classList.add('selected');
      });
    }
  };

  // ── Init ────────────────────────────────────────────────────
  function init() {
    injectCSS();

    document.querySelectorAll('[data-reserva-picker]').forEach(function (container) {
      const inputDate = container.querySelector('[data-rp-date]');
      const inputHora = container.querySelector('[data-rp-hora]');
      if (!inputDate || !inputHora) return;

      inputDate.style.display = 'none';
      inputHora.style.display = 'none';

      new ReservaPicker(inputDate, inputHora, container);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
