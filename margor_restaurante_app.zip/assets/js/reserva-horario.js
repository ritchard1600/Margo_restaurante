/**
 * reserva-horario.js
 * Controla o campo de horário conforme o dia da semana selecionado.
 *
 * Regras:
 *  Seg–Qui (1-4): 12:00–15:00 e 19:00–23:00
 *  Sex–Sáb (5-6): 12:00–23:59
 *  Domingo  (0) : 12:00–17:00
 */

(function () {
  'use strict';

  // Blocos por dia da semana (0=Dom … 6=Sáb)
  const BLOCOS = {
    0: [{ ini: '12:00', fim: '17:00' }],                               // Dom
    1: [{ ini: '12:00', fim: '15:00' }, { ini: '19:00', fim: '23:00' }], // Seg
    2: [{ ini: '12:00', fim: '15:00' }, { ini: '19:00', fim: '23:00' }], // Ter
    3: [{ ini: '12:00', fim: '15:00' }, { ini: '19:00', fim: '23:00' }], // Qua
    4: [{ ini: '12:00', fim: '15:00' }, { ini: '19:00', fim: '23:00' }], // Qui
    5: [{ ini: '12:00', fim: '23:59' }],                               // Sex
    6: [{ ini: '12:00', fim: '23:59' }],                               // Sáb
  };

  const LABELS = {
    0: 'Domingo: 12h às 17h',
    1: 'Segunda a Quinta: 12h–15h ou 19h–23h',
    2: 'Segunda a Quinta: 12h–15h ou 19h–23h',
    3: 'Segunda a Quinta: 12h–15h ou 19h–23h',
    4: 'Segunda a Quinta: 12h–15h ou 19h–23h',
    5: 'Sexta e Sábado: 12h às 00h',
    6: 'Sexta e Sábado: 12h às 00h',
  };

  function toMinutes(hhmm) {
    const [h, m] = hhmm.split(':').map(Number);
    return h * 60 + m;
  }

  function isHorarioValido(dia, hhmm) {
    const t = toMinutes(hhmm);
    return BLOCOS[dia].some(b => t >= toMinutes(b.ini) && t <= toMinutes(b.fim));
  }

  function primeiroHorario(dia) {
    return BLOCOS[dia][0].ini;
  }

  function atualizarCampoHora(inputData, inputHora, msgEl) {
    const val = inputData.value;
    if (!val) return;

    // date('w') em PHP = 0=Dom. JS: new Date().getDay() = 0=Dom também.
    // Mas new Date(val) interpreta como UTC — somar offset para evitar bug de dia.
    const [y, mo, d] = val.split('-').map(Number);
    const dia = new Date(y, mo - 1, d).getDay(); // local, sem UTC

    const blocos = BLOCOS[dia];

    // Define min/max pelo primeiro e último bloco
    const minTime = blocos[0].ini;
    const maxTime = blocos[blocos.length - 1].fim === '23:59' ? '23:59' : blocos[blocos.length - 1].fim;

    inputHora.min = minTime;
    inputHora.max = maxTime;

    // Mostra dica do horário
    if (msgEl) {
      msgEl.textContent = '⏰ ' + LABELS[dia];
      msgEl.style.display = 'block';
    }

    // Se o horário atual é inválido, reseta para o primeiro horário disponível
    if (inputHora.value && !isHorarioValido(dia, inputHora.value)) {
      inputHora.value = primeiroHorario(dia);
    }
  }

  function validarNoSubmit(inputData, inputHora, form) {
    form.addEventListener('submit', function (e) {
      const val = inputData.value;
      if (!val || !inputHora.value) return;

      const [y, mo, d] = val.split('-').map(Number);
      const dia = new Date(y, mo - 1, d).getDay();

      if (!isHorarioValido(dia, inputHora.value)) {
        e.preventDefault();
        alert('Horário inválido para este dia.\n' + LABELS[dia]);
        inputHora.focus();
      }
    });
  }

  // Inicializa todos os pares data+hora da página
  function init() {
    // Pares possíveis de campos
    const pares = [
      { data: 'data_reserva', hora: 'hora_reserva', msg: 'msg-horario' },
    ];

    pares.forEach(function (par) {
      const inputData = document.getElementById(par.data) || document.querySelector('[name="' + par.data + '"]');
      const inputHora = document.getElementById(par.hora) || document.querySelector('[name="' + par.hora + '"]');
      const msgEl     = document.getElementById(par.msg)  || null;

      if (!inputData || !inputHora) return;

      // Ao mudar a data
      inputData.addEventListener('change', function () {
        atualizarCampoHora(inputData, inputHora, msgEl);
      });

      // Ao mudar a hora (valida em tempo real)
      inputHora.addEventListener('change', function () {
        if (!inputData.value) return;
        const [y, mo, d] = inputData.value.split('-').map(Number);
        const dia = new Date(y, mo - 1, d).getDay();
        if (!isHorarioValido(dia, inputHora.value)) {
          inputHora.setCustomValidity('Horário fora do funcionamento. ' + LABELS[dia]);
          inputHora.reportValidity();
        } else {
          inputHora.setCustomValidity('');
        }
      });

      // Validação no submit
      const form = inputData.closest('form');
      if (form) validarNoSubmit(inputData, inputHora, form);

      // Roda uma vez se já tiver data preenchida
      if (inputData.value) atualizarCampoHora(inputData, inputHora, msgEl);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
