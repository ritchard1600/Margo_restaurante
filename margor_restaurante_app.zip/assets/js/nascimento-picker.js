/**
 * nascimento-picker.js
 * Calendário visual para data de nascimento
 * Permite navegar por ano e mês rapidamente (dropdown)
 */
(function () {
  'use strict';

  const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                 'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  const DIAS_CURTOS = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];

  const CSS = `
  .np-wrap { position: relative; }

  .np-display {
    width: 100%;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: var(--radius, 10px);
    padding: .7rem 1rem;
    color: var(--text);
    font-size: .9rem;
    font-family: var(--font-body, sans-serif);
    cursor: pointer;
    text-align: left;
    display: flex;
    align-items: center;
    justify-content: space-between;
    transition: border-color .2s;
    box-sizing: border-box;
  }
  .np-display:hover, .np-display.open { border-color: var(--gold, #C9A84C); }
  .np-display .np-placeholder { color: var(--muted, #7A7470); }
  .np-display .np-arrow { font-size: .7rem; color: var(--muted); transition: transform .2s; }
  .np-display.open .np-arrow { transform: rotate(180deg); }

  .np-cal {
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    z-index: 300;
    background: var(--surface, #1e1e1e);
    border: 1px solid var(--border-gold, rgba(201,168,76,.25));
    border-radius: 14px;
    padding: 1.2rem;
    width: 300px;
    box-shadow: 0 8px 32px rgba(0,0,0,.55);
    display: none;
  }
  .np-cal.open { display: block; }

  /* Header com dropdowns de mês e ano */
  .np-cal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: .4rem;
    margin-bottom: 1rem;
  }
  .np-cal-nav {
    background: none;
    border: 1px solid var(--border, #2e2e2e);
    border-radius: 6px;
    color: var(--text-2, #C8BFA8);
    width: 28px; height: 28px;
    cursor: pointer;
    font-size: .9rem;
    display: flex; align-items: center; justify-content: center;
    transition: border-color .2s, color .2s;
    flex-shrink: 0;
    font-family: inherit;
  }
  .np-cal-nav:hover { border-color: var(--gold, #C9A84C); color: var(--gold, #C9A84C); }

  .np-sel {
    background: var(--bg, #0f0f0f);
    border: 1px solid var(--border, #2e2e2e);
    border-radius: 6px;
    color: var(--text, #F5F0E8);
    font-size: .82rem;
    font-family: inherit;
    padding: .25rem .4rem;
    cursor: pointer;
    transition: border-color .2s;
    outline: none;
  }
  .np-sel:focus, .np-sel:hover { border-color: var(--gold, #C9A84C); }
  .np-sel option { background: var(--surface, #1e1e1e); }

  /* Grade de dias */
  .np-cal-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 2px;
  }
  .np-cal-dow {
    text-align: center;
    font-size: .65rem;
    color: var(--muted, #7A7470);
    text-transform: uppercase;
    letter-spacing: .06em;
    padding: .3rem 0 .5rem;
  }
  .np-day {
    text-align: center;
    padding: .42rem .2rem;
    border-radius: 8px;
    font-size: .83rem;
    cursor: pointer;
    color: var(--text-2, #C8BFA8);
    transition: background .15s, color .15s;
    border: 1px solid transparent;
    background: none;
    width: 100%;
    font-family: inherit;
  }
  .np-day:hover:not(:disabled) { background: var(--gold-dim, rgba(201,168,76,.12)); color: var(--gold, #C9A84C); }
  .np-day.selected { background: var(--gold, #C9A84C) !important; color: #0f0f0f !important; font-weight: 700; border-radius: 8px; }
  .np-day:disabled { opacity: .2; cursor: not-allowed; }
  .np-day.other-month { opacity: .25; }
  `;

  function injectCSS() {
    if (document.getElementById('np-css')) return;
    const s = document.createElement('style');
    s.id = 'np-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  function pad(n) { return String(n).padStart(2, '0'); }

  function formatValue(y, m, d) {
    return `${y}-${pad(m + 1)}-${pad(d)}`;
  }

  function formatDisplay(y, m, d) {
    return `${pad(d)}/${pad(m + 1)}/${y}`;
  }

  function NascimentoPicker(inputHidden, container) {
    this.input = inputHidden;

    const today = new Date();
    this.maxYear = today.getFullYear() - 1;  // mínimo 1 ano de idade
    this.minYear = today.getFullYear() - 120;

    // Estado
    this.selYear  = null;
    this.selMonth = null;
    this.selDay   = null;
    this.viewYear  = today.getFullYear() - 25; // começa em ~25 anos atrás
    this.viewMonth = today.getMonth();

    // Se já tem valor no input
    if (inputHidden.value) {
      const parts = inputHidden.value.split('-');
      if (parts.length === 3) {
        this.selYear  = parseInt(parts[0]);
        this.selMonth = parseInt(parts[1]) - 1;
        this.selDay   = parseInt(parts[2]);
        this.viewYear  = this.selYear;
        this.viewMonth = this.selMonth;
      }
    }

    this._build(container);
  }

  NascimentoPicker.prototype._build = function (container) {
    const self = this;

    // Botão display
    this.displayBtn = document.createElement('button');
    this.displayBtn.type = 'button';
    this.displayBtn.className = 'np-display';
    this._updateDisplay();

    // Calendário
    this.cal = document.createElement('div');
    this.cal.className = 'np-cal';

    const wrap = document.createElement('div');
    wrap.className = 'np-wrap';
    wrap.appendChild(this.displayBtn);
    wrap.appendChild(this.cal);
    container.appendChild(wrap);

    this._renderCal();

    this.displayBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (self.cal.classList.contains('open')) self._close();
      else self._open();
    });

    document.addEventListener('click', function (e) {
      if (!wrap.contains(e.target)) self._close();
    });
  };

  NascimentoPicker.prototype._open  = function () {
    this.cal.classList.add('open');
    this.displayBtn.classList.add('open');
  };
  NascimentoPicker.prototype._close = function () {
    this.cal.classList.remove('open');
    this.displayBtn.classList.remove('open');
  };

  NascimentoPicker.prototype._updateDisplay = function () {
    if (this.selYear !== null) {
      this.displayBtn.innerHTML =
        `<span>${formatDisplay(this.selYear, this.selMonth, this.selDay)}</span><span class="np-arrow">▼</span>`;
    } else {
      this.displayBtn.innerHTML =
        `<span class="np-placeholder">Selecione a data</span><span class="np-arrow">▼</span>`;
    }
  };

  NascimentoPicker.prototype._renderCal = function () {
    const self = this;
    const y = this.viewYear;
    const m = this.viewMonth;

    this.cal.innerHTML = '';

    // ── Header ──
    const header = document.createElement('div');
    header.className = 'np-cal-header';

    const btnPrev = document.createElement('button');
    btnPrev.type = 'button'; btnPrev.className = 'np-cal-nav'; btnPrev.textContent = '‹';
    btnPrev.addEventListener('click', function (e) { e.stopPropagation(); self._prevMonth(); });

    const btnNext = document.createElement('button');
    btnNext.type = 'button'; btnNext.className = 'np-cal-nav'; btnNext.textContent = '›';
    btnNext.addEventListener('click', function (e) { e.stopPropagation(); self._nextMonth(); });

    // Dropdown de mês
    const selMes = document.createElement('select');
    selMes.className = 'np-sel';
    MESES.forEach(function (nome, i) {
      const opt = document.createElement('option');
      opt.value = i; opt.textContent = nome;
      if (i === m) opt.selected = true;
      selMes.appendChild(opt);
    });
    selMes.addEventListener('change', function (e) {
      e.stopPropagation();
      self.viewMonth = parseInt(selMes.value);
      self._renderCal();
    });

    // Dropdown de ano
    const selAno = document.createElement('select');
    selAno.className = 'np-sel';
    for (let yr = self.maxYear; yr >= self.minYear; yr--) {
      const opt = document.createElement('option');
      opt.value = yr; opt.textContent = yr;
      if (yr === y) opt.selected = true;
      selAno.appendChild(opt);
    }
    selAno.addEventListener('change', function (e) {
      e.stopPropagation();
      self.viewYear = parseInt(selAno.value);
      self._renderCal();
    });

    header.appendChild(btnPrev);
    header.appendChild(selMes);
    header.appendChild(selAno);
    header.appendChild(btnNext);
    this.cal.appendChild(header);

    // ── Grid ──
    const grid = document.createElement('div');
    grid.className = 'np-cal-grid';

    DIAS_CURTOS.forEach(function (d) {
      const el = document.createElement('div');
      el.className = 'np-cal-dow';
      el.textContent = d;
      grid.appendChild(el);
    });

    const firstDay    = new Date(y, m, 1).getDay();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const daysInPrev  = new Date(y, m, 0).getDate();
    const today       = new Date(); today.setHours(0,0,0,0);
    const maxDate     = new Date(self.maxYear, today.getMonth(), today.getDate());

    // Dias do mês anterior
    for (let i = firstDay - 1; i >= 0; i--) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'np-day other-month';
      btn.textContent = daysInPrev - i;
      btn.disabled = true;
      grid.appendChild(btn);
    }

    // Dias do mês atual
    for (let d = 1; d <= daysInMonth; d++) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'np-day';
      btn.textContent = d;

      const dateObj = new Date(y, m, d);
      if (dateObj > maxDate) { btn.disabled = true; }

      if (self.selYear === y && self.selMonth === m && self.selDay === d) {
        btn.classList.add('selected');
      }

      btn.addEventListener('click', (function (dd) {
        return function (e) {
          e.stopPropagation();
          self.selYear  = y;
          self.selMonth = m;
          self.selDay   = dd;
          self.input.value = formatValue(y, m, dd);
          self._updateDisplay();
          self._renderCal();
          self._close();
        };
      })(d));

      grid.appendChild(btn);
    }

    this.cal.appendChild(grid);
  };

  NascimentoPicker.prototype._prevMonth = function () {
    if (this.viewMonth === 0) { this.viewYear--; this.viewMonth = 11; }
    else this.viewMonth--;
    this._renderCal();
  };
  NascimentoPicker.prototype._nextMonth = function () {
    if (this.viewMonth === 11) { this.viewYear++; this.viewMonth = 0; }
    else this.viewMonth++;
    this._renderCal();
  };

  // ── Máscara de telefone ──────────────────────────────────
  function aplicarMascaraTelefone(input) {
    input.addEventListener('input', function () {
      let v = input.value.replace(/\D/g, '').slice(0, 11);
      if (v.length === 0) { input.value = ''; return; }
      if (v.length <= 2)  { input.value = '(' + v; return; }
      if (v.length <= 6)  { input.value = '(' + v.slice(0,2) + ') ' + v.slice(2); return; }
      if (v.length <= 10) {
        input.value = '(' + v.slice(0,2) + ') ' + v.slice(2,6) + '-' + v.slice(6);
        return;
      }
      // 11 dígitos — celular: (XX) XXXXX-XXXX
      input.value = '(' + v.slice(0,2) + ') ' + v.slice(2,7) + '-' + v.slice(7);
    });

    // Ao colar
    input.addEventListener('paste', function () {
      setTimeout(function () { input.dispatchEvent(new Event('input')); }, 10);
    });

    // Não deixa digitar letra
    input.addEventListener('keypress', function (e) {
      if (!/[0-9]/.test(e.key) && !e.ctrlKey && !e.metaKey) e.preventDefault();
    });
  }

  // ── Init ────────────────────────────────────────────────
  function init() {
    injectCSS();

    // Pickers de nascimento
    document.querySelectorAll('[data-nasc-picker]').forEach(function (container) {
      const inputHidden = container.querySelector('[data-nasc-input]');
      if (!inputHidden) return;
      inputHidden.style.display = 'none';
      new NascimentoPicker(inputHidden, container);
    });

    // Máscaras de telefone
    document.querySelectorAll('[data-tel-mask]').forEach(function (input) {
      aplicarMascaraTelefone(input);
      // Aplica máscara no valor já existente
      if (input.value) input.dispatchEvent(new Event('input'));
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
