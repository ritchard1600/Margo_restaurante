-- =============================================================
--  SISTEMA DE CADASTRO DE RESTAURANTE
--  Execute este arquivo no phpMyAdmin ou no MySQL
-- =============================================================

CREATE DATABASE IF NOT EXISTS margor_db1
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE margor_db1;

-- -------------------------------------------------------------
-- TABELA: usuarios (funcionários internos)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(100)  NOT NULL,
  email         VARCHAR(150)  NOT NULL UNIQUE,
  senha         VARCHAR(255)  NOT NULL COMMENT 'MD5 para fins didáticos',
  perfil        ENUM('Administrador','Gerente','Garçom','Cozinheiro','Caixa') NOT NULL DEFAULT 'Garçom',
  status        ENUM('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
  criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- -------------------------------------------------------------
-- TABELA: categorias_prato
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categorias_prato (
  id   INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- -------------------------------------------------------------
-- TABELA: pratos
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pratos (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(150)  NOT NULL UNIQUE,
  descricao     TEXT,
  preco         DECIMAL(10,2) NOT NULL,
  tempo_minutos SMALLINT UNSIGNED DEFAULT 0,
  categoria_id  INT NOT NULL,
  status        ENUM('Disponível','Indisponível') NOT NULL DEFAULT 'Disponível',
  criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_prato_categoria FOREIGN KEY (categoria_id)
    REFERENCES categorias_prato(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- -------------------------------------------------------------
-- TABELA: clientes (com suporte a login)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clientes (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  nome            VARCHAR(120) NOT NULL,
  email           VARCHAR(150) UNIQUE,
  senha           VARCHAR(255) DEFAULT NULL COMMENT 'NULL = cadastro via reserva sem conta',
  telefone        VARCHAR(20),
  cpf             VARCHAR(14) UNIQUE,
  data_nascimento DATE,
  endereco        VARCHAR(200),
  cidade          VARCHAR(80),
  estado          CHAR(2),
  criado_em       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- -------------------------------------------------------------
-- TABELA: reservas
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reservas (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(120)  NOT NULL,
  data_reserva  DATE          NOT NULL,
  hora_reserva  TIME          NOT NULL,
  pessoas       TINYINT UNSIGNED NOT NULL DEFAULT 1,
  status        ENUM('Pendente','Confirmada','Cancelada','Concluída') NOT NULL DEFAULT 'Pendente',
  origem        ENUM('online','interno') NOT NULL DEFAULT 'online',
  cliente_id    INT DEFAULT NULL,
  usuario_id    INT DEFAULT NULL,
  criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reserva_cliente FOREIGN KEY (cliente_id)  REFERENCES clientes(id) ON DELETE SET NULL,
  CONSTRAINT fk_reserva_usuario FOREIGN KEY (usuario_id)  REFERENCES usuarios(id) ON DELETE SET NULL,
  INDEX idx_data (data_reserva),
  INDEX idx_status (status)
) ENGINE=InnoDB;

-- -------------------------------------------------------------
-- TABELA: pedidos
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pedidos (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id  INT NOT NULL,
  usuario_id  INT NOT NULL,
  status      ENUM('Aguardando','Em preparo','Pronto','Entregue','Cancelado') NOT NULL DEFAULT 'Aguardando',
  observacao  TEXT,
  total       DECIMAL(10,2) NOT NULL DEFAULT 0,
  criado_em   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pedido_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE RESTRICT,
  CONSTRAINT fk_pedido_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- -------------------------------------------------------------
-- TABELA: itens_pedido
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS itens_pedido (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id   INT NOT NULL,
  prato_id    INT NOT NULL,
  quantidade  SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  preco_unit  DECIMAL(10,2) NOT NULL,
  subtotal    DECIMAL(10,2) GENERATED ALWAYS AS (quantidade * preco_unit) STORED,
  CONSTRAINT fk_item_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id)  ON DELETE CASCADE,
  CONSTRAINT fk_item_prato  FOREIGN KEY (prato_id)  REFERENCES pratos(id)   ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =============================================================
-- MIGRAÇÃO SEGURA: adiciona coluna senha em clientes (se não existir)
-- Usa PROCEDURE para evitar erro de coluna duplicada no Workbench
-- =============================================================

DROP PROCEDURE IF EXISTS sp_add_senha_clientes;

DELIMITER $$
CREATE PROCEDURE sp_add_senha_clientes()
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME   = 'clientes'
      AND COLUMN_NAME  = 'senha'
  ) THEN
    ALTER TABLE clientes
      ADD COLUMN senha VARCHAR(255) DEFAULT NULL
      COMMENT 'NULL = cliente sem conta (reserva anônima)'
      AFTER email;
  END IF;
END$$
DELIMITER ;

CALL sp_add_senha_clientes();
DROP PROCEDURE IF EXISTS sp_add_senha_clientes;

-- =============================================================
-- DADOS INICIAIS
-- =============================================================

-- Limpeza segura de duplicatas (mantém o registro mais antigo de cada prato)
DROP PROCEDURE IF EXISTS sp_remove_pratos_duplicados;
DELIMITER $$
CREATE PROCEDURE sp_remove_pratos_duplicados()
BEGIN
  DELETE p1 FROM pratos p1
  INNER JOIN pratos p2
  WHERE p1.id > p2.id AND p1.nome = p2.nome;
END$$
DELIMITER ;
CALL sp_remove_pratos_duplicados();
DROP PROCEDURE IF EXISTS sp_remove_pratos_duplicados;

INSERT IGNORE INTO categorias_prato (nome) VALUES
  ('Entradas'), ('Pratos principais'), ('Sobremesas'), ('Bebidas'), ('Lanches');

-- Usuário admin — senha: 123456 (MD5 para fins didáticos)
INSERT IGNORE INTO usuarios (nome, email, senha, perfil, status) VALUES
  ('Administrador', 'admin@restaurante.com', MD5('123456'), 'Administrador', 'Ativo');

INSERT IGNORE INTO pratos (nome, descricao, preco, tempo_minutos, categoria_id, status) VALUES
  ('Frango grelhado',  'Frango temperado na brasa com ervas finas e alho', 32.90, 25, 2, 'Disponível'),
  ('Suco de laranja',  'Natural espremido na hora, 300 ml',                  8.00,  5, 4, 'Disponível'),
  ('Pudim de leite',   'Receita tradicional da casa com calda de caramelo', 12.50, 10, 3, 'Disponível'),
  ('Bruschetta',       'Pão italiano com tomate, manjericão e azeite',       14.90, 10, 1, 'Disponível'),
  ('Água mineral',     'Garrafa 500 ml',                                      4.50,  1, 4, 'Disponível'),
  ('X-Burguer Artesanal', 'Pão brioche, blend 180g, queijo e molho da casa', 38.90, 20, 5, 'Disponível');

-- =============================================================
-- ATUALIZAÇÃO: coluna reserva_id em pedidos (pré-pedido vinculado)
-- =============================================================
DROP PROCEDURE IF EXISTS sp_add_reserva_id_pedidos;

DELIMITER $$
CREATE PROCEDURE sp_add_reserva_id_pedidos()
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME   = 'pedidos'
      AND COLUMN_NAME  = 'reserva_id'
  ) THEN
    ALTER TABLE pedidos
      ADD COLUMN reserva_id INT NULL AFTER usuario_id,
      ADD CONSTRAINT fk_pedido_reserva
        FOREIGN KEY (reserva_id) REFERENCES reservas(id) ON DELETE SET NULL;
  END IF;
END$$
DELIMITER ;

CALL sp_add_reserva_id_pedidos();
DROP PROCEDURE IF EXISTS sp_add_reserva_id_pedidos;

-- =============================================================
-- ATUALIZAÇÃO: adicionar perfil Gerente ao ENUM de usuarios
-- =============================================================
DROP PROCEDURE IF EXISTS sp_add_gerente;
DELIMITER $$
CREATE PROCEDURE sp_add_gerente()
BEGIN
  ALTER TABLE usuarios
    MODIFY COLUMN perfil ENUM('Administrador','Gerente','Garçom','Cozinheiro','Caixa') NOT NULL DEFAULT 'Garçom';
END$$
DELIMITER ;
CALL sp_add_gerente();
DROP PROCEDURE IF EXISTS sp_add_gerente;
