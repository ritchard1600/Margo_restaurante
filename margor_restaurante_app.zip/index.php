<?php
require_once 'includes/auth.php';

// Já logado? Redireciona
if (usuarioLogado()) {
    header('Location: pages/painel.php');
    exit;
}
if (clienteLogado()) {
    header('Location: pages/cliente/painel.php');
    exit;
}

// Busca destaques do cardápio
$pratos = [];
try {
    $db = getDB();
    $stmt = $db->query(
        "SELECT p.nome, p.descricao, p.preco, p.tempo_minutos, c.nome AS categoria
         FROM pratos p JOIN categorias_prato c ON c.id = p.categoria_id
         WHERE p.status = 'Disponível'
         ORDER BY RAND() LIMIT 4"
    );
    $pratos = $stmt->fetchAll();
} catch (Exception $e) { /* banco ainda não conectado */ }

// Reserva rápida
$reservaOk   = false;
$reservaErro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reserva_rapida'])) {
    $nome    = trim($_POST['nome']         ?? '');
    $data    = trim($_POST['data_reserva'] ?? '');
    $hora    = trim($_POST['hora_reserva'] ?? '');
    $pessoas = (int)($_POST['pessoas']     ?? 2);
    if (!$nome || !$data || !$hora) {
        $reservaErro = 'Preencha todos os campos para reservar.';
    } elseif ($data < date('Y-m-d')) {
        $reservaErro = 'A data não pode ser no passado.';
    } else {
        // Validar horário conforme dia da semana
        $validacao = validarHorarioReserva($data, $hora);
        if ($validacao !== true) {
            $reservaErro = $validacao;
        } else {
            try {
                $db = getDB();
                $db->prepare(
                    "INSERT INTO reservas (nome, data_reserva, hora_reserva, pessoas, status, origem)
                     VALUES (?, ?, ?, ?, 'Pendente', 'online')"
                )->execute([$nome, $data, $hora, $pessoas]);
                $reservaOk = true;
            } catch (Exception $e) {
                $reservaErro = 'Erro ao salvar reserva. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RestauranteApp — Experiência Gastronômica</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    /* Ornamentos do hero */
    .hero-divider {
      width: 60px; height: 1px;
      background: linear-gradient(90deg, transparent, var(--gold), transparent);
      margin: 1.5rem auto;
    }
    .hero-diamond {
      display: inline-block;
      width: 6px; height: 6px;
      background: var(--gold);
      transform: rotate(45deg);
      margin: 0 .5rem;
    }

    /* Seção sobre */
    .sobre-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 5rem;
      align-items: center;
    }
    .sobre-numero {
      font-family: var(--font-display);
      font-size: 5rem;
      color: var(--gold);
      opacity: .15;
      line-height: 1;
      margin-bottom: -1rem;
    }
    .sobre-texto h2 { font-size: 2.2rem; margin-bottom: 1rem; }
    .sobre-texto p { color: var(--text-2); line-height: 1.8; margin-bottom: 1rem; }
    .sobre-stat { display: flex; gap: 2.5rem; margin-top: 1.5rem; }
    .sobre-stat-item .num {
      font-family: var(--font-display);
      font-size: 2rem;
      color: var(--gold);
      font-weight: 700;
    }
    .sobre-stat-item .lbl { font-size: .78rem; color: var(--muted); text-transform: uppercase; letter-spacing: .1em; }

    /* Seção horários */
    .horarios-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1.5rem;
      text-align: center;
    }
    .horario-item {
      padding: 2rem 1.5rem;
      border: 1px solid var(--border-gold);
      border-radius: var(--radius-lg);
    }
    .horario-dia {
      font-size: .75rem;
      letter-spacing: .15em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: .4rem;
    }
    .horario-hora {
      font-family: var(--font-display);
      font-size: 1.2rem;
      color: var(--text);
    }
    .horario-obs { font-size: .78rem; color: var(--muted); margin-top: .3rem; }

    /* Scroll reveal simples */
    .reveal { opacity: 0; transform: translateY(24px); transition: opacity .7s, transform .7s; }
    .reveal.visible { opacity: 1; transform: none; }

    @media (max-width: 768px) {
      .sobre-grid { grid-template-columns: 1fr; gap: 2rem; }
      .horarios-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body class="landing-body">

<!-- ── NAVEGAÇÃO ── -->
<nav class="landing-nav" id="nav">
  <div class="nav-logo">Margôr</div>
  <ul class="nav-links">
    <li><a href="#cardapio">Cardápio</a></li>
    <li><a href="#reserva">Reservas</a></li>
    <li><a href="#sobre">Sobre</a></li>
    <li><a href="#horarios">Horários</a></li>
  </ul>
  <div style="display:flex;gap:.8rem;align-items:center">
    <a href="pages/login-cliente.php" class="btn btn-outline btn-sm">Entrar</a>
    <a href="pages/cadastro.php"      class="btn btn-primary btn-sm">Criar conta</a>
  </div>
</nav>

<!-- ── HERO ── -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-ornament"></div>
  <div class="hero-content">
    <p class="hero-eyebrow">
      <span class="hero-diamond"></span>
      Bem-vindo à experiência
      <span class="hero-diamond"></span>
    </p>
    <h1 class="hero-title">
      Uma mesa<br>para <em>momentos</em><br>que ficam
    </h1>
    <div class="hero-divider"></div>
    <p class="hero-subtitle">
      Cozinha autoral, ingredientes de origem e um ambiente que convida a ficar
    </p>
    <div class="hero-ctas">
      <a href="#reserva" class="btn btn-primary btn-lg">Reservar uma mesa</a>
      <a href="#cardapio" class="btn btn-accent btn-lg">Explorar o cardápio</a>
    </div>
  </div>
</section>

<!-- ── CARDÁPIO DESTAQUES ── -->
<section class="section" id="cardapio" style="background:var(--bg-2)">
  <div class="section-inner">
    <div class="section-header reveal">
      <p class="section-eyebrow">Da nossa cozinha</p>
      <h2 class="section-title">Destaques do cardápio</h2>
      <p class="section-sub">Pratos elaborados com técnica e cuidado, do primeiro ao último detalhe</p>
    </div>

    <?php if (!empty($pratos)): ?>
    <div class="pratos-grid">
      <?php foreach ($pratos as $p): ?>
      <div class="prato-card reveal">
        <div class="prato-card-cat"><?= htmlspecialchars($p['categoria']) ?></div>
        <h3 class="prato-card-nome"><?= htmlspecialchars($p['nome']) ?></h3>
        <p class="prato-card-desc"><?= htmlspecialchars($p['descricao'] ?? '') ?></p>
        <div class="prato-card-footer">
          <span class="prato-card-preco">R$ <?= number_format((float)$p['preco'], 2, ',', '.') ?></span>
          <span class="prato-card-tempo">⏱ <?= $p['tempo_minutos'] ?>min</span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:2.5rem">
      <a href="pages/cardapio-publico.php" class="btn btn-accent">Ver cardápio completo →</a>
    </div>
    <?php else: ?>
    <div class="empty-state">
      <div class="empty-icon">🍽️</div>
      <p>Cardápio em atualização. Volte em breve!</p>
    </div>
    <?php endif; ?>
  </div>
</section>

<!-- ── RESERVA RÁPIDA ── -->
<section class="section" id="reserva">
  <div class="section-inner">
    <div class="section-header reveal">
      <p class="section-eyebrow">Garanta sua mesa</p>
      <h2 class="section-title">Fazer uma reserva</h2>
      <p class="section-sub">Rápido e sem necessidade de cadastro. Nossa equipe confirmará em breve</p>
    </div>

    <div class="reserva-rapida reveal">
      <?php if ($reservaOk): ?>
        <div class="alert alert-success" style="text-align:center;font-size:1rem;padding:1.5rem">
          ✅ <strong>Reserva solicitada!</strong> Nossa equipe entrará em contato para confirmar.
        </div>
        <div style="text-align:center;margin-top:1rem">
          <a href="#reserva" onclick="location.reload()" class="btn btn-outline">Fazer outra reserva</a>
          <a href="pages/cadastro.php" class="btn btn-primary" style="margin-left:.8rem">Criar conta para acompanhar</a>
        </div>
      <?php else: ?>
        <?php if ($reservaErro): ?>
          <div class="alert alert-err"><?= htmlspecialchars($reservaErro) ?></div>
        <?php endif; ?>
        <form method="POST">
          <input type="hidden" name="reserva_rapida" value="1">
          <div class="reserva-rapida-grid">
            <div class="form-group" style="margin:0">
              <label>Seu nome</label>
              <input type="text" name="nome" placeholder="Nome para a reserva"
                     value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
            </div>
            <div class="form-group" style="margin:0" data-reserva-picker>
              <label>Data</label>
              <input type="date" name="data_reserva" data-rp-date
                     value="<?= htmlspecialchars($_POST['data_reserva'] ?? '') ?>">
              <div style="margin-top:.5rem">
                <label style="font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;color:var(--text-2);font-weight:500">Horário</label>
                <input type="hidden" name="hora_reserva" data-rp-hora
                       value="<?= htmlspecialchars($_POST['hora_reserva'] ?? '') ?>">
              </div>
            </div>
            <div class="form-group" style="margin:0">
              <label>Pessoas</label>
              <select name="pessoas">
                <?php for ($i = 1; $i <= 20; $i++): ?>
                  <option value="<?= $i ?>" <?= (int)($_POST['pessoas'] ?? 2) === $i ? 'selected' : '' ?>>
                    <?= $i ?> <?= $i > 1 ? 'pessoas' : 'pessoa' ?>
                  </option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
          <div style="text-align:center;margin-top:1.5rem">
            <button type="submit" class="btn btn-primary btn-lg">📅 Confirmar reserva</button>
          </div>
        </form>
        <p style="text-align:center;font-size:.8rem;color:var(--muted);margin-top:1rem">
          Tem uma conta?
          <a href="pages/login-cliente.php">Entre aqui</a> para vincular a reserva ao seu perfil.
        </p>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- ── SOBRE ── -->
<section class="section" id="sobre" style="background:var(--bg-2)">
  <div class="section-inner">
    <div class="sobre-grid">
      <div class="reveal">
        <div class="sobre-numero">01</div>
        <p class="section-eyebrow" style="margin-bottom:.6rem">Nossa história</p>
        <h2 style="font-size:2.2rem;margin-bottom:1rem">Cozinha com alma,<br>serviço com elegância</h2>
        <p style="color:var(--text-2);line-height:1.8;margin-bottom:1rem">
          Nascemos da paixão por reunir pessoas à mesa. Cada prato que sai da nossa cozinha carrega
          técnica, memória afetiva e ingredientes selecionados de produtores locais.
        </p>
        <p style="color:var(--text-2);line-height:1.8">
          Do ambiente ao serviço, cada detalhe é pensado para que você esqueça o relógio
          e simplesmente desfrute do momento.
        </p>
        <div class="sobre-stat">
          <div class="sobre-stat-item"><div class="num">8+</div><div class="lbl">Anos de história</div></div>
          <div class="sobre-stat-item"><div class="num">40+</div><div class="lbl">Pratos no cardápio</div></div>
          <div class="sobre-stat-item"><div class="num">⭐ 4.9</div><div class="lbl">Avaliação média</div></div>
        </div>
      </div>
      <div class="reveal" style="display:flex;flex-direction:column;gap:1rem">
        <div class="prato-card" style="border-color:var(--border-gold)">
          <div class="prato-card-cat">Nosso compromisso</div>
          <h3 class="prato-card-nome">Ingredientes de origem</h3>
          <p class="prato-card-desc">Trabalhamos com produtores locais para garantir frescor e apoiar a agricultura regional.</p>
        </div>
        <div class="prato-card">
          <div class="prato-card-cat">Ambiente</div>
          <h3 class="prato-card-nome">Espaço para todos os momentos</h3>
          <p class="prato-card-desc">Do jantar a dois à comemoração em família — temos mesas e menus para cada ocasião.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── HORÁRIOS ── -->
<section class="section" id="horarios">
  <div class="section-inner">
    <div class="section-header reveal">
      <p class="section-eyebrow">Quando nos encontrar</p>
      <h2 class="section-title">Horários de funcionamento</h2>
    </div>
    <div class="horarios-grid reveal">
      <div class="horario-item">
        <div class="horario-dia">Segunda — Quinta</div>
        <div class="horario-hora">12h às 15h • 19h às 23h</div>
        <div class="horario-obs">Almoço e jantar</div>
      </div>
      <div class="horario-item" style="border-color:var(--gold)">
        <div class="horario-dia">Sexta — Sábado</div>
        <div class="horario-hora">12h às 00h</div>
        <div class="horario-obs">Funcionamento contínuo</div>
      </div>
      <div class="horario-item">
        <div class="horario-dia">Domingo</div>
        <div class="horario-hora">12h às 17h</div>
        <div class="horario-obs">Brunch & almoço</div>
      </div>
    </div>
  </div>
</section>

<!-- ── FOOTER ── -->
<footer class="landing-footer">
  <div class="footer-logo">Margôr</div>
  <p class="footer-info">Rua das Flores, 247 — Centro — Teresina, PI</p>
  <p class="footer-info">📞 (86) 99999-0000 &nbsp;|&nbsp; ✉️ contato@margor.com.br</p>
  <div class="footer-links">
    <a href="pages/cardapio-publico.php">Cardápio</a>
    <a href="#reserva">Reservas</a>
    <a href="pages/login-cliente.php">Área do cliente</a>
    <a href="pages/login-admin.php" style="opacity:.4">Equipe interna</a>
  </div>
  <p style="font-size:.72rem;color:var(--muted);margin-top:1.5rem;opacity:.5">
    © <?= date('Y') ?> Margôr Restaurante. Todos os direitos reservados.
  </p>
</footer>

<script>
// Nav scroll
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 60);
});

// Scroll reveal
const reveals = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } });
}, { threshold: 0.12 });
reveals.forEach(el => io.observe(el));
</script>
<script src="assets/js/reserva-picker.js"></script>
</body>
</html>
