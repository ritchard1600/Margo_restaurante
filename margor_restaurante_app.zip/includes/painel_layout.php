<?php
// =============================================================
//  PAINEL_LAYOUT.PHP — Layout base para área administrativa
//  Variáveis esperadas: $tituloPagina, $paginaAtiva, $cssPath
// =============================================================

$usuario  = usuarioAtual();
$perfil   = $usuario['perfil'] ?? '';
$cssPath  = $cssPath ?? '../../assets/css/style.css';
$primeiraLetra = mb_strtoupper(mb_substr($usuario['nome'] ?? 'A', 0, 1));

// Monta os links do menu conforme perfil
$menuAdmin = [
    ['href' => 'painel.php',    'icon' => '📊', 'label' => 'Visão geral',  'key' => 'painel'],
    ['href' => 'pedidos.php',   'icon' => '🧾', 'label' => 'Pedidos',      'key' => 'pedidos'],
    ['href' => 'reservas.php',  'icon' => '📅', 'label' => 'Reservas',     'key' => 'reservas'],
    ['href' => 'cardapio.php',  'icon' => '🍴', 'label' => 'Cardápio',     'key' => 'cardapio'],
    ['href' => 'clientes.php',  'icon' => '👥', 'label' => 'Clientes',     'key' => 'clientes'],
    ['href' => 'usuarios.php',  'icon' => '🔑', 'label' => 'Usuários',     'key' => 'usuarios'],
    ['href' => 'relatorios.php','icon' => '📈', 'label' => 'Relatórios',   'key' => 'relatorios'],
    ['href' => 'cozinha.php',   'icon' => '👨‍🍳', 'label' => 'Cozinha',     'key' => 'cozinha'],
    ['href' => 'caixa.php',     'icon' => '💰', 'label' => 'Caixa',        'key' => 'caixa'],
];
$menuGarcom = [
    ['href' => 'painel.php',          'icon' => '📊', 'label' => 'Início',   'key' => 'painel'],
    ['href' => '../admin/pedidos.php', 'icon' => '🧾', 'label' => 'Pedidos',  'key' => 'pedidos'],
    ['href' => '../admin/reservas.php','icon' => '📅', 'label' => 'Reservas', 'key' => 'reservas'],
];
$menuCozinheiro = [
    ['href' => 'painel.php',          'icon' => '👨‍🍳', 'label' => 'Fila da cozinha', 'key' => 'cozinha'],
    ['href' => '../admin/pedidos.php', 'icon' => '🧾',  'label' => 'Ver pedidos',    'key' => 'pedidos'],
];
$menuCaixa = [
    ['href' => 'painel.php', 'icon' => '💰', 'label' => 'Fechamento', 'key' => 'caixa'],
];
$menuGerente = [
    ['href' => 'painel.php',    'icon' => '📊', 'label' => 'Visão geral', 'key' => 'painel'],
    ['href' => 'relatorios.php','icon' => '📈', 'label' => 'Relatórios',  'key' => 'relatorios'],
    ['href' => 'pedidos.php',   'icon' => '🧾', 'label' => 'Pedidos',     'key' => 'pedidos'],
    ['href' => 'reservas.php',  'icon' => '📅', 'label' => 'Reservas',    'key' => 'reservas'],
    ['href' => 'clientes.php',  'icon' => '👥', 'label' => 'Clientes',    'key' => 'clientes'],
];

$menu = match($perfil) {
    'Administrador' => $menuAdmin,
    'Gerente'       => $menuGerente,
    'Garçom'        => $menuGarcom,
    'Cozinheiro'    => $menuCozinheiro,
    'Caixa'         => $menuCaixa,
    default         => [],
};

// Caminho do logout relativo à localização atual
$logoutPath = 'logout.php'; // cada perfil tem seu próprio logout.php na pasta
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($tituloPagina ?? 'Painel') ?> — RestauranteApp</title>
  <link rel="stylesheet" href="<?= $cssPath ?>">
</head>
<body>
<div class="painel-wrap">

  <!-- ── SIDEBAR ── -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
      <div class="sidebar-logo-name">Margôr</div>
      <div class="sidebar-logo-role"><?= htmlspecialchars($perfil) ?></div>
    </div>

    <nav class="sidebar-nav">
      <div class="sidebar-section">Menu</div>
      <?php foreach ($menu as $item): ?>
        <a href="<?= $item['href'] ?>"
           class="sidebar-link <?= ($paginaAtiva ?? '') === $item['key'] ? 'active' : '' ?>">
          <span class="icon"><?= $item['icon'] ?></span>
          <?= htmlspecialchars($item['label']) ?>
        </a>
      <?php endforeach; ?>
    </nav>

    <div class="sidebar-footer">
      <div class="sidebar-user">
        <div class="sidebar-avatar"><?= $primeiraLetra ?></div>
        <div>
          <div class="sidebar-user-name"><?= htmlspecialchars($usuario['nome'] ?? '') ?></div>
          <div class="sidebar-user-email"><?= htmlspecialchars($usuario['email'] ?? '') ?></div>
        </div>
      </div>
      <a href="<?= $logoutPath ?>" class="btn btn-ghost btn-sm btn-full" style="justify-content:flex-start;gap:.5rem">
        🚪 Sair
      </a>
    </div>
  </aside>

  <!-- ── CONTEÚDO PRINCIPAL ── -->
  <div class="main-content">
    <header class="main-header">
      <button onclick="document.getElementById('sidebar').classList.toggle('open')"
              style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.2rem;display:none"
              id="btn-menu">☰</button>
      <span class="main-header-title">
        <?= htmlspecialchars($tituloPagina ?? 'Painel') ?>
      </span>
      <div style="display:flex;align-items:center;gap:.8rem">
        <span style="font-size:.8rem;color:var(--muted)"><?= date('d/m/Y') ?></span>
        <a href="<?= $logoutPath ?>" class="btn btn-ghost btn-sm">Sair</a>
      </div>
    </header>
    <main class="main-body">
