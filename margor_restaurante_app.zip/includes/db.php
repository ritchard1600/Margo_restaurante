<?php
// =============================================================
//  CONEXÃO COM O BANCO DE DADOS
//  Ajuste host, dbname, user e pass conforme seu ambiente
// =============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'margor_db1');
define('DB_USER', 'root');
define('DB_PASS', '');          // XAMPP: sem senha | Laragon: sem senha
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            // Em produção, nunca exiba detalhes do erro
            die('<div style="font-family:sans-serif;padding:2rem;color:#c0392b">
                    <h2>Erro de conexão com o banco</h2>
                    <p>' . htmlspecialchars($e->getMessage()) . '</p>
                    <p style="font-size:.85rem;color:#888">Verifique as configurações em <code>includes/db.php</code></p>
                 </div>');
        }
    }
    return $pdo;
}
