<?php
// =============================================================
//  CLIENTE_LAYOUT.PHP — Layout base para área do cliente
//  Variável esperada: $paginaAtiva
// =============================================================

$cliente = clienteAtual();
$primeiraLetra = mb_strtoupper(mb_substr($cliente['nome'] ?? 'C', 0, 1));

$menu = [
    ['href' => 'painel.php',   'icon' => '🏠', 'label' => 'Início',          'key' => 'painel'],
    ['href' => 'cardapio.php', 'icon' => '🍴', 'label' => 'Cardápio & Pedido','key' => 'cardapio'],
    ['href' => 'reservas.php', 'icon' => '📅', 'label' => 'Minhas Reservas', 'key' => 'reservas'],
    ['href' => 'pedidos.php',  'icon' => '🧾', 'label' => 'Meus Pedidos',    'key' => 'pedidos'],
    ['href' => 'perfil.php',   'icon' => '👤', 'label' => 'Meu Perfil',      'key' => 'perfil'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Área do Cliente — RestauranteApp</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
  <style>
    /* Sidebar do cliente — versão mais compacta */
    .cliente-wrap { display: flex; min-height: 100vh; }

    .cliente-sidebar {
      width: 220px;
      flex-shrink: 0;
      background: var(--bg-2);
      border-right: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 0; bottom: 0; left: 0;
      z-index: 50;
    }
    .cliente-sidebar-logo {
      padding: 1.5rem 1.2rem 1.2rem;
      border-bottom: 1px solid var(--border);
    }
    .cliente-sidebar-logo a {
      font-family: var(--font-display);
      font-size: 1.1rem;
      color: var(--gold);
      display: block;
      margin-bottom: .15rem;
    }
    .cliente-sidebar-logo span {
      font-size: .7rem;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: .08em;
    }
    .cliente-sidebar-nav { padding: .8rem 0; flex: 1; }
    .cliente-sidebar-footer {
      padding: 1rem 1.2rem;
      border-top: 1px solid var(--border);
    }
    .cliente-avatar-bar {
      display: flex;
      align-items: center;
      gap: .6rem;
      margin-bottom: .8rem;
    }
    .cliente-avatar {
      width: 30px; height: 30px;
      border-radius: 50%;
      background: var(--gold-dim);
      border: 1px solid var(--border-gold);
      display: flex; align-items: center; justify-content: center;
      font-family: var(--font-display);
      font-size: .8rem;
      color: var(--gold);
      font-weight: 700;
      flex-shrink: 0;
    }
    .cliente-nome { font-size: .82rem; font-weight: 500; }
    .cliente-email { font-size: .7rem; color: var(--muted); }

    .cliente-main {
      margin-left: 220px;
      flex: 1;
      min-width: 0;
    }
    .cliente-topbar {
      background: var(--bg-2);
      border-bottom: 1px solid var(--border);
      padding: .9rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 40;
    }
    .cliente-body { padding: 2rem; max-width: 1000px; }

    @media (max-width: 768px) {
      .cliente-sidebar { transform: translateX(-100%); transition: transform .3s; }
      .cliente-sidebar.open { transform: translateX(0); }
      .cliente-main { margin-left: 0; }
      .cliente-body { padding: 1.2rem; }
    }
  </style>
</head>
<body>
<div class="cliente-wrap">

  <!-- Sidebar -->
  <aside class="cliente-sidebar" id="clienteSidebar">
    <div class="cliente-sidebar-logo">
      <a href="../../index.php">Margôr</a>
      <span>Área do cliente</span>
    </div>
    <nav class="cliente-sidebar-nav">
      <?php foreach ($menu as $item): ?>
        <a href="<?= $item['href'] ?>"
           class="sidebar-link <?= ($paginaAtiva ?? '') === $item['key'] ? 'active' : '' ?>">
          <span class="icon"><?= $item['icon'] ?></span>
          <?= htmlspecialchars($item['label']) ?>
        </a>
      <?php endforeach; ?>
      <div style="margin-top:.5rem;padding:.4rem 1.4rem">
        <div style="height:1px;background:var(--border);margin-bottom:.5rem"></div>
        <a href="../reserva.php" class="sidebar-link" style="color:var(--gold)">
          <span class="icon">📅</span> Nova reserva
        </a>
        <a href="../cardapio-publico.php" class="sidebar-link">
          <span class="icon">🌐</span> Ver cardápio público
        </a>
      </div>
    </nav>
    <div class="cliente-sidebar-footer">
      <div class="cliente-avatar-bar">
        <div class="cliente-avatar"><?= $primeiraLetra ?></div>
        <div>
          <div class="cliente-nome"><?= htmlspecialchars(explode(' ', $cliente['nome'] ?? '')[0]) ?></div>
          <div class="cliente-email"><?= htmlspecialchars($cliente['email'] ?? '') ?></div>
        </div>
      </div>
      <a href="logout.php" class="btn btn-ghost btn-sm btn-full" style="justify-content:flex-start;gap:.5rem">
        🚪 Sair
      </a>
    </div>
  </aside>

  <!-- Conteúdo -->
  <div class="cliente-main">
    <div class="cliente-topbar">
      <button onclick="document.getElementById('clienteSidebar').classList.toggle('open')"
              style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.2rem">
        ☰
      </button>
      <div style="display:flex;align-items:center;gap:.8rem">
        <a href="../reserva.php" class="btn btn-primary btn-sm">📅 Reservar mesa</a>
      </div>
    </div>
    <main class="cliente-body">
