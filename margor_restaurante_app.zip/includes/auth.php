<?php
// =============================================================
//  AUTH.PHP — Autenticação de usuários (equipe) e clientes
// =============================================================

require_once __DIR__ . '/db.php';

// Inicia sessão se ainda não iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── FUNÇÕES DE USUÁRIO (equipe interna) ──────────────────────

/**
 * Tenta logar um funcionário (usuarios).
 * Retorna true em sucesso, false em falha.
 */
function login(string $email, string $senha): bool {
    $db   = getDB();
    $stmt = $db->prepare(
        "SELECT * FROM usuarios WHERE email = ? AND senha = MD5(?) AND status = 'Ativo' LIMIT 1"
    );
    $stmt->execute([$email, $senha]);
    $usuario = $stmt->fetch();

    if ($usuario) {
        $_SESSION['usuario'] = [
            'id'     => $usuario['id'],
            'nome'   => $usuario['nome'],
            'email'  => $usuario['email'],
            'perfil' => $usuario['perfil'],
        ];
        return true;
    }
    return false;
}

/** Retorna se há um funcionário logado. */
function usuarioLogado(): bool {
    return !empty($_SESSION['usuario']);
}

/** Retorna os dados do funcionário logado ou null. */
function usuarioAtual(): ?array {
    return $_SESSION['usuario'] ?? null;
}

/** Exige login de funcionário, redireciona para login-admin se não logado. */
function requireLogin(): void {
    if (!usuarioLogado()) {
        $base = _baseUrl();
        header('Location: ' . $base . '/pages/login-admin.php');
        exit;
    }
}

// ── FUNÇÕES DE CLIENTE ────────────────────────────────────────

/**
 * Tenta logar um cliente (clientes).
 * Retorna true em sucesso, false em falha.
 */
function loginCliente(string $email, string $senha): bool {
    $db   = getDB();
    $stmt = $db->prepare(
        "SELECT * FROM clientes WHERE email = ? AND senha = MD5(?) LIMIT 1"
    );
    $stmt->execute([$email, $senha]);
    $cliente = $stmt->fetch();

    if ($cliente) {
        $_SESSION['cliente'] = [
            'id'       => $cliente['id'],
            'nome'     => $cliente['nome'],
            'email'    => $cliente['email'],
            'telefone' => $cliente['telefone'] ?? '',
        ];
        return true;
    }
    return false;
}

/** Retorna se há um cliente logado. */
function clienteLogado(): bool {
    return !empty($_SESSION['cliente']);
}

/** Retorna os dados do cliente logado ou null. */
function clienteAtual(): ?array {
    return $_SESSION['cliente'] ?? null;
}

/** Exige login de cliente, redireciona para login-cliente se não logado. */
function requireCliente(): void {
    if (!clienteLogado()) {
        $base = _baseUrl();
        header('Location: ' . $base . '/pages/login-cliente.php');
        exit;
    }
}

// ── CADASTRO DE CLIENTE ───────────────────────────────────────

/**
 * Cadastra um novo cliente.
 * Retorna true em sucesso ou string com mensagem de erro.
 */
function cadastrarCliente(array $dados): bool|string {
    $db = getDB();

    // Verifica e-mail duplicado
    $check = $db->prepare("SELECT id FROM clientes WHERE email = ? LIMIT 1");
    $check->execute([$dados['email']]);
    if ($check->fetch()) {
        return 'Este e-mail já está cadastrado. Tente fazer login.';
    }

    $db->prepare(
        "INSERT INTO clientes (nome, email, senha, telefone, data_nascimento)
         VALUES (?, ?, MD5(?), ?, ?)"
    )->execute([
        $dados['nome'],
        $dados['email'],
        $dados['senha'],
        $dados['telefone']   ?: null,
        $dados['data_nascimento'] ?: null,
    ]);

    $id = (int)$db->lastInsertId();

    // Loga automaticamente após cadastro
    $_SESSION['cliente'] = [
        'id'       => $id,
        'nome'     => $dados['nome'],
        'email'    => $dados['email'],
        'telefone' => $dados['telefone'] ?? '',
    ];

    return true;
}

// ── LOGOUT ────────────────────────────────────────────────────

/** Encerra sessão de funcionário. */
function logout(): void {
    unset($_SESSION['usuario']);
    session_destroy();
    header('Location: ' . _baseUrl() . '/pages/login-admin.php');
    exit;
}

/** Encerra sessão de cliente. */
function logoutCliente(): void {
    unset($_SESSION['cliente']);
    session_destroy();
    header('Location: ' . _baseUrl() . '/pages/login-cliente.php');
    exit;
}

// ── UTILITÁRIO ────────────────────────────────────────────────

/**
 * Detecta a URL base do projeto automaticamente.
 * Funciona tanto em localhost/restaurante quanto em domínio próprio.
 */
function _baseUrl(): string {
    $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host  = $_SERVER['HTTP_HOST'] ?? 'localhost';

    // Sobe dois níveis a partir de includes/ para chegar à raiz do projeto
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']));
    $docRoot   = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $relPath   = str_replace($docRoot, '', $scriptDir);

    // Pega só a parte até a pasta raiz do projeto (primeira pasta depois da raiz)
    $parts    = array_filter(explode('/', $relPath));
    $rootPart = '/' . (reset($parts) ?: '');

    // Se estiver na raiz do servidor, não adiciona subpasta
    if (count($parts) === 0 || $relPath === '/') {
        return $proto . '://' . $host;
    }

    return $proto . '://' . $host . $rootPart;
}

// =============================================================
//  VALIDAÇÃO DE HORÁRIOS DE RESERVA
// =============================================================

/**
 * Retorna os blocos de horário permitidos para um dado dia da semana.
 * $diaSemana: 0=Dom, 1=Seg, ..., 5=Sex, 6=Sab
 */
function getHorariosPermitidos(int $diaSemana): array {
    return match(true) {
        $diaSemana === 0                    => [['12:00','17:00']],           // Domingo
        in_array($diaSemana, [5, 6])        => [['12:00','23:59']],           // Sex e Sáb
        in_array($diaSemana, [1,2,3,4])     => [['12:00','15:00'],['19:00','23:00']], // Seg-Qui
        default                             => [['12:00','23:00']],
    };
}

/**
 * Valida se um horário (HH:MM) é permitido para uma data (Y-m-d).
 * Retorna true se válido, ou string com mensagem de erro.
 */
function validarHorarioReserva(string $data, string $hora): bool|string {
    $diaSemana = (int)date('w', strtotime($data));
    $blocos    = getHorariosPermitidos($diaSemana);

    $hm = strtotime("1970-01-01 $hora:00");

    foreach ($blocos as $bloco) {
        $inicio = strtotime("1970-01-01 {$bloco[0]}:00");
        $fim    = strtotime("1970-01-01 {$bloco[1]}:00");
        if ($hm >= $inicio && $hm <= $fim) {
            return true;
        }
    }

    $nomeDia = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'][$diaSemana];
    $descricao = match(true) {
        $diaSemana === 0               => '12h às 17h',
        in_array($diaSemana,[5,6])     => '12h às 00h',
        default                        => '12h às 15h ou 19h às 23h',
    };

    return "$nomeDia: horário disponível apenas das $descricao.";
}
